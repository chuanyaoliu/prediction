import numpy as np
import json
import os
import codecs
import pdb
from scipy import spatial

path = os.path.join("dataset", "json_dataset", "predicates.json")
rels = [i.split() for i in json.load(open(path,"r"))]
relation = [" ".join(i) for i in rels]
print(relation)
# word_set = []
# for i in rels:
#     word_set.extend(i)
# word_set = list(set(word_set))
# word2id = dict(zip(word_set, range(word_set.__len__())))
# id2word = dict(zip(range(word_set.__len__()), word_set))
#
# relVec = []
# extraVec = []
# VectorPath = os.path.join("dataset", "glove.840B.300d", "glove.840B.300d.txt")
# relWordVectr = dict()
# with codecs.open(VectorPath, "r", "utf-8") as f:
#     for line in f:
#         value = line.split()
#         if value[0] == ",":
#             extraVec = value[1:]
#             print("find ,")
#             break
#         # if not value:
#         #     continue
#         # word, vec = value[0], value[1:]
#         # if word in word_set:
#         #     try:
#         #         relWordVectr[word] = [float(i) for i in vec]
#         #     except ValueError:
#         #         print("value error")
#         #         print(value.__len__())
#         #         print(value)
#
# storePath = os.path.join("dataset", "glove.840B.300d", "relWord.npy")
# # np.save(storePath, relWordVectr)
# relWordVector = np.load(storePath).item()
# result = []
# for rel in rels:
#     temp = np.zeros(300)
#     for word in rel:
#         temp += np.asarray(relWordVector[word])
#     temp = temp/rel.__len__()
#     result.append(temp)
# result.append(extraVec)
path = os.path.join("dataset", "initRelEmbedding.npy")
# np.save(path, result)
resultLoad = np.load(path)
rel2vec = dict()
relName = []
for rel, vec in zip(rels, resultLoad):
    temp = " ".join(rel)
    rel2vec[temp] = [float(i) for i in vec]
    relName.append(temp)
result = []
distanceDict = dict()
for key, value in rel2vec.items():
    temp = []
    for tempKey, tempValue in rel2vec.items():
        # distance = 1 - spatial.distance.cosine(value, tempValue)
        distance = np.linalg.norm(np.asarray(value)-np.asarray(tempValue))
        temp.append(distance)
    # print(key, sum(temp))
    distanceDict[key] = sum(sorted(temp)[:3])
    result.append(temp)
    # print("*" * 30)
betterLabel = ["on", "above", "behind","under", "has", "in the front of", "below", "sit on"]
worseLabel = ["next to", "hold", "in", "near"]
for key, value in sorted(distanceDict.items(), key=lambda x:x[1]):
    print(key, value)
print("*" * 30)
for i in betterLabel:
    print(i, distanceDict[i])
print("*" * 30)
for i in worseLabel:
    print(i, distanceDict[i])
relWeight = dict()
rel2id = dict(zip(relation, range(relation.__len__())))
id2rel = dict(zip(range(relation.__len__()), relation))
for i in relation:
    distance = distanceDict[i]
    if i in ["next to", "hold"]:
        relWeight[rel2id[i]] = -0.008
    else:
        relWeight[rel2id[i]] = 0.0
path = os.path.join("dataset", "relWeight.npy")
#np.save(path, relWeight)
print(relWeight)
a = [2, 18, 18, 0, 9, 18, 1, 27, 1, 2, 2, 43, 1, 1, 10, 0]
print([id2rel[i] for i in a])
# path = os.path.join("dataset", "relWeight.npy")
# relWeight = np.load(path).item()
# print(type(relWeight))
# 画热力图
# import seaborn as sns
# import pandas as pd
# import matplotlib.pyplot as plt
# plt.figure(dpi = 1200)
# f, ax= plt.subplots(figsize = (20, 20))
# ax.tick_params(axis='y',labelsize=8)
# ax.tick_params(axis='x',labelsize=8)
# sns.heatmap(pd.DataFrame(result, columns = relName, index = relName), annot=False, xticklabels= 1, yticklabels= 1,linewidths=1., cmap="YlGnBu")
#
# imgPath = os.path.join("dataset", "relHotMap")
# plt.savefig(imgPath)
    # print(np.asarray(result).shape, np.asarray(resultLoad).shape)

# labels = [" ".join(i) for i in rels]
# labels.append(" ")
# from sklearn.manifold import TSNE
# import matplotlib.pyplot as plt
#
# tsne_model = TSNE(perplexity=40, n_components=2, init='pca', n_iter=2500, random_state=23)
# new_values = tsne_model.fit_transform(result)
#
# x = []
# y = []
# for value in new_values:
#     x.append(value[0])
#     y.append(value[1])
#
# plt.figure(figsize=(16, 16))
# for i in range(len(x)):
#     plt.scatter(x[i], y[i])
#     plt.annotate(labels[i],
#                  xy=(x[i], y[i]),
#                  xytext=(5, 2),
#                  textcoords='offset points',
#                  ha='right',
#                  va='bottom')
# # plt.show()
# pngPath = os.path.join("dataset", "relationVector.png")
# plt.savefig(pngPath)