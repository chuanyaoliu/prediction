import tensorflow as tf
import numpy as np
from configparser import ConfigParser
import os
import pdb
import datetime
from layer import *
from VrdTransE import VisualTransE
from EvalRecall import ErrorAnalysis, EvalRecallUnion
from VIsualModel import vgg_16
from layer import AlternatingHighWayCell
from VrdAttention import VisualAttention
import tensorflow.contrib.slim as slim
from tensorflow.contrib.slim import nets
from LoadMat import DataLoad
from MatDRNet import UnionData
from EvalRecall import EvalRecall
np.set_printoptions(threshold=np.nan)
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
cfg = ConfigParser()
cfg.read("config.ini", encoding="utf-8-sig")

#
#
# class DrNet(object):
#     def __init__(self):
#         self.learning_rate = 0.0001
#         self.relation_class = 70
#         self.iters = 8
#         self.ImgSize = 224
#         self.MaskSize =32
#
#         # tf placeholder
#         self.subject_input = tf.placeholder(tf.float32, [None, self.ImgSize, self.ImgSize, 3])
#         self.object_input = tf.placeholder(tf.float32, [None, self.ImgSize, self.ImgSize, 3])
#         self.context_input = tf.placeholder(tf.float32, [None, self.ImgSize, self.ImgSize, 3])
#         self.spatial_input = tf.placeholder(tf.float32, [None, self.MaskSize, self.MaskSize, 2])
#         self.relation_input = tf.placeholder(tf.int32, [None])
#         self.mode = tf.placeholder(tf.bool)
#
#     def construct(self, mode="train"):
#         is_training = self.mode
#         # subject_feature = self.exterior(self.subject_input, is_training=is_training, name="exterior", reuse=False)
#         # object_feature = self.exterior(self.object_input, is_training, name="exterior", reuse=True)
#         # # subject_feature = None
#         # # object_feature = None
#         # context_feature = self.exterior(self.context_input, is_training, name="exterior", reuse=True)
#         VisualInput = tf.concat((self.subject_input, self.object_input, self.context_input), axis=0)
#         subject_feature, object_feature, context_feature = self.exterior(VisualInput, is_training)
#         spatial = self.spatial(self.spatial_input)
#         pr = self.combine_feature(spatial, context_feature)
#         res = self.iter_reason(subject_feature, object_feature, pr)
#         # res = pr
#         assert res.get_shape()[-1] == self.relation_class
#
#         prob = tf.nn.softmax(res, dim=-1)
#         prediction = tf.argmax(prob, axis=-1)
#         # get loss and train_op
#         relation = tf.one_hot(self.relation_input, depth=self.relation_class)
#         cost = tf.nn.softmax_cross_entropy_with_logits(logits=res,
#                                                        labels=relation)
#         acc = tf.reduce_mean(tf.cast(
#             tf.equal(tf.cast(prediction, dtype=tf.int32), self.relation_input), dtype=tf.float32))
#         loss = tf.reduce_sum(cost)
#         optimizer = tf.train.AdamOptimizer(learning_rate=0.001)
#
#         train_step = slim.learning.create_train_op(loss, optimizer)
#
#         return prob, loss, train_step, acc
#
#     def iter_reason(self, subject_vector, object_vector, pr, name="reason"):
#         reuse = False
#         with tf.variable_scope(name, reuse=tf.AUTO_REUSE):
#             for i in range(self.iters):
#                 pa = slim.fully_connected(subject_vector, self.relation_class, scope="pa", reuse=tf.AUTO_REUSE)
#                 pb = slim.fully_connected(object_vector, self.relation_class, scope="pb", reuse=tf.AUTO_REUSE)
#                 pr = slim.fully_connected(pr, self.relation_class, scope="pr", reuse=tf.AUTO_REUSE)
#                 pr = tf.nn.relu(pa+pb+pr)
#                 # feature_vector = tf.concat((pa, pb, pr), axis=-1)
#                 reuse = True if not reuse else reuse
#         return pr
#
#     def spatial(self, spatial_input, name="spatial"):
#         spatial = tf.reshape(spatial_input, [-1, 32, 32, 2])
#         with tf.variable_scope(name):
#             conv1 = slim.conv2d(spatial, num_outputs=96, kernel_size=5, stride=2, padding='SAME', scope="conv1")
#             conv2 = slim.conv2d(conv1, num_outputs=128, kernel_size=5, stride=2, padding="SAME", scope="conv2")
#             conv3 = slim.conv2d(conv2, num_outputs=64, kernel_size=8, stride=1, padding="VALID", scope="conv3")
#             spatial_feature = tf.reshape(conv3, [-1, 1*1*64])
#         return spatial_feature
#
#     def exterior(self, feature, is_training, name="resnet"):
#         with slim.arg_scope(nets.resnet_v1.resnet_arg_scope()):
#             net, endpoints = nets.resnet_v1.resnet_v1_101(feature, num_classes=None,
#                                                           is_training=is_training)
#         VectorDim = net.get_shape()[-1]
#         net = tf.reshape(net, (-1, VectorDim))
#         sub, obj, context = tf.split(net, 3, axis=0)
#         return sub, obj, context
#
#     def combine_feature(self, spatial, context, name="combine"):
#         with tf.variable_scope(name):
#             feature = tf.concat((spatial, context), axis=-1)
#             fc1 = slim.fully_connected(feature, 128, activation_fn=tf.nn.relu)
#             fc2 = slim.fully_connected(fc1, self.relation_class, activation_fn=tf.nn.relu)
#         return fc2
#
#     def GetSaver(self, name='resnet_v1_101'):
#         checkpoint_exclude_scopes = name
#         exclusions = None
#         if checkpoint_exclude_scopes:
#             exclusions = [
#                 scope.strip() for scope in checkpoint_exclude_scopes.split(',')]
#         variables_to_restore = []
#         for var in slim.get_model_variables():
#             excluded = False
#             for exclusion in exclusions:
#                 if var.op.name.startswith(exclusion):
#                     excluded = True
#             if excluded:
#                 variables_to_restore.append(var)
#         # path = os.path.join("ckpt", "pretrain", "ResnetVariables.ins")
#         # pickle.dump(["resnet_v1_101"], open(path, "wb"))
#
#         saver_restore = tf.train.Saver(var_list=variables_to_restore)
#         saver = tf.train.Saver(tf.global_variables())
#
#         return saver_restore, saver
#
#     def TrainTest(self, data_train, data_test, resnet_model_path):
#         prob, loss, train_op, acc = self.construct()
#         saver_restore, saver = self.GetSaver()
#         config = tf.ConfigProto()
#         config.gpu_options.allow_growth = True
#         config.gpu_options.per_process_gpu_memory_fraction = 0.9
#         init = tf.global_variables_initializer()
#         epochs = 10
#         with tf.Session() as sess:
#             sess.run(init)
#             saver_restore.restore(sess, resnet_model_path)
#             for epoch in range(epochs):
#                 # training process
#                 step = 0
#                 train = data_train.NextBatchRelation()
#                 test = data_test.NextBatchRelation(test=True)
#                 TrainAcc = []
#                 for subjects, objects, contexts, spatials, relations in train:
#                     feed_dict = {
#                         self.subject_input: subjects,
#                         self.object_input: objects,
#                         self.context_input: contexts,
#                         self.spatial_input: spatials,
#                         self.relation_input: relations,
#                         self.mode: True}
#                     if len(relations) != 0:
#                         sess.run(train_op, feed_dict=feed_dict)
#                         # train_res, train_loss, _ = sess.run([prob, loss, train_op], feed_dict=feed_dict)
#                         train_acc, train_loss = sess.run([acc, loss],feed_dict=feed_dict)
#                         TrainAcc.append(train_acc)
#                     if step % 100 == 0:
#                         print("train step: {0}, acc: {1}".format(step, sum(TrainAcc)/TrainAcc.__len__()))
#                         TrainAcc.clear()
#                     step += 1
#                 # testing process
#                 step = 0
#                 TestAcc = []
#                 eve = EvalRecall()
#                 for subjects, objects, contexts, spatials, relations, RelationTruth, RelationCandidate in  test:
#                     feed_dict = {
#                         self.subject_input: subjects,
#                         self.object_input: objects,
#                         self.context_input: contexts,
#                         self.spatial_input: spatials,
#                         self.relation_input: relations,
#                         self.mode:False}
#                     if len(relations) != 0:
#                         test_res, test_acc = sess.run([prob, acc], feed_dict=feed_dict)
#                         TestAcc.append(test_acc)
#                         PredictTriad, Score = ContextModel.GetPredict(test_res, RelationCandidate)
#                         eve.add(RelationTruth, PredictTriad, Score)
#                     step += 1
#                 eve.show()
#                 print("test Recall:", sum(TestAcc)/TestAcc.__len__())
#
#
#
# if __name__ == "__main__":
#     TrainMat = "annotations_train.json"
#     train_data = DataDR(TrainMat, "sg_train_images", False)
#     RestorePath = os.path.join("ckpt", "Vrd", "vrd")
#     TestMat = "annotations_test.json"
#     test_data = DataDR(TestMat, "sg_test_images", False)
#     Dr = DrNet()
#     Dr.TrainTest(train_data, test_data, RestorePath)

# class VisualWeight(VisualAttention):
#
#     def __init__(self):
#         VisualAttention.__init__(self)
#         self.learning_rate = 0.0001
#         self.subjectMask = tf.placeholder(tf.float32, [None, self.MaskSize, self.MaskSize])
#         self.objectMask = tf.placeholder(tf.float32, [None, self.MaskSize, self.MaskSize])
#         self.spatial = tf.placeholder(tf.float32, [None, 4])
#
#     # def GetArch(self, NumLayers=4, BatchSize=1, teacher=False, isSemantic=False):
#     #     """
#     #     使用全部的信息，目前效果为0.531，不使用MSE(multi task方式为0.521，权重为0.2时为0.529),正在确认中
#     #     """
#     #     Img = tf.concat((self.subjectImg, self.objectImg), axis=0)
#     #     unionVisual = self.GetVisualFeature(Img)
#     #     unionVisual = tf.squeeze(unionVisual, 0)
#     #     subVisual, objVisual = tf.split(unionVisual, 2, axis=0)
#     #     # unionVisual = self.GetVisualFeature(self.unionImg)
#     #     # unionVisual = tf.squeeze(unionVisual, 0)
#     #     objectClass = tf.concat((self.subjectLabel, self.objectLabel), axis=0)
#     #     Word = self.GetWordVector(objectClass, path=None)
#     #     Word = tf.squeeze(Word, 0)
#     #     WordVector = slim.fully_connected(Word, num_outputs=100, activation_fn=None, biases_initializer=None)
#     #     subWord, objWord = tf.split(WordVector, 2, axis=0)
#     #     # edgeWord = tf.concat((subWord, objWord), axis=-1)
#     #     # subVec, objVec = subWord, objWord
#     #     subVec, objVec = tf.concat((subVisual, subWord), axis=-1), tf.concat((objVisual, objWord), axis=-1)
#     #     edgeVec = subVec - objVec
#     #
#     #     # UnionVisual = slim.fully_connected(UnionVisual, num_outputs=self.dim, activation_fn=None, biases_initializer=None)
#     #     edgeMask = tf.stack((self.subjectMask, self.objectMask, self.unionMask), axis=-1)
#     #     edgeMask = self.GetPositionMask(edgeMask)
#     #     edgeMask = tf.squeeze(edgeMask, 0)
#     #     edgeVec = tf.concat((edgeVec, edgeMask), axis=-1)
#     #     edgeVec = slim.fully_connected(edgeVec, num_outputs=500)
#     #     edge = slim.fully_connected(edgeVec, self.relationClass)
#     #
#     #     # subWord = tf.expand_dims(tf.expand_dims(subWord, 1), 1)
#     #     # objWord =  tf.expand_dims(tf.expand_dims(objWord, 1), 1)
#     #     #
#     #     # subMask = tf.expand_dims(self.subjectMask, -1)
#     #     # objMask = tf.expand_dims(self.objectMask, -1)
#     #     #
#     #     # subVec = subWord*subMask
#     #     # objVec = objWord*objMask
#     #     # # binary mask combine word vector
#     #     # edgeVector = (self.subjectMask+self.objectMask)/2
#     #     # edge = self.GetPositionMask(edgeVector)
#     #     # objectClass = tf.concat((self.subjectLabel, self.objectLabel), axis=0)
#     #     # # word = self.GetWordVector(self.ObjectClass, path=None)
#     #     # Word = self.GetWordVector(objectClass, path=None)
#     #     # WordVector = slim.fully_connected(Word, num_outputs=100)
#     #     # edgeMask = tf.stack((self.subjectMask, self.objectMask, self.unionMask), axis=-1)
#     #     #
#     #     # edge = self.ContextMaskAtt(unionVisual, WordVector, edgeMask)
#     #     EdgeScore = tf.nn.softmax(edge, dim=-1)
#     #     if teacher is True:
#     #         EdgeScore = EdgeScore*self.TeacherInput
#     #     re_edgeMask = slim.fully_connected(edgeVec, 64)
#     #     # edgeLoss = tf.losses.mean_squared_error(labels=edgeMask, predictions=re_edgeMask)*0.2
#     #     edgeLoss = None
#     #     loss, accuracy, train_step = self.GetOptimizer(edge,  self.RelationClass, Teacher=teacher, maskFeature=edgeLoss)
#     #
#     #     return loss, accuracy, train_step, EdgeScore, # index
#
#     # def GetArch(self, NumLayers=4, BatchSize=1, teacher=False):
#     #     """
#     #     尝试融合不同来源的att，目前实验结果为object的att：0.512，mask的att：0.539, 再次实验出现波动
#     #     """
#     #     Img = tf.concat((self.subjectImg, self.objectImg), axis=0)
#     #     # use pool5 map, shape:batch, weight, height, channel
#     #     unionVisual = self.GetVisualFeature(Img)
#     #     subVisual, objVisual = tf.split(unionVisual, 2, axis=0)
#     #     unionVisual = subVisual*objVisual
#     #
#     #     objectClass = tf.concat((self.subjectLabel, self.objectLabel), axis=0)
#     #     Word = self.GetWordVector(objectClass, path=None)
#     #
#     #     # UnionVisual = slim.fully_connected(UnionVisual, num_outputs=self.dim, activation_fn=None, biases_initializer=None)
#     #     edgeMask = tf.stack((self.subjectMask, self.objectMask, self.unionMask), axis=-1)
#     #
#     #     edge = self.ContextMaskWordAtt_weight(unionVisual, Word, edgeMask)
#     #
#     #     EdgeScore = tf.nn.softmax(edge, dim=-1)
#     #     if teacher is True:
#     #         EdgeScore = EdgeScore*self.TeacherInput
#     #     # re_edgeMask = slim.fully_connected(edgeVec, 64)
#     #     # edgeLoss = tf.losses.mean_squared_error(labels=edgeMask, predictions=re_edgeMask)*0.2
#     #     edgeLoss = None
#     #     loss, accuracy, train_step = self.GetOptimizer(edge,  self.RelationClass, Teacher=teacher, maskFeature=edgeLoss)
#     #
#     #     return loss, accuracy, train_step, EdgeScore, # index
#
#     # def GetArch(self, NumLayers=4, BatchSize=1, teacher=False, isSemantic=False):
#     #     """
#     #     尝试结合spatial和semantic 的结构图
#     #     """
#     #     Img = tf.concat((self.subjectImg, self.objectImg), axis=0)
#     #     # use pool5 map, shape:batch, weight, height, channel
#     #     unionVisual = self.GetVisualFeature(Img)
#     #     unionVisual = tf.squeeze(unionVisual, 0) if unionVisual.get_shape()[0] == 1 else unionVisual
#     #     subVisual, objVisual = tf.split(unionVisual, 2, axis=0)
#     #     visualScore = slim.fully_connected(subVisual*objVisual, self.relationClass)
#     #
#     #     objectClass = tf.concat((self.subjectLabel, self.objectLabel), axis=0)
#     #     Word = self.GetWordVector(objectClass, path=None)
#     #
#     #     # UnionVisual = slim.fully_connected(UnionVisual, num_outputs=self.dim, activation_fn=None, biases_initializer=None)
#     #     edgeMask = tf.stack((self.subjectMask, self.objectMask, self.unionMask), axis=-1)
#     #
#     #     subSemantic, objSemantic = self.getSpatialSemantic(Word, self.subjectMask, self.objectMask)
#     #     semanticScore = slim.fully_connected(subSemantic*objSemantic, self.relationClass)
#     #
#     #     edgeMask = tf.squeeze(self.GetPositionMask(edgeMask), axis=0)
#     #     subjectWordVector, objectWordVector = tf.split(tf.nn.relu(tf.squeeze(Word, 0)), 2, axis=0)
#     #     extraFeature = tf.concat((subjectWordVector * objectWordVector, edgeMask), axis=-1)
#     #     extraScore = slim.fully_connected(extraFeature, self.relationClass)
#     #
#     #     edge = visualScore*0.6 + semanticScore*0.1 + extraScore*0.3
#     #     # edge = self.ContextMaskWordAtt_weight(unionVisual, Word, edgeMask)
#     #
#     #     EdgeScore = tf.nn.softmax(edge, dim=-1)
#     #     if teacher is True:
#     #         EdgeScore = EdgeScore*self.TeacherInput
#     #     # re_edgeMask = slim.fully_connected(edgeVec, 64)
#     #     # edgeLoss = tf.losses.mean_squared_error(labels=edgeMask, predictions=re_edgeMask)*0.2
#     #     edgeLoss = None
#     #     loss, accuracy, train_step = self.GetOptimizer(edge,  self.RelationClass, Teacher=teacher, maskFeature=edgeLoss)
#     #
#     #     return loss, accuracy, train_step, EdgeScore, # index
#
#     # def GetArch(self, NumLayers=4, BatchSize=1, teacher=False, isSemantic=False):
#     #     """
#     #      正常的visual+semanticVisual，达到了0.45，emmm但是同样没有semanticVisual是0.442，
#     #     所以有提升???, 没有细调也许调参会更有效, 修改wordVector的方式之后 baseline上升至0.52，问题在于如何组合不同来源的visual
#     #     feature
#     #     采用不训练semantic的方式是0.5238/(正常的情况0.5242)，emm基本上与不加这个网络的效果保持一致
#     #     训练的时候为0.5218. 基本上....
#     #     """
#     #     Img = tf.concat((self.subjectImg, self.objectImg), axis=0)
#     #     # use pool5 map, shape:batch, weight, height, channel
#     #     unionVisual = self.GetVisualFeature(Img)
#     #     unionSemanticVisual = self.semanticFeature(Img)
#     #     subSemanticVisual, objSemanticVisual = tf.split(unionSemanticVisual, 2, axis=0)
#     #     unionVisual = tf.squeeze(unionVisual, 0) if unionVisual.get_shape()[0] == 1 else unionVisual
#     #     subVisual, objVisual = tf.split(unionVisual, 2, axis=0)
#     #     # subVisual += subSemanticVisual
#     #     # objVisual += objSemanticVisual
#     #     objectClass = tf.concat((self.subjectLabel, self.objectLabel), axis=0)
#     #     Word = self.GetWordVector(objectClass, path=None)
#     #     WordVector = slim.fully_connected(tf.squeeze(Word, 0), num_outputs=100, activation_fn=None, biases_initializer=None)
#     #     subjectWordVector, objectWordVector = tf.split(WordVector, 2, axis=0)
#     #     # UnionVisual = slim.fully_connected(UnionVisual, num_outputs=self.dim, activation_fn=None, biases_initializer=None)
#     #     edgeMask = tf.stack((self.subjectMask, self.objectMask, self.unionMask), axis=-1)
#     #     edgeMask = tf.squeeze(self.GetPositionMask(edgeMask), axis=0)
#     #
#     #     edgeVec = subVisual-objVisual
#     #     edgeSemanticVisual = subSemanticVisual-objSemanticVisual
#     #     edgeWeight = tf.sigmoid(slim.fully_connected(edgeVec, 500) + slim.fully_connected(edgeSemanticVisual, 500))
#     #     edgeVisual = edgeWeight*slim.fully_connected(edgeVec, 500) + (1-edgeWeight)*slim.fully_connected(edgeSemanticVisual,500)
#     #     edgeExtra = tf.concat((subjectWordVector-objectWordVector, edgeMask), axis=-1)
#     #
#     #     edgeFeature = tf.concat((edgeVisual,edgeExtra), axis=-1)
#     #     # edgeFeature = tf.concat((subjectWordVector*objectWordVector, edgeMask), axis=-1)
#     #     edgeFeature = slim.fully_connected(edgeFeature, num_outputs=500)
#     #     edge =slim.fully_connected(edgeFeature, self.relationClass)
#     #     # edge = self.ContextMaskWordAtt_weight(unionVisual, Word, edgeMask)
#     #
#     #     EdgeScore = tf.nn.softmax(edge, dim=-1)
#     #     if teacher is True:
#     #         EdgeScore = EdgeScore*self.TeacherInput
#     #     # re_edgeMask = slim.fully_connected(edgeVec, 64)
#     #     # edgeLoss = tf.losses.mean_squared_error(labels=edgeMask, predictions=re_edgeMask)*0.2
#     #     edgeLoss = None
#     #     loss, accuracy, train_step = self.GetOptimizer(edge,  self.RelationClass, Teacher=teacher, maskFeature=edgeLoss)
#     #
#     #     return loss, accuracy, train_step, EdgeScore, # index
#
#     # def GetArch(self, NumLayers=4, BatchSize=1, teacher=False, isSemantic=False):
#     #     """
#     #     把特征减少一点，看会不会有点改进的感觉，emmm 是存在改进，删掉wordvector后，改进为0.454 -> 0.457
#     #     """
#     #     Img = tf.concat((self.subjectImg, self.objectImg), axis=0)
#     #     # use pool5 map, shape:batch, weight, height, channel
#     #     unionVisual = self.GetVisualFeature(Img)
#     #     unionSemanticVisual = self.semanticFeature(Img)
#     #     subSemanticVisual, objSemanticVisual = tf.split(unionSemanticVisual, 2, axis=0)
#     #     unionVisual = tf.squeeze(unionVisual, 0) if unionVisual.get_shape()[0] == 1 else unionVisual
#     #     subVisual, objVisual = tf.split(unionVisual, 2, axis=0)
#     #     # subVisual += subSemanticVisual
#     #     # objVisual += objSemanticVisual
#     #     objectClass = tf.concat((self.subjectLabel, self.objectLabel), axis=0)
#     #     WordVector = tf.one_hot(objectClass, depth=self.objectClass)
#     #     # Word = self.GetWordVector(objectClass, path=None)
#     #     # WordVector = slim.fully_connected(tf.squeeze(Word, 0), num_outputs=100, activation_fn=None, biases_initializer=None)
#     #     subjectWordVector, objectWordVector = tf.split(WordVector, 2, axis=0)
#     #     # UnionVisual = slim.fully_connected(UnionVisual, num_outputs=self.dim, activation_fn=None, biases_initializer=None)
#     #     edgeMask = tf.stack((self.subjectMask, self.objectMask, self.unionMask), axis=-1)
#     #     edgeMask = tf.squeeze(self.GetPositionMask(edgeMask), axis=0)
#     #
#     #     edgeVec = subVisual-objVisual
#     #     # edgeSemanticVisual = subSemanticVisual-objSemanticVisual
#     #     # edgeWeight = tf.sigmoid(slim.fully_connected(edgeVec, 500) + slim.fully_connected(edgeSemanticVisual, 500))
#     #     # edgeVisual = edgeWeight*slim.fully_connected(edgeVec, 500) + (1-edgeWeight)*slim.fully_connected(edgeSemanticVisual,500)
#     #     edgeExtra = tf.concat((subjectWordVector, objectWordVector, edgeMask), axis=-1)
#     #
#     #     edgeFeature = tf.concat((edgeVec,edgeExtra), axis=-1)
#     #     # edgeFeature = tf.concat((subjectWordVector*objectWordVector, edgeMask), axis=-1)
#     #     edgeFeature = slim.fully_connected(edgeFeature, num_outputs=500)
#     #     edge =slim.fully_connected(edgeFeature, self.relationClass)
#     #     # edge = self.ContextMaskWordAtt_weight(unionVisual, Word, edgeMask)
#     #
#     #     EdgeScore = tf.nn.softmax(edge, dim=-1)
#     #     if teacher is True:
#     #         EdgeScore = EdgeScore*self.TeacherInput
#     #     # re_edgeMask = slim.fully_connected(edgeVec, 64)
#     #     # edgeLoss = tf.losses.mean_squared_error(labels=edgeMask, predictions=re_edgeMask)*0.2
#     #     edgeLoss = None
#     #     loss, accuracy, train_step = self.GetOptimizer(edge,  self.RelationClass, Teacher=teacher, maskFeature=edgeLoss)
#     #
#     #     return loss, accuracy, train_step, EdgeScore, # index
#
#     # def GetArch(self, NumLayers=4, BatchSize=1, teacher=False, isSemantic=False):
#     #     """
#     #     把feature换成了transE中描述的那样，标准地出来是0.3997，加上edgeVector loss之后是0.4447，
#     #     均会被原版的低很多，所以找一下原因，改一下好了
#     #     """
#     #     Img = tf.concat((self.subjectImg, self.objectImg), axis=0)
#     #     # use pool5 map, shape:batch, weight, height, channel
#     #     unionVisual = self.GetVisualFeature(Img)
#     #     unionVisual = tf.squeeze(unionVisual, 0) if unionVisual.get_shape()[0] == 1 else unionVisual
#     #     subVisual, objVisual = tf.split(unionVisual, 2, axis=0)
#     #
#     #     objectClass = tf.concat((self.subjectLabel, self.objectLabel), axis=0)
#     #     WordVector = tf.one_hot(objectClass, depth=self.relationClass)
#     #     # WordVector = self.GetWordVector(objectClass, path=None)
#     #     # WordVector = tf.squeeze(WordVector, axis=0)
#     #     subjectWordVector, objectWordVector = tf.split(WordVector, 2, axis=0)
#     #
#     #     # edgeMask = tf.stack((self.subjectMask, self.objectMask, self.unionMask), axis=-1)
#     #     # edgeMask = tf.squeeze(self.GetPositionMask(edgeMask), axis=0)
#     #     edgeMask = self.spatial
#     #     edgeVec = subVisual-objVisual
#     #     edgeExtra = tf.concat((subjectWordVector-objectWordVector, edgeMask), axis=-1)
#     #     edgeFeature = tf.concat((edgeVec,edgeExtra), axis=-1)
#     #     edgeFeature = slim.fully_connected(edgeFeature, num_outputs=500)
#     #     relationWordVector = self.getRelWordVector(self.RelationClass)
#     #     relationWordVector = slim.fully_connected(relationWordVector, num_outputs=500)
#     #
#     #     edge =slim.fully_connected(edgeFeature, self.relationClass)
#     #     EdgeScore = tf.nn.softmax(edge, dim=-1)
#     #     if teacher is True:
#     #         EdgeScore = EdgeScore*self.TeacherInput
#     #     # re_edgeMask = slim.fully_connected(edgeVec, 64)
#     #     # edgeLoss = tf.losses.mean_squared_error(labels=edgeMask, predictions=re_edgeMask)*0.2
#     #     edgeLoss = tf.reduce_sum(tf.square(relationWordVector-edgeFeature), axis=-1)*0.01
#     #     # edgeLoss = tf.reduce_mean(edgeLoss, axis=0)*0.01
#     #     # edgeLoss = None
#     #     loss, accuracy, train_step = self.GetOptimizer(edge,  self.RelationClass, Teacher=teacher, maskFeature=edgeLoss)
#     #
#     #     return loss, accuracy, train_step, EdgeScore, # index
#     def GetArch(self, NumLayers=4, BatchSize=1, teacher=False, isSemantic=False):
#         """
#         把feature换成了transE中描述的那样，标准地出来是0.3997，加上edgeVector loss之后是0.4447，
#         均会被原版的低很多，所以找一下原因，改一下好了
#         """
#         Img = tf.concat((self.subjectImg, self.objectImg), axis=0)
#         # use pool5 map, shape:batch, weight, height, channel
#         unionVisual = self.GetVisualFeature(Img)
#         unionVisual = tf.squeeze(unionVisual, 0) if unionVisual.get_shape()[0] == 1 else unionVisual
#         subVisual, objVisual = tf.split(unionVisual, 2, axis=0)
#
#         objectClass = tf.concat((self.subjectLabel, self.objectLabel), axis=0)
#         WordVector = tf.one_hot(objectClass, depth=self.relationClass)
#         # WordVector = self.GetWordVector(objectClass, path=None)
#         # WordVector = tf.squeeze(WordVector, axis=0)
#         subjectWordVector, objectWordVector = tf.split(WordVector, 2, axis=0)
#
#         # edgeMask = tf.stack((self.subjectMask, self.objectMask, self.unionMask), axis=-1)
#         # edgeMask = tf.squeeze(self.GetPositionMask(edgeMask), axis=0)
#         edgeMask = self.spatial
#         edgeVec = subVisual-objVisual
#         edgeExtra = tf.concat((subjectWordVector-objectWordVector, edgeMask), axis=-1)
#         edgeFeature = tf.concat((edgeVec,edgeExtra), axis=-1)
#         edgeFeature = slim.fully_connected(edgeFeature, num_outputs=500)
#         relationWordVector = self.getRelWordVector(self.RelationClass)
#         relationWordVector = slim.fully_connected(relationWordVector, num_outputs=500)
#
#         edge =slim.fully_connected(edgeFeature, self.relationClass)
#         EdgeScore = tf.nn.softmax(edge, dim=-1)
#         if teacher is True:
#             EdgeScore = EdgeScore*self.TeacherInput
#         # re_edgeMask = slim.fully_connected(edgeVec, 64)
#         # edgeLoss = tf.losses.mean_squared_error(labels=edgeMask, predictions=re_edgeMask)*0.2
#         edgeLoss = tf.reduce_sum(tf.square(relationWordVector-edgeFeature), axis=-1)*0.01
#         # edgeLoss = tf.reduce_mean(edgeLoss, axis=0)*0.01
#         # edgeLoss = None
#         loss, accuracy, train_step = self.GetOptimizer(edge,  self.RelationClass, Teacher=teacher, maskFeature=edgeLoss)
#
#         return loss, accuracy, train_step, EdgeScore, # index
#
#     def GetVisualFeature(self, Regions):
#         ResNetInput = tf.reshape(Regions, (-1, self.ImgSize, self.ImgSize, 3))
#         with slim.arg_scope(nets.vgg.vgg_arg_scope()):
#             net, endpoints, feature = vgg_16(ResNetInput, num_classes=None, is_training=self.IsTraining)
#         # x_h, out = CANAttention(feature, is_training=self.IsTraining)
#         # out = SpatialATT(feature)
#
#         # feature pool5 对应的feature map
#         out = feature
#         # with tf.variable_scope("visual_concept"):
#         #     visualConcept = slim.conv2d(out, 256, kernel_size=1, stride=1)
#         #     visualConcept = slim.dropout(visualConcept, self.dropout, is_training=self.IsTraining, scope="drop6")
#         #     voting = slim.conv2d(visualConcept, 512, kernel_size=15, stride=1)
#         # out, weight = SelfATT(feature)
#         with tf.variable_scope('vgg_16', reuse=True):
#             # Use conv2d instead of fully_connected layers.
#             out = slim.conv2d(out, 4096, [7, 7], padding="VALID", scope='fc6')
#             out = slim.dropout(out, 0.5, is_training=self.IsTraining,
#                                scope='dropout6')
#             out = slim.conv2d(out, 4096, [1, 1], scope='fc7')
#         VectorDim = out.get_shape()[-1]
#         out = tf.reshape(out, (1, -1, VectorDim))
#         # out = tf.concat((x_h, out), axis=-1)
#         return out
#
#     def GetOptimizer(self, logits, labels, Teacher=True, alpha=0.5, maskFeature=None):
#         edgeLabel = labels
#         print(logits)
#         edgeLosses = tf.nn.softmax_cross_entropy_with_logits(
#                      labels=tf.one_hot(edgeLabel, depth=self.relationClass), logits=logits)
#         losses = edgeLosses # + maskLosses + actionLosses
#         optimizer = tf.train.AdamOptimizer(learning_rate=self.learning_rate)
#         if Teacher is True:
#             print("teacher input")
#             teacherLogits = tf.nn.softmax(logits)
#             teacherLabel = self.TeacherInput*teacherLogits
#             teacherLoss = -tf.reduce_sum(teacherLabel * tf.log(tf.clip_by_value(teacherLogits, 1e-10, 1.0)) +
#                                          (1-teacherLabel)*tf.log(1- tf.clip_by_value(teacherLogits, 1e-10, 1.0)))
#             # teacherLoss =  tf.nn.softmax_cross_entropy_with_logits(
#             # labels=tf.one_hot(edgeLabel, depth=self.relationClass), logits=self.TeacherInput*logits)
#             a = tf.get_variable("weight_loss_a", initializer=tf.constant(2.0))
#             b = tf.get_variable("weight_loss_b", initializer=tf.constant(2.0))
#             # teacherLoss = -tf.reduce_mean(teacherProb * tf.log(tf.clip_by_value(tf.nn.softmax(logits), 1e-10, 1.0)))
#             # losses = losses*tf.exp(-a) + tf.exp(-b)*teacherLoss + 0.5 * a + 0.5*b
#             # losses = edgeLosses*tf.exp(-a) + tf.exp(-b)*teacherLoss + 0.5*a + 0.5*b
#             losses = teacherLoss*(1-self.a) + edgeLosses*self.a
#         if maskFeature is not None:
#             losses += maskFeature
#             print("add extra loss")
#         logits = tf.nn.softmax(logits)
#         classes = tf.argmax(logits, axis=1, name='classes')
#         accuracy = tf.reduce_mean(tf.cast(
#             tf.equal(tf.cast(classes, dtype=tf.int32), edgeLabel), dtype=tf.float32))
#
#         loss = tf.reduce_mean(losses)
#         # var_list = []
#         # for i in tf.trainable_variables():
#         #     if i.name.split("/")[0] in ["semanticVgg"]:
#         #         continue
#         #     else:osses += maskFeature
#         #         var_list.append(i)
#         train_step = slim.learning.create_train_op(loss, optimizer)#, variables_to_train=var_list)
#         return loss, accuracy, train_step
#
#     def ContextAtt(self, unionVisual, wordVector, edgeMask,scope="context_att"):
#         # text att 效果正常达到0.533，与论文的0.536相差不多
#         edgeMask = tf.squeeze(self.GetPositionMask(edgeMask), axis=0)
#
#         wordDim = wordVector.get_shape()[-1]
#         feature_dim = unionVisual.get_shape()[-1]
#         batch = tf.shape(unionVisual)[0]
#         subjectWordVector, objectWordVector = tf.split(tf.nn.relu(tf.squeeze(wordVector, 0)), 2, axis=0)
#         WordVector = tf.reshape(tf.concat((subjectWordVector, objectWordVector), axis=-1), (-1, wordDim * 2, 1))
#         WordVector = tf.tile(WordVector, [1,1, feature_dim])
#         WordVector = tf.tile(tf.expand_dims(WordVector, -1), [1, 1, 1, self.relationClass])
#         with tf.variable_scope(scope):
#             wp = tf.get_variable("context_wp", shape=(1, feature_dim, self.relationClass))
#             wp = tf.tile(wp, [batch, 1, 1])
#
#             vp = tf.get_variable("context_vp", shape=(1, wordDim*2, feature_dim, self.relationClass))
#             vp = tf.tile(vp, [batch, 1, 1, 1])
#             context = tf.reduce_sum(vp*WordVector, axis=1)
#             cls = wp + context
#             weight, height = unionVisual.get_shape()[1:3]
#             # x: batch, weight, height, channel
#             # cls: batch, channel, classes
#             visual = tf.tile(tf.expand_dims(unionVisual, -1), [1, 1, 1, 1,self.relationClass])
#             cls = tf.tile(tf.expand_dims(cls, 1), [1, weight, 1, 1])
#             cls = tf.tile(tf.expand_dims(cls, 2), [1, 1, height, 1, 1])
#             attention_map = tf.reduce_sum(cls*visual, axis=3)
#             w_a = tf.get_variable("w_a",shape=[weight, height, self.relationClass], initializer=tf.random_uniform_initializer(minval=0, maxval=1))
#             w_a = tf.tile(tf.expand_dims(w_a, axis=0), [batch, 1, 1, 1])
#             attention_numerator = tf.nn.softplus(attention_map) + w_a
#             attention_dominator = tf.reduce_sum(tf.reduce_sum(attention_numerator, axis=2), axis=1)
#             attention_final = attention_numerator / tf.expand_dims(tf.expand_dims(attention_dominator,axis=1), axis=2)
#             attention_final = tf.expand_dims(attention_final, axis=-2)
#             visual = attention_final * visual
#             att_visual = tf.reduce_sum(tf.reduce_sum(visual, axis=2), axis=1)
#
#         with tf.variable_scope("context_cls"):
#             wp = tf.get_variable("context_wp", shape=(1, feature_dim, self.relationClass))
#             wp = tf.tile(wp, [batch, 1, 1])
#
#             vp = tf.get_variable("context_vp", shape=(1, wordDim * 2, feature_dim, self.relationClass))
#             bias = tf.get_variable("context_bias", shape=(1, self.relationClass))
#             vp = tf.tile(vp, [batch, 1, 1, 1])
#             context = tf.reduce_sum(vp * WordVector, axis=1)
#             cls = wp + context
#
#             score = tf.reduce_sum(att_visual * cls, axis=1) + bias
#
#             maskScore = slim.fully_connected(edgeMask, num_outputs=self.relationClass, activation_fn=tf.nn.relu)
#             score += maskScore
#         return score
#
#     def ContextMaskAtt(self, unionVisual, wordVector, edgeMask,scope="context_mask_att"):
#         edge = tf.squeeze(self.GetPositionMask(edgeMask), axis=0)
#
#         maskDim = edge.get_shape()[-1]
#         wordDim = wordVector.get_shape()[-1]
#         feature_dim = unionVisual.get_shape()[-1]
#         batch = tf.shape(unionVisual)[0]
#         edge = tf.tile(tf.expand_dims(edge, -1), [1, 1, feature_dim])
#         edge = tf.tile(tf.expand_dims(edge, -1), [1, 1, 1, self.relationClass])
#         subjectWordVector, objectWordVector = tf.split(tf.nn.relu(tf.squeeze(wordVector, 0)), 2, axis=0)
#         WordVector = tf.reshape(tf.concat((subjectWordVector, objectWordVector), axis=-1), (-1, wordDim * 2))
#         # WordVector = tf.tile(WordVector, [1, 1, feature_dim])
#         # WordVector = tf.tile(tf.expand_dims(WordVector, -1), [1, 1, 1, self.relationClass])
#         with tf.variable_scope(scope):
#             wp = tf.get_variable("context_wp", shape=(1, feature_dim, self.relationClass))
#             wp = tf.tile(wp, [batch, 1, 1])
#
#             vp = tf.get_variable("context_vp", shape=(1, maskDim, feature_dim, self.relationClass))
#             vp = tf.tile(vp, [batch, 1, 1, 1])
#             context = tf.reduce_sum(vp * edge, axis=1)
#             cls = wp + context
#             weight, height = unionVisual.get_shape()[1:3]
#             # x: batch, weight, height, channel
#             # cls: batch, channel, classes
#             visual = tf.tile(tf.expand_dims(unionVisual, -1), [1, 1, 1, 1, self.relationClass])
#             cls = tf.tile(tf.expand_dims(cls, 1), [1, weight, 1, 1])
#             cls = tf.tile(tf.expand_dims(cls, 2), [1, 1, height, 1, 1])
#             attention_map = tf.reduce_sum(cls * visual, axis=3)
#             w_a = tf.get_variable("w_a", shape=[weight, height, self.relationClass],
#                                   initializer=tf.random_uniform_initializer(minval=0, maxval=1))
#             w_a = tf.tile(tf.expand_dims(w_a, axis=0), [batch, 1, 1, 1])
#             attention_numerator = tf.nn.softplus(attention_map) + w_a
#             attention_dominator = tf.reduce_sum(tf.reduce_sum(attention_numerator, axis=2), axis=1)
#             attention_final = attention_numerator / tf.expand_dims(tf.expand_dims(attention_dominator, axis=1), axis=2)
#             attention_final = tf.expand_dims(attention_final, axis=-2)
#             visual = attention_final * visual
#             att_visual = tf.reduce_sum(tf.reduce_sum(visual, axis=2), axis=1)
#
#         with tf.variable_scope("context_cls"):
#             wp = tf.get_variable("context_wp", shape=(1, feature_dim, self.relationClass))
#             wp = tf.tile(wp, [batch, 1, 1])
#
#             vp = tf.get_variable("context_vp", shape=(1, maskDim, feature_dim, self.relationClass))
#             bias = tf.get_variable("context_bias", shape=(1, self.relationClass))
#             vp = tf.tile(vp, [batch, 1, 1, 1])
#             context = tf.reduce_sum(vp * edge, axis=1)
#             cls = wp + context
#
#             score = tf.reduce_sum(att_visual * cls, axis=1) + bias
#
#             maskScore = slim.fully_connected(WordVector, num_outputs=self.relationClass)
#             score = score+maskScore
#         return score
#
#     def ContextMaskWordAtt_feature(self, unionVisual, wordVector, edgeMask,scope="context_mask_word_att"):
#         """
#         考虑尝试不同来源的信息指导att 权重， mask， word权重加和的方式, 0.539, 有效果
#         """
#         edge = tf.squeeze(self.GetPositionMask(edgeMask), axis=0)
#         maskDim = edge.get_shape()[-1]
#         wordDim = wordVector.get_shape()[-1]
#         feature_dim = unionVisual.get_shape()[-1]
#         batch = tf.shape(unionVisual)[0]
#
#         subjectWordVector, objectWordVector = tf.split(tf.nn.relu(tf.squeeze(wordVector, 0)), 2, axis=0)
#         extra_word = subjectWordVector*objectWordVector
#         extra_feature = tf.concat((extra_word, edge), axis=-1)
#
#
#         edgeFeature = tf.tile(tf.expand_dims(edge, -1), [1, 1, feature_dim])
#         edgeFeature = tf.tile(tf.expand_dims(edgeFeature, -1), [1, 1, 1, self.relationClass])
#
#
#         Word = tf.reshape(tf.concat((subjectWordVector, objectWordVector), axis=-1), (-1, wordDim * 2, 1))
#         Word = tf.tile(Word, [1, 1, feature_dim])
#         Word = tf.tile(tf.expand_dims(Word, -1), [1, 1, 1, self.relationClass])
#         with tf.variable_scope(scope):
#             wp = tf.get_variable("context_wp", shape=(1, feature_dim, self.relationClass))
#             wp = tf.tile(wp, [batch, 1, 1])
#
#             vp = tf.get_variable("mask_context_vp", shape=(1, maskDim, feature_dim, self.relationClass))
#             vp = tf.tile(vp, [batch, 1, 1, 1])
#             maskContext = tf.reduce_sum(vp * edgeFeature, axis=1)
#
#             vp = tf.get_variable("word_context_vp", shape=(1, wordDim*2, feature_dim, self.relationClass))
#             vp = tf.tile(vp, [batch, 1, 1, 1])
#             wordContext = tf.reduce_sum(vp * Word, axis=1)
#
#             cls = wp + maskContext + wordContext
#             weight, height = unionVisual.get_shape()[1:3]
#             # x: batch, weight, height, channel
#             # cls: batch, channel, classes
#             visual = tf.tile(tf.expand_dims(unionVisual, -1), [1, 1, 1, 1, self.relationClass])
#             cls = tf.tile(tf.expand_dims(cls, 1), [1, weight, 1, 1])
#             cls = tf.tile(tf.expand_dims(cls, 2), [1, 1, height, 1, 1])
#             attention_map = tf.reduce_sum(cls * visual, axis=3)
#             w_a = tf.get_variable("w_a", shape=[weight, height, self.relationClass],
#                                   initializer=tf.random_uniform_initializer(minval=0, maxval=1))
#             w_a = tf.tile(tf.expand_dims(w_a, axis=0), [batch, 1, 1, 1])
#             attention_numerator = tf.nn.softplus(attention_map) + w_a
#             attention_dominator = tf.reduce_sum(tf.reduce_sum(attention_numerator, axis=2), axis=1)
#             attention_final = attention_numerator / tf.expand_dims(tf.expand_dims(attention_dominator, axis=1), axis=2)
#             attention_final = tf.expand_dims(attention_final, axis=-2)
#
#             visual = attention_final * visual
#             att_visual = tf.reduce_sum(tf.reduce_sum(visual, axis=2), axis=1)
#
#         with tf.variable_scope("context_cls"):
#             wp = tf.get_variable("context_wp", shape=(1, feature_dim, self.relationClass))
#             wp = tf.tile(wp, [batch, 1, 1])
#
#             vp = tf.get_variable("mask_context_vp", shape=(1, maskDim, feature_dim, self.relationClass))
#             bias = tf.get_variable("context_bias", shape=(1, self.relationClass))
#             vp = tf.tile(vp, [batch, 1, 1, 1])
#             maskContext = tf.reduce_sum(vp * edgeFeature, axis=1)
#
#             vp = tf.get_variable("word_context_vp", shape=(1, wordDim * 2, feature_dim, self.relationClass))
#             vp = tf.tile(vp, [batch, 1, 1, 1])
#             wordContext = tf.reduce_sum(vp * Word, axis=1)
#
#             cls = wp + maskContext + wordContext
#
#             score = tf.reduce_sum(att_visual * cls, axis=1) + bias
#
#             maskScore = slim.fully_connected(extra_feature, num_outputs=self.relationClass)
#             score = score + maskScore
#         return score
#
#     def ContextMaskWordAtt_weight(self, unionVisual, wordVector, edgeMask, scope="context_mask_word_att"):
#         """
#         考虑尝试不同来源的信息指导att 权重， mask， word权重加和的方式, 0.533->0.539，有效果
#         """
#         edge = tf.squeeze(self.GetPositionMask(edgeMask), axis=0)
#         subjectWordVector, objectWordVector = tf.split(tf.nn.relu(tf.squeeze(wordVector, 0)), 2, axis=0)
#         extraFeature = tf.concat((subjectWordVector*objectWordVector, edge), axis=-1)
#
#         maskDim = edge.get_shape()[-1]
#         wordDim = wordVector.get_shape()[-1]
#         feature_dim = unionVisual.get_shape()[-1]
#         batch = tf.shape(unionVisual)[0]
#         edgeFeature = tf.tile(tf.expand_dims(edge, -1), [1, 1, feature_dim])
#         edgeFeature = tf.tile(tf.expand_dims(edgeFeature, -1), [1, 1, 1, self.relationClass])
#
#
#         Word = tf.reshape(tf.concat((subjectWordVector, objectWordVector), axis=-1), (-1, wordDim * 2, 1))
#         Word = tf.tile(Word, [1, 1, feature_dim])
#         Word = tf.tile(tf.expand_dims(Word, -1), [1, 1, 1, self.relationClass])
#         with tf.variable_scope(scope):
#             wp = tf.get_variable("context_wp", shape=(1, feature_dim, self.relationClass))
#             wp = tf.tile(wp, [batch, 1, 1])
#
#             vp = tf.get_variable("mask_context_vp", shape=(1, maskDim, feature_dim, self.relationClass))
#             vp = tf.tile(vp, [batch, 1, 1, 1])
#             maskContext = tf.reduce_sum(vp * edgeFeature, axis=1)
#             cls = wp + maskContext
#
#             weight, height = unionVisual.get_shape()[1:3]
#             visual = tf.tile(tf.expand_dims(unionVisual, -1), [1, 1, 1, 1, self.relationClass])
#
#             mask_cls = tf.tile(tf.expand_dims(cls, 1), [1, weight, 1, 1])
#             mask_cls = tf.tile(tf.expand_dims(mask_cls, 2), [1, 1, height, 1, 1])
#             attention_map = tf.reduce_sum(mask_cls * visual, axis=3)
#             w_a = tf.get_variable("mask_w_a", shape=[weight, height, self.relationClass],
#                                   initializer=tf.random_uniform_initializer(minval=0, maxval=1))
#             w_a = tf.tile(tf.expand_dims(w_a, axis=0), [batch, 1, 1, 1])
#             attention_numerator = tf.nn.softplus(attention_map) + w_a
#             attention_dominator = tf.reduce_sum(tf.reduce_sum(attention_numerator, axis=2), axis=1)
#             mask_attention_final = attention_numerator / tf.expand_dims(tf.expand_dims(attention_dominator, axis=1), axis=2)
#             mask_attention_final = tf.expand_dims(mask_attention_final, axis=-2)
#
#             vp = tf.get_variable("word_context_vp", shape=(1, wordDim * 2, feature_dim, self.relationClass))
#             vp = tf.tile(vp, [batch, 1, 1, 1])
#             wordContext = tf.reduce_sum(vp * Word, axis=1)
#
#             word_cls = wp + wordContext
#             word_cls = tf.tile(tf.expand_dims(word_cls, 1), [1, weight, 1, 1])
#             word_cls = tf.tile(tf.expand_dims(word_cls, 2), [1, 1, height, 1, 1])
#             attention_map = tf.reduce_sum(word_cls * visual, axis=3)
#             w_a = tf.get_variable("word_w_a", shape=[weight, height, self.relationClass],
#                                   initializer=tf.random_uniform_initializer(minval=0, maxval=1))
#             w_a = tf.tile(tf.expand_dims(w_a, axis=0), [batch, 1, 1, 1])
#             attention_numerator = tf.nn.softplus(attention_map) + w_a
#             attention_dominator = tf.reduce_sum(tf.reduce_sum(attention_numerator, axis=2), axis=1)
#             word_attention_final = attention_numerator / tf.expand_dims(tf.expand_dims(attention_dominator, axis=1), axis=2)
#             word_attention_final = tf.expand_dims(word_attention_final, axis=-2)
#             # x: batch, weight, height, channel
#             # cls: batch, channel, classes
#             rate = 0.8
#             attention_final = rate*word_attention_final + (1-rate)*mask_attention_final
#             visual = attention_final * visual
#             att_visual = tf.reduce_sum(tf.reduce_sum(visual, axis=2), axis=1)
#
#         with tf.variable_scope("context_cls"):
#             wp = tf.get_variable("context_wp", shape=(1, feature_dim, self.relationClass))
#             wp = tf.tile(wp, [batch, 1, 1])
#
#             vp = tf.get_variable("mask_context_vp", shape=(1, maskDim, feature_dim, self.relationClass))
#             bias = tf.get_variable("context_bias", shape=(1, self.relationClass))
#             vp = tf.tile(vp, [batch, 1, 1, 1])
#             maskContext = tf.reduce_sum(vp * edgeFeature, axis=1)
#
#             vp = tf.get_variable("word_context_vp", shape=(1, wordDim * 2, feature_dim, self.relationClass))
#             vp = tf.tile(vp, [batch, 1, 1, 1])
#             wordContext = tf.reduce_sum(vp * Word, axis=1)
#
#             cls = wp + maskContext + wordContext
#
#             score = tf.reduce_sum(att_visual * cls, axis=1) + bias
#
#             maskScore = slim.fully_connected(extraFeature, num_outputs=self.relationClass)
#             score = score + maskScore
#         return score
#
#     def getSpatialSemantic(self, wordVector, maskSub, maskObj):
#         # wordVec [batch, 300]
#         wordDim = wordVector.get_shape()[-1]
#         subjectWordVector, objectWordVector = tf.split(tf.squeeze(wordVector, 0), 2, axis=0)
#         subjectWordVector = tf.reshape(subjectWordVector, [-1, 1, 1, wordDim])
#         objectWordVector = tf.reshape(objectWordVector, [-1, 1, 1, wordDim])
#         maskSub = tf.expand_dims(maskSub, -1)
#         maskObj = tf.expand_dims(maskObj, -1)
#         subVec = subjectWordVector*maskSub
#         objVec = objectWordVector*maskObj
#         # subVec/objVec: batch*32*32*300
#         edgeVec = tf.concat((subVec, objVec), axis=0)
#         with slim.arg_scope([slim.conv2d, slim.fully_connected],
#                                 activation_fn=tf.nn.crelu,):
#                                 # normalizer_fn=slim.batch_norm,
#                                 # normalizer_params={'is_training': self.IsTraining, 'decay': 0.95}):
#             conv1 = slim.conv2d(edgeVec, 256, 3, stride=1,scope='conv1')
#             pool1 = slim.max_pool2d(conv1, 3, stride=2, scope='pool1')
#             conv2 = slim.conv2d(pool1, 512, 3, stride=1, scope='conv2')
#             pool2 = slim.max_pool2d(conv2, 3, stride=2, scope='pool2')
#             conv3 = slim.conv2d(pool2, num_outputs=512, kernel_size=3,scope="conv3")
#         with tf.variable_scope("attention"):
#             confidence = slim.conv2d(conv3, num_outputs=1024, kernel_size=1)
#             confidence = tf.nn.sigmoid(confidence)
#         spatial = confidence*conv3
#         subFeature, objFeature = tf.split(tf.reduce_sum(spatial,[1, 2]), 2, axis=0)
#         subFeature = self.high_way(subFeature, 1024, name="sub")
#         objFeature = self.high_way(objFeature, 1024, name="obj")
#         return subFeature, objFeature
#
#     def semanticFeature(self, Imgs, reuse=False, gpu="/gpu:1", is_training=False):
#         net, endpoints, feature = vgg_16(Imgs, num_classes=None, is_training=self.IsTraining, scope="semanticVgg")
#         out = cnnGate(feature)
#         with tf.variable_scope('semanticVgg', reuse=True):
#             # Use conv2d instead of fully_connected layers.
#             out = slim.conv2d(out, 4096, [7, 7], padding="VALID", scope='fc6')
#             out = slim.dropout(out, 0.5, is_training=self.IsTraining,
#                                scope='dropout6')
#             out = slim.conv2d(out, 4096, [1, 1], scope='fc7')
#         VectorDim = out.get_shape()[-1]
#         out = tf.reshape(out, (-1, VectorDim))
#         # out = tf.concat((x_h, out), axis=-1)
#         # # Use conv2d instead of fully_connected layers.
#         # out = slim.conv2d(out, 4096, [7, 7], padding="VALID", scope='fc6')
#         # out = slim.dropout(out, 0.5, is_training=self.IsTraining,
#         #                    scope='dropout6')
#         # out = slim.conv2d(out, 4096, [1, 1], scope='fc7')
#         # VectorDim = out.get_shape()[-1]
#         # out = tf.reshape(out, (-1, VectorDim))
#         return out
#     # def GetPositionMask(self, Positions, name="binary_mask"):
#     #     # two binary mask [None, 32,32, 2]
#     #     # 8.24添加，未服务器运行
#     #     spatial = Positions
#     #     with tf.variable_scope(name):
#     #         conv1 = slim.conv2d(spatial, num_outputs=256, kernel_size=3, stride=1, padding='SAME', scope="conv1")
#     #         pool1 = slim.max_pool2d(conv1, kernel_size=3, stride=2)
#     #         conv2 = slim.conv2d(pool1, num_outputs=512, kernel_size=3, stride=1, padding="SAME", scope="conv2")
#     #         pool2 = slim.max_pool2d(conv2, kernel_size=3, stride=2)
#     #         conv3 = slim.conv2d(pool2, num_outputs=1024, kernel_size=3, stride=1, padding="VALID", scope="conv3")
#     #         spatial_feature = tf.reduce_mean(conv3, [1, 2])
#     #         spatial_feature = slim.fully_connected(spatial_feature, num_outputs=self.relationClass)
#     #     # with slim.arg_scope([slim.conv2d, slim.fully_connected],
#     #     #                     activation_fn=tf.nn.crelu,
#     #     #                     normalizer_fn=slim.batch_norm,
#     #     #                     normalizer_params={'is_training': self.IsTraining, 'decay': 0.95}):
#     #     #     conv1 = slim.conv2d(spatial, 256, 3, stride=1,scope='conv1')
#     #     #     pool1 = slim.max_pool2d(conv1, 3, stride=2,scope='pool1')
#     #     #     conv2 = slim.conv2d(pool1, 512, 3, stride=1, scope='conv2')
#     #     #     pool2 = slim.max_pool2d(conv2, 3, stride=2, scope='pool2')
#     #     #     conv3 = slim.conv2d(pool2, 832, 3, stride=1, scope="conv3")
#     #     #     spatial_feature = tf.reduce_mean(conv3, [1, 2])
#     #     # spatial_feature = slim.fully_connected(spatial_feature, num_outputs=self.relationClass)
#     #     print(spatial_feature)
#     #     return spatial_feature
#     def TrainTest(self, TrainData, resnet_model_path, TestData, Error=True, teacher=False, epoch=10, isSemantic=False):
#         BatchSize = TrainData.Batch
#         loss, accuracy, train_step, EdgeScore = self.GetArch(BatchSize=BatchSize, teacher=teacher, isSemantic=isSemantic)
#         saver_restore, saver = self.GetSaver()
#
#         if isSemantic is True:
#             semantic_restore,_ = self.GetSaver(name="semantic")
#             print("get semantic restore var")
#         semanticPath = os.path.join("ckpt", "Semantic_segmentation_vgg", "Semantic_segmentation_vgg")
#         config = tf.ConfigProto(allow_soft_placement=True)
#         config.gpu_options.per_process_gpu_memory_fraction = 0.95
#         init = tf.global_variables_initializer()
#         with tf.Session(config=config) as sess:
#             sess.run(init)
#             # Load the pretrained checkpoint file xxx.ckpt
#             saver_restore.restore(sess, resnet_model_path)
#             if isSemantic is True:
#                 semantic_restore.restore(sess, semanticPath)
#                 print("restroe from the semantic ckpt")
#             Acc = []
#             for i in range(epoch):
#                 train = TrainData.getNext(teacher=teacher)
#                 test = TestData.getNext(teacher=teacher)
#                 TestData.Length = []
#                 TrainStep = 0
#                 for temp_train in train:
#                     if teacher:
#                         inter, union, subject, objects, subLabel, objLabel, rel, teacherInput, spatial = temp_train
#                         # subMask = TrainData.getSemanticMask(subject[1], subLabel)
#                         # objMask = TrainData.getSemanticMask(objects[1], objLabel)
#                         TrainDict = {
#                             self.subjectImg:subject[0],
#                             self.subjectMask:subject[1],
#                             self.subjectLabel:subLabel,
#                             self.spatial:spatial,
#                             self.objectImg:objects[0],
#                             self.objectMask:objects[1],
#                             self.objectLabel:objLabel,
#
#                             self.unionImg:union[0],
#                             self.unionMask:union[1],
#                             self.RelationClass:rel,
#                             self.IsTraining: True,
#                             self.TeacherInput: teacherInput,
#
#                         }
#                     else:
#                         inter, union, subject, objects, subLabel, objLabel, rel, spatial = temp_train
#                         # subMask = TrainData.getSemanticMask(subject[1], subLabel)
#                         # objMask = TrainData.getSemanticMask(objects[1], objLabel)
#                         TrainDict = {
#                             self.subjectImg: subject[0],
#                             self.subjectMask: subject[1],
#                             self.subjectLabel: subLabel,
#                             self.spatial: spatial,
#                             self.objectImg: objects[0],
#                             self.objectMask: objects[1],
#                             self.objectLabel: objLabel,
#
#                             self.RelationClass: rel,
#                             self.unionImg: union[0],
#                             self.unionMask: union[1],
#
#                             self.IsTraining: True}
#                     if TrainStep > 500 or i >= 0:
#                         TrainDict[self.a] = 0.5
#                     else:
#                         TrainDict[self.a] = 1.0
#                     try:
#                         sess.run(train_step, feed_dict=TrainDict)
#                         TrainLoss, TrainAcc = sess.run([loss, accuracy], feed_dict=TrainDict)
#                     except Exception as e:
#                         print("running error")
#                         feedDict1, feedDict2 = self.split(TrainDict)
#                         sess.run(train_step, feed_dict=feedDict1)
#                         sess.run(train_step, feed_dict=feedDict2)
#                         TrainLoss, TrainAcc = sess.run([loss, accuracy], feed_dict=feedDict2)
#
#                     Acc.append(TrainAcc)
#                     if TrainStep % 100 == 0:
#                         TrainResult = "train step:{0}, loss:{1}, acc:{2}".format(TrainStep, TrainLoss,
#                                                                                  sum(Acc) / Acc.__len__())
#                         Acc = []
#                         print(TrainResult)
#                     TrainStep += 1
#                 EvalTest = EvalRecall()
#                 EvalAll = EvalRecall()
#                 evalTest = EvalRecallUnion()
#                 if Error and isinstance(Error, str):
#                     error = ErrorAnalysis(i, startPath=Error)
#                 Acc = []
#                 testImgName = (i for i in TestData.ImgName)
#                 for temp_test in test:
#                     if teacher is True:
#                         inter, union, subject, objects, subLabel, objLabel, rel, teacherInput, spatial = temp_test
#                         # subMask = TrainData.getSemanticMask(subject[1], subLabel)
#                         # objMask = TrainData.getSemanticMask(objects[1], objLabel)
#                         feedDict = {
#                             self.subjectImg: subject[0],
#                             self.subjectMask: subject[1],
#                             self.subjectLabel: subLabel,
#                             self.spatial:spatial,
#                             self.objectImg: objects[0],
#                             self.objectMask: objects[1],
#                             self.objectLabel: objLabel,
#                             self.TeacherInput: teacherInput,
#                             self.unionImg: union[0],
#                             self.unionMask: union[1],
#                             self.RelationClass: rel,
#                             self.IsTraining: True}
#                     else:
#                         inter, union, subject, objects, subLabel, objLabel, rel, spatial = temp_test
#                         # subMask = TrainData.getSemanticMask(subject[1], subLabel)
#                         # objMask = TrainData.getSemanticMask(objects[1], objLabel)
#                         feedDict = {
#                             self.subjectImg: subject[0],
#                             self.subjectMask: subject[1],
#                             self.subjectLabel: subLabel,
#                             self.spatial: spatial,
#                             self.objectImg: objects[0],
#                             self.objectMask: objects[1],
#                             self.objectLabel: objLabel,
#
#                             self.unionImg: union[0],
#                             self.unionMask: union[1],
#                             self.RelationClass: rel,
#                             self.IsTraining: True}
#                     # TrainLoss, TrainAcc = sess.run([loss, accuracy], feed_dict=TrainDict)
#                     # Acc.append(TrainAcc)
#                     # Score, index = sess.run([EdgeScore, EdgeIndex], feed_dict=feedDict)
#                     Score = sess.run(EdgeScore, feed_dict=feedDict)
#                     evalTest.add(rel, Score, subLabel, objLabel, subject[-1], objects[-1])
#                     # Triad, TestRelationScore, candidate = self.GetPredict(Score, index)
#                     # print("Truth Relation:",Relation[0])
#                     # print("Triad:", Triad)
#                     # print("Score:", TestRelationScore)
#                     # pdb.set_trace()
#
#                     # EvalTest.add(relation, Triad, TestRelationScore)
#                     # if Error:
#                     #     error.add(originalName, SubImgs[0], ImgLabel[0], relation, Triad)
#                     # EvalAll.add(Relation[0], candidate, TestRelationScore)
#                 # print("test set acc:", sum(Acc) / Acc.__len__())
#                 evalTest.eval(TestData.Length)
#                 evalTest.show()
#                 if Error:
#                     error.write()

class VisualGenerate(VisualTransE):
    def __init__(self):
        VisualTransE.__init__(self)
        self.z = tf.placeholder(tf.float32, [None, 128])
        self.weightOriginal = tf.placeholder(tf.float32, [None,])

    def getWordVector(self, Object, path=None):
        with tf.variable_scope("Word2Vec"):
            LoadPath = path if path else os.path.join("dataset", "InitEmbedding.npy")
            init = tf.constant(np.load(LoadPath), dtype=tf.float32)
            ObjectEmbedding = tf.get_variable("ObjectEmbedding", initializer=init, trainable=True)
            Vectors = tf.nn.embedding_lookup(ObjectEmbedding, Object)
            VectorsDim = Vectors.get_shape()[-1]
        print("get word vector and shape is:", Vectors.get_shape())
        sub, obj = tf.split(Vectors, 2, axis=0)
        return sub, obj

    def getGenerate(self,edgeVector, subWordVector, objWordVector,isTrainable=False):
        objectClass = tf.concat((self.subjectLabel, self.objectLabel), axis=0)
        subWord, objWord = self.getWordVector(objectClass)
        featureVector = tf.concat((subWord, objWord, edgeVector),axis=-1)
        # subVector = tf.concat((subWord, edgeVector), axis=-1)
        # objVector = tf.concat((objWord, edgeVector), axis=-1)
        # featureVector = tf.concat((subVector, objVector), axis=0)
        noise = tf.concat([self.z, featureVector], axis=1)
        with tf.variable_scope("generator"):
            net = slim.fully_connected(noise, 1024, activation_fn=tf.nn.leaky_relu, scope="gen_fc1", trainable=isTrainable)
            net = slim.fully_connected(net, 450, activation_fn=tf.nn.leaky_relu, scope="gen_fc2", trainable=isTrainable)
        # subVisual, objVisual = tf.split(net, 2, axis=0)
        # return subVisual, objVisual
        # with tf.variable_scope("predicate"):
        #     subVector = subVisual * subWordVector
        #     objVector = objVisual * objWordVector
        #     edge = slim.fully_connected(subVector - objVector, 450, scope="feature", trainable=isTrainable)
        #     edgeFeature = tf.concat((edge, edgeVector), axis=-1)
        #     score = slim.fully_connected(edgeFeature, num_outputs=self.relationClass, trainable=isTrainable)
        #     EdgeScore = tf.nn.softmax(score, dim=-1)
        # return score, EdgeScore
        return net

    def getGenerateParams(self):
        # params = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, scope='generator')
        params = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope='generator')
        restoreGenerate = tf.train.Saver(var_list=params)

        predicateParams = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope='predicate')
        restorePredicate = tf.train.Saver(var_list=predicateParams)
        originalParams = [i for i in tf.trainable_variables() if i not in params and i.name !="Word2Vec/ObjectEmbedding:0"]
        restoreGlobal = tf.train.Saver(var_list=originalParams)
        return restoreGenerate, restoreGlobal, restorePredicate

    def getArch(self):
        # 将visual feature 和gan 生成的feature 拼在一起，然后训练最佳0.5103/0.1755
        # 看来简单的拼接并不是有效的融合方式
        Img = tf.concat((self.subjectImg, self.objectImg), axis=0)
        unionVisual = self.GetVisualFeature(Img)
        unionVisual = tf.squeeze(unionVisual, 0) if unionVisual.get_shape()[0] == 1 else unionVisual
        subVisual, objVisual = tf.split(unionVisual, 2, axis=0)
        # spatial vector
        with tf.variable_scope("visual"):
            featureDim = 450
            subVisual = slim.fully_connected(subVisual, featureDim)
            objVisual = slim.fully_connected(objVisual, featureDim)

        with tf.variable_scope("word2mask"):
            objectClass = tf.concat((self.subjectLabel, self.objectLabel), axis=0)
            # WordVector = tf.squeeze(self.GetWordVector(objectClass), axis=0)
            WordVector = tf.one_hot(objectClass, depth=self.relationClass)
            subjectWordVector, objectWordVector = tf.split(WordVector, 2, axis=0)
            # subjectWordVector = slim.fully_connected(subjectWordVector, 2*featureDim)
            # objectWordVector = slim.fully_connected(objectWordVector, 2*featureDim)
            subjectWordVector = slim.fully_connected(subjectWordVector, featureDim)
            objectWordVector = slim.fully_connected(objectWordVector, featureDim)

        with tf.variable_scope("spatial"):
            edgeMask = self.spatial
            edgeVector = slim.fully_connected(edgeMask, 20)
            edgeVector = slim.fully_connected(edgeVector, 50)

        # get generate feature from gan network
        # subVisualGenerate, objVisualGenerate = self.getGenerate(edgeVector, subjectWordVector, objectWordVector)
        generateVector = self.getGenerate(edgeVector, subjectWordVector, objectWordVector)
        generateEdge, generateEdgeScore = self.classificationLayer(subVisual - objVisual, generateVector, edgeVector)
        # generate wordVector concat in 0.5227/0.2053
        #add in edge para 0.0: 0.506; 1.0: 0.505; 0.2:0.514; 0.5: 0.510
        #add in edgeScore: 0.5: 0.45
        # para = 0.9
        with tf.variable_scope("edgeFeature"):
            # from generate visual feature get
            # subVisualVector = tf.concat((subVisual, subVisualGenerate), axis=-1)
            # objVisualVector = tf.concat((objVisual, objVisualGenerate), axis=-1)
            #
            # subVec = subVisualVector*subjectWordVector
            # objVec = objVisualVector*objectWordVector

            # from generate visualVector get
            subVec = subVisual*subjectWordVector
            objVec = objVisual*objectWordVector
            # subVec = tf.concat((subVec, subVisualGenerate), axis=-1)
            # objVec = tf.concat((objVec, objVisualGenerate), axis=-1)
            #
            # # get edgeVec
            # edgeVec = slim.fully_connected(subVec-objVec, featureDim)
            # original = subVisual*subjectWordVector - objVisual*objectWordVector
            # edgeVec = tf.concat((original, generate), axis=-1)
            # edgeVec = tf.concat((visual*vector, visual*generateVector), axis=-1)
            edgeVec = subVec - objVec
            # edgeVec = edgeVec*self.weightPair + (1-self.weightPair)*generateVector
            # feature = tf.concat((edgeVec, (subVisual-objVisual)*generateVector,edgeVector), axis=-1)
            feature = tf.concat((edgeVec,edgeVector), axis=-1)
            originalEdge = slim.fully_connected(feature, self.relationClass)
            edge = originalEdge
            EdgeScore = tf.nn.softmax(edge, dim=-1)# *para + generateEdgeScore*(1-para)
            EdgeScore = EdgeScore*tf.expand_dims(self.weightOriginal, -1) + tf.expand_dims(1-self.weightOriginal, -1)*generateEdgeScore
        edgeLoss = None
        loss, accuracy, train_step = self.GetOptimizer(edge, self.RelationClass, maskFeature=edgeLoss)
        return loss, accuracy, train_step, EdgeScore

    def classificationLayer(self, visual, gan_res, edgeVector, classLabel=None, name="predicate", reuse=False, isTrainable=False):
        with tf.variable_scope(name, reuse=reuse) as scope:
            # 先差再乘
            # edge = slim.fully_connected(visual*gan_res, 450, scope="feature", trainable=isTrainable)
            edge = visual*gan_res
            edgeFeature = tf.concat((edge, edgeVector), axis=-1)
            score = slim.fully_connected(edgeFeature, num_outputs=self.relationClass, trainable=isTrainable)
            EdgeScore = tf.nn.softmax(score, dim=-1)
        return score, EdgeScore

    def GetOptimizer(self, logits, labels, Teacher=True, alpha=0.5, maskFeature=None):
        edgeLabel = labels
        edgeLosses = tf.nn.softmax_cross_entropy_with_logits(
                     labels=tf.one_hot(edgeLabel, depth=self.relationClass), logits=logits)
        losses = edgeLosses # + maskLosses + actionLosses
        optimizer = tf.train.AdamOptimizer(learning_rate=self.learning_rate)
        if maskFeature is not None:
            losses += maskFeature
            maskLoss = tf.reduce_mean(maskFeature)
            print("add extra loss")
        else:
            maskLoss = tf.reduce_mean(tf.zeros_like(losses))
        logits = tf.nn.softmax(logits)
        classes = tf.argmax(logits, axis=1, name='classes')
        accuracy = tf.reduce_mean(tf.cast(
            tf.equal(tf.cast(classes, dtype=tf.int32), edgeLabel), dtype=tf.float32))
        loss = tf.reduce_mean(losses)
        train_step = slim.learning.create_train_op(loss, optimizer)#, variables_to_train=var_list)
        # # use different lr
        # varRel = [i for i in tf.trainable_variables() if "rel2Vec/relEmbedding" in i.name]
        # varList = [i for i in tf.trainable_variables() if "rel2Vec/relEmbedding" not in i.name]
        # # 0.05/0.04时最佳0.516, 可以哟；0.01时，为0.512；0.005时，为0.506，
        # # 0.03时为0.510；0.07时为0.514; 0.09时,为0.510;
        # lr = 0.05
        # optimizerRel = tf.train.AdamOptimizer(lr)
        # grads = tf.gradients(loss, varList + varRel)
        # grads1 = grads[:len(varList)]
        # grads2 = grads[len(varList):]
        # train_op1 = optimizer.apply_gradients(zip(grads1, varList))
        # train_op2 = optimizerRel.apply_gradients(zip(grads2, varRel))
        # train_step = tf.group(train_op1, train_op2)
        return [loss, maskLoss], accuracy, train_step

    def TrainTest(self, TrainData, resnet_model_path, generateRestore,TestData,Error=True, epoch=10, save=True):
        BatchSize = TrainData.Batch
        def floatShow(a, b=5):
            a = str(a)
            return a[:b]
        loss, accuracy, train_step, EdgeScore = self.getArch()
        saver_restore, saver = self.GetSaver()
        generateParams, globalParams, predicateParams = self.getGenerateParams()
        saveParams = tf.train.Saver()
        config = tf.ConfigProto(allow_soft_placement=True)
        config.gpu_options.per_process_gpu_memory_fraction = 0.95
        init = tf.global_variables_initializer()
        bestRecall = 0.0
        # path = os.path.join("dataset", "relWeight.npy")
        # relWeight = np.load(path).item()
        pairWeight = np.load(os.path.join("dataset", "testPair.npy")).item()
        with tf.Session(config=config) as sess:
            sess.run(init)
            # restore the generate
            generateParams.restore(sess, generateRestore)
            predicateParams.restore(sess, os.path.join("ckpt", "visual", "predicate", "predicate"))
            saver_restore.restore(sess, resnet_model_path)
            Acc = []
            for i in range(epoch):
                train = TrainData.getNext()
                test = TestData.getNext()
                TestData.Length = []
                TrainStep = 0
                for temp_train in train:
                    inter, union, subject, objects, subLabel, objLabel, rel, spatial, imgName = temp_train
                    # simRelations, disSimRelations, disSimRelationScore = relSim.each(rel, num=negative)
                    batch_z = np.random.normal(0, 1, [BatchSize, 128]).astype(np.float32)
                    tempWeight = [pairWeight.get((sub, obj), 0) for sub, obj in zip(subLabel, objLabel)]
                    TrainDict = {
                            self.subjectImg: subject[0],
                            self.subjectMask: subject[1],
                            self.subjectLabel: subLabel,
                            self.spatial: spatial,
                            self.objectImg: objects[0],
                            self.objectMask: objects[1],
                            self.objectLabel: objLabel,

                            self.RelationClass: rel,
                            self.unionImg: union[0],
                            self.unionMask: union[1],

                            self.z:batch_z,
                            self.weightOriginal:tempWeight,
                            # self.relWeight: [relWeight.get(i, 0.0) for i in rel],
                            self.IsTraining: True}
                    if TrainStep > 500 or i >= 0:
                        TrainDict[self.a] = 0.5
                    else:
                        TrainDict[self.a] = 1.0
                    sess.run(train_step, feed_dict=TrainDict)
                    TrainLoss, TrainAcc = sess.run([loss, accuracy], feed_dict=TrainDict)
                    Acc.append(TrainAcc)
                    if TrainStep % 100 == 0:
                        TrainResult = "train step:{0}, all loss:{1}, extra loss:{3},acc:{2}".format(TrainStep, TrainLoss[0],
                                                                              sum(Acc) / Acc.__len__(), floatShow(TrainLoss[1]))
                        Acc = []
                        print(TrainResult)
                    TrainStep += 1
                evalTest = EvalRecallUnion()
                if Error and isinstance(Error, str):
                    error = ErrorAnalysis(i, startPath=Error)
                Acc = []
                testImgName = (i for i in TestData.ImgName)
                # testFeature = []
                for temp_test in test:
                    inter, union, subject, objects, subLabel, objLabel, rel, spatial, imgName = temp_test
                    # simRelations, disSimRelations, disSimRelationScore = relSim.each(rel, num=negative)
                    batch_z = np.random.normal(0, 1, [BatchSize, 128]).astype(np.float32)
                    tempWeight = [pairWeight.get((sub, obj), 0) for sub, obj in zip(subLabel, objLabel)]
                    feedDict = {
                            self.subjectImg: subject[0],
                            self.subjectMask: subject[1],
                            self.subjectLabel: subLabel,
                            self.spatial: spatial,
                            self.objectImg: objects[0],
                            self.objectMask: objects[1],
                            self.objectLabel: objLabel,

                            self.unionImg: union[0],
                            self.unionMask: union[1],
                            self.RelationClass: rel,
                            self.weightOriginal: tempWeight,

                            self.z:batch_z,
                            self.IsTraining: False}
                    Score = sess.run(EdgeScore, feed_dict=feedDict)
                    evalTest.add(rel, Score, subLabel, objLabel, subject[-1], objects[-1])
                evalTest.eval(TestData.Length)
                evalTest.show()
                # save the best model
                testRecall = evalTest.getRecall()
                if testRecall > bestRecall and save and testRecall>0.523:
                    time = datetime.datetime.now().strftime("%Y-%m-%d--%H:%M:%S")
                    bestRecall = testRecall
                    path = os.path.join("ckpt", "visual", time)
                    if not os.path.exists(path):
                        os.makedirs(path)
                    savePath = os.path.join(path, "transE")
                    # np.save(savePath, testFeature)
                    saveParams.save(sess, savePath)
                    print(time)
                if Error:
                    error.write()

    def testVisual(self, testData, restore, generateRestorePath,trainData, predicatePath,BatchSize=16):
        loss, accuracy, train_step, EdgeScore = self.getArch()
        # generateParams, globalParams, predicateParams = self.getGenerateParams()
        generateParams, globalParams = self.getGenerateParams()
        saver = tf.train.Saver()
        config = tf.ConfigProto(allow_soft_placement=True)
        config.gpu_options.per_process_gpu_memory_fraction = 0.95
        init = tf.global_variables_initializer()
        with tf.Session(config=config) as sess:
            sess.run(init)
            # Load the pretrained checkpoint file xxx.ckpt
            generateParams.restore(sess, generateRestorePath)
            # predicateParams.restore(sess, predicatePath)
            globalParams.restore(sess, restore)
            test = testData.getNext()
            train = trainData.getNext()
            testData.Length = []
            evalTest = EvalRecallUnion()
            for temp_test in test:
                inter, union, subject, objects, subLabel, objLabel, rel, spatial,imgName = temp_test
                batch_z = np.random.normal(0, 1, [BatchSize, 128]).astype(np.float32)
                feedDict = {
                    self.subjectImg: subject[0],
                    self.subjectMask: subject[1],
                    self.subjectLabel: subLabel,
                    self.spatial: spatial,
                    self.objectImg: objects[0],
                    self.objectMask: objects[1],
                    self.objectLabel: objLabel,
                    self.unionImg: union[0],
                    self.unionMask: union[1],
                    self.RelationClass: rel,
                    self.z:batch_z,
                    self.IsTraining: False}
                # Score = sess.run(EdgeScore, feed_dict=feedDict)
                Score = sess.run(EdgeScore, feed_dict=feedDict)
                evalTest.add(rel, Score, subLabel, objLabel, subject[-1], objects[-1])
            evalTest.eval(testData.Length)
            evalTest.show()
            return None

if __name__ == "__main__":
    batch = 16
    TrainMat = "annotations_train.json"
    train_data = UnionData(TrainMat, "sg_train_images", batch=batch)
    # reStorePath = os.path.join("ckpt", "visual", "baseline--0.505", "transE")
    reStorePath = os.path.join("ckpt", "Vgg", "vrd")
    # generateRestorePath = os.path.join("ckpt", "visual", "generate--0.168--不能删", "embedding")
    generateRestorePath = os.path.join("ckpt", "visual", "embedding", "embedding")
    # generateRestorePath = os.path.join("ckpt", "visual", "generate--withVIsualxVector--0.442", "embedding")
    TestMat = "annotations_test.json"
    test_data = UnionData(TestMat, "sg_test_images", batch=batch)
    StorePath = os.path.join("ckpt", "Vrd", "vrd")
    predicatePath = os.path.join("ckpt", "visual", "predicate", "predicate")
    Res = VisualGenerate()
    Res.TrainTest(train_data, reStorePath, generateRestorePath, test_data, Error=False, epoch=10)
    # Res.testVisual(test_data, reStorePath, generateRestorePath, train_data, predicatePath)