import tensorflow as tf
import numpy as np
from configparser import ConfigParser
import os
import pdb
from layer import *
import time
from EvalRecall import ErrorAnalysis
from VIsualModel import vgg_16
from layer import AlternatingHighWayCell
from MatDRNet import FeatureData, FeatureDataAtt
from VrdTransE import VisualTransE
from EvalRecall import EvalRecallUnion
import tensorflow.contrib.slim as slim
from tensorflow.contrib.slim import nets
from LoadMat import DataLoad
from EvalRecall import EvalRecall
from VrdEmbedding import *
np.set_printoptions(threshold=np.nan)
os.environ["CUDA_VISIBLE_DEVICES"] = "0"

class GAN(object):
    def __init__(self, condition, noise, targetOut, isTrain=True, type="WGAN"):
        self.condition = condition
        self.noise = noise
        self.targetOut = targetOut
        self.type = type
        self.isTrain = isTrain

    @staticmethod
    def mse(pred, data):
        error = tf.reduce_mean(tf.square(pred-data), axis=0, keep_dims=False)
        return tf.sqrt(error)

    def generator(self, x, name="generator", reuse=False, isTrainable=True):
        with tf.variable_scope(name, reuse=reuse) as scope:
            net = slim.fully_connected(x, 1024, activation_fn=tf.nn.leaky_relu, scope="gen_fc1", trainable=isTrainable)
            net = slim.fully_connected(net, 450, activation_fn=tf.nn.leaky_relu, scope="gen_fc2", trainable=isTrainable)
            return net

    def discriminator(self, x, name="discriminator", reuse=False, isTrainable=True):
        with tf.variable_scope(name, reuse=reuse) as scope:
            net = slim.fully_connected(x, 4096, activation_fn=tf.nn.leaky_relu, scope="disc_fc1",trainable=isTrainable)
            real_fake = slim.fully_connected(net, 1, activation_fn=None, scope="disc_rf", trainable=isTrainable)
            action_dis = tf.nn.sigmoid(real_fake)
            dis_logits = tf.reshape(real_fake, [-1])
            dis = tf.reshape(action_dis, [-1])

            return dis_logits, dis

    def discriminator_EBGAN(self, x, name="discriminator", reuse=False, isTrainable=True):
        with tf.variable_scope(name, reuse=reuse) as scope:
            net = slim.fully_connected(x, 512, activation_fn=tf.nn.leaky_relu, scope="disc_fc1",trainable=isTrainable)
            code = slim.fully_connected(net, 32, activation_fn=tf.nn.leaky_relu, scope="disc_fc2", trainable=isTrainable)
            net = slim.fully_connected(code, 512, activation_fn=tf.nn.leaky_relu, scope="disc_fc3", trainable=isTrainable)
            real_fake = slim.fully_connected(net, 750, activation_fn=None, scope="disc_rf", trainable=isTrainable)
            action_dis = tf.nn.sigmoid(real_fake)
            recon_error = tf.reduce_mean(tf.square(action_dis-x), axis=[0, 1])
            return action_dis, tf.sqrt(recon_error), code

    def GanLoss(self, type="WGAN"):
        if type == "WGAN":
            return self.WGAN_GP()
        elif type== "GAN":
            return self.GAN()
        elif type=="LSGAN":
            return self.LSGAN()
        elif type=="BEGAN":
            return self.BEGAN()
        else:
            raise("type Error")

    def WGAN_GP(self):
        condition = self.condition
        noise = self.noise
        targetOut = self.targetOut
        train = self.isTrain
        # generator
        generatorInput = tf.concat([noise, condition], axis=1)
        generatorRes = self.generator(generatorInput)

        # discriminator
        targetEmbd = tf.concat([targetOut, condition], axis=1)
        targetDisc, _ = self.discriminator(targetEmbd, isTrainable=train)
        genTargetEmbd = tf.concat([generatorRes, condition], axis=1)
        genTargetDisc, _ = self.discriminator(genTargetEmbd, isTrainable=train, reuse=True)

        # GAN Loss
        genDiscMean = tf.reduce_mean(genTargetDisc)
        discriminatorLoss = tf.reduce_mean(genTargetDisc - targetDisc)

        alpha = tf.random_uniform(shape=[tf.shape(targetOut)[0], 1], minval=0., maxval=1.)

        interpolates = alpha * targetOut + ((1 - alpha) * generatorRes)
        interpolate = tf.concat([interpolates, condition], axis=1)
        gradients = tf.gradients(self.discriminator(interpolate, reuse=True, isTrainable=train)[0], [interpolates])[0]
        slopes = tf.sqrt(tf.reduce_sum(tf.square(gradients), reduction_indices=[1]))
        gradientPenalty = tf.reduce_mean((slopes - 1.) ** 2)

        gradientPenalty = 10 * gradientPenalty
        discriminatorLoss = discriminatorLoss + gradientPenalty

        genLoss = -genDiscMean
        return discriminatorLoss, genLoss, generatorRes

    def LSGAN(self):
        condition = self.condition
        noise = self.noise
        targetOut = self.targetOut
        train = self.isTrain
        # generator
        generatorInput = tf.concat([noise, condition], axis=1)
        generatorRes = self.generator(generatorInput)

        # discriminator
        targetEmbd = tf.concat([targetOut, condition], axis=1)
        D_real, _ = self.discriminator(targetEmbd, isTrainable=train)
        genTargetEmbd = tf.concat([generatorRes, condition], axis=1)
        D_fake, _ = self.discriminator(genTargetEmbd, isTrainable=train, reuse=True)

        # loss
        d_loss_real = self.mse(D_real, tf.ones_like(D_real))
        d_loss_fake = self.mse(D_fake, tf.zeros_like(D_fake))
        d_loss = 0.5*(d_loss_fake+d_loss_real)

        g_loss = self.mse(D_fake, tf.ones_like(D_fake))
        return d_loss, g_loss, generatorRes

    def GAN(self):
        condition = self.condition
        noise = self.noise
        targetOut = self.targetOut
        train = self.isTrain
        # generator
        generatorInput = tf.concat([noise, condition], axis=1)
        generatorRes = self.generator(generatorInput)

        # discriminator
        targetEmbd = tf.concat([targetOut, condition], axis=1)
        D_real_logits, D_real = self.discriminator(targetEmbd, isTrainable=train)
        genTargetEmbd = tf.concat([generatorRes, condition], axis=1)
        D_fake_logits, D_fake = self.discriminator(genTargetEmbd, isTrainable=train, reuse=True)

        d_loss_real = tf.reduce_mean(
            tf.nn.sigmoid_cross_entropy_with_logits(logits=D_real_logits, labels=tf.ones_like(D_real)))
        d_loss_fake = tf.reduce_mean(
            tf.nn.sigmoid_cross_entropy_with_logits(logits=D_fake_logits, labels=tf.zeros_like(D_fake)))

        d_loss = d_loss_real + d_loss_fake

        # get loss for generator
        g_loss = tf.reduce_mean(
            tf.nn.sigmoid_cross_entropy_with_logits(logits=D_fake_logits, labels=tf.ones_like(D_fake)))
        return d_loss, g_loss, generatorRes

    def BEGAN(self):
        # BEGAN Parameter
        gamma = 0.75
        lamda = 0.001
        k = tf.Variable(0., trainable=False)

        condition = self.condition
        noise = self.noise
        targetOut = self.targetOut
        train = self.isTrain
        # generator
        generatorInput = tf.concat([noise, condition], axis=1)
        generatorRes = self.generator(generatorInput)

        # discriminator
        targetEmbd = tf.concat([targetOut, condition], axis=1)
        D_real_logits, D_real_err, D_real_code = self.discriminator_EBGAN(targetEmbd, isTrainable=train)
        genTargetEmbd = tf.concat([generatorRes, condition], axis=1)
        D_fake_logits, D_fake_err, D_fake_code = self.discriminator_EBGAN(genTargetEmbd, isTrainable=train, reuse=True)

        #loss
        d_loss = D_real_err - k * D_fake_err

        # get loss for generator
        g_loss = D_fake_err

        # convergence metric
        M = D_real_err + tf.abs(gamma * D_real_err - D_fake_err)
        update_k = k.assign(tf.clip_by_value(k + lamda * (gamma * D_real_err - D_fake_err), 0, 1))

        return d_loss, g_loss, generatorRes

class Generate(object):
    def __init__(self):
        self.relationClass = 71
        self.objectClass = 100
        self.lr = 0.0001
        featureDim = 450
        self.featureDim = featureDim
        self.subVisual = tf.placeholder(tf.float32, [None, featureDim])
        self.objVisual = tf.placeholder(tf.float32, [None, featureDim])
        self.subVector = tf.placeholder(tf.float32, [None, featureDim])
        self.objVector = tf.placeholder(tf.float32, [None, featureDim])
        self.subEdgeVector = tf.placeholder(tf.float32, [None, featureDim])
        self.objEdgeVector = tf.placeholder(tf.float32, [None, featureDim])
        self.subLabel = tf.placeholder(tf.int32, [None])
        self.objLabel = tf.placeholder(tf.int32, [None])
        self.spatial = tf.placeholder(tf.float32, [None, 50])
        self.rel = tf.placeholder(tf.int64, [None])
        self.z = tf.placeholder(tf.float32, [None, 128])
        self.context = tf.placeholder(tf.float32, [None, 250])

        self.clsLoss = []

    def classificationLayerAtt(self, gan_res, classes, classLabel=None, name="predicate", reuse=False, isTrainable=True):
        print("classification predicate")
        with tf.variable_scope(name, reuse=reuse) as scope:
            subVector, objVector = tf.split(gan_res, 2, axis=0)
            subVec = self.subVisual*subVector*self.subEdgeVector
            objVec = self.objVisual*objVector*self.objEdgeVector
            edge = slim.fully_connected(subVec - objVec, self.featureDim, scope="feature")
            originalEdge = slim.fully_connected(self.subVisual*self.subVector*self.subEdgeVector-self.objVisual*self.objVector*self.objEdgeVector,
                                                self.featureDim, scope="feature", reuse=True)
            originalFeature = tf.concat((originalEdge, self.spatial), axis=-1)

            edgeFeature = tf.concat((edge, self.spatial), axis=-1)
            score = slim.fully_connected(edgeFeature, num_outputs=self.relationClass)
            originalScore = slim.fully_connected(originalFeature, num_outputs=self.relationClass, scope="fully_connected", reuse=True)
            EdgeScore = tf.nn.softmax(score+originalScore, dim=-1)# + tf.nn.softmax(originalScore, dim=-1)

        return score, EdgeScore, originalScore, tf.nn.softmax(score, dim=-1)

    def getWordVector(self, Object, path=None):
        with tf.variable_scope("Word2Vec"):
            LoadPath = path if path else os.path.join("dataset", "InitEmbedding.npy")
            init = tf.constant(np.load(LoadPath), dtype=tf.float32)
            ObjectEmbedding = tf.get_variable("ObjectEmbedding", initializer=init, trainable=True)
            Vectors = tf.nn.embedding_lookup(ObjectEmbedding, Object)
            VectorsDim = Vectors.get_shape()[-1]
        print("get word vector and shape is:", Vectors.get_shape())
        sub, obj = tf.split(Vectors, 2, axis=0)
        return sub, obj

    def getArchOptimizer(self, ganType="WGAN", batch_size=16, att=None):
        train = True
        objectLabel = tf.concat((self.subLabel, self.objLabel), axis=0)
        subVector, objVector = self.getWordVector(objectLabel)
        condition = tf.concat((subVector, objVector), axis=0)
        targetOut = tf.concat((self.subVector, self.objVector), axis=0)
        noise = self.z

        ganType = ganType
        alpha = 1.0
        # GAN loss
        GANnet = GAN(condition, noise, targetOut, train)
        discriminatorLoss, generateLoss, generatorRes = GANnet.GanLoss(ganType)

        classificationLogits, score, _, generateScore = self.classificationLayerAtt(generatorRes, self.objectClass, objectLabel, isTrainable=False)
        ############ classification loss #########################
        classificationLoss = tf.reduce_mean(
            tf.nn.sparse_softmax_cross_entropy_with_logits(logits=classificationLogits, labels=self.rel))
        self.clsLoss = classificationLoss

        generatorLoss = generateLoss+classificationLoss*alpha
        #################### getting parameters to optimize ####################
        discParams = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, scope='discriminator')
        generatorParams = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, scope='generator')
        for params in discParams:
            print(params.name)
        for params in generatorParams:
            print(params.name)
        # discOptimizer = tf.train.AdamOptimizer(learning_rate=self.lr)
        discOptimizer = tf.train.GradientDescentOptimizer(learning_rate=self.lr)
        # genOptimizer = tf.train.AdamOptimizer(learning_rate=self.lr)
        genOptimizer = tf.train.GradientDescentOptimizer(learning_rate=self.lr)

        discGradsVars = discOptimizer.compute_gradients(discriminatorLoss, var_list=discParams)
        genGradsVars = genOptimizer.compute_gradients(generatorLoss, var_list=generatorParams)
        discTrain = discOptimizer.apply_gradients(discGradsVars)
        generatorTrain = genOptimizer.apply_gradients(genGradsVars)
        return discTrain, generatorTrain, discriminatorLoss, generatorLoss, score, generateScore

    def getRestore(self):
        params = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope='predicate')
        saver = tf.train.Saver(var_list=params)

        generatorParams = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, scope='generator')
        save = tf.train.Saver()
        return saver, save

    def TrainTest(self, trainData, testData, restorePath,Epoch=200, batch=16):
        discTrain, generatorTrain, discriminatorLoss, generatorLoss, EdgeScore, originalScore = self.getArchOptimizer()
        reStore, save = self.getRestore()
        savePath = os.path.join("ckpt", "visual", "embeddingNoSpatial")
        if not os.path.exists(savePath):
            os.makedirs(savePath)
        cytle = 5
        best = 0.0
        bestZero = 0.0
        config = tf.ConfigProto(allow_soft_placement=True)
        config.gpu_options.per_process_gpu_memory_fraction = 0.55
        RecallStore = []
        merged_all = tf.summary.merge_all()
        logdir = os.path.join("result", "record")
        k = 1
        with tf.Session(config=config) as sess:
            sess.run(tf.global_variables_initializer())
            # restore the relation matrix and layer
            reStore.restore(sess, restorePath)
            summary_writer = tf.summary.FileWriter(logdir, sess.graph)
            allDisLoss, allGenLoss = [], []
            for epoch in range(Epoch):
                epochDisLoss, epochGenLoss = [], []
                for i in range(0, trainData.size, batch):
                    tempDisLoss = []
                    for j in range(cytle):
                        batch_subVisual, batch_objVisuals, batch_subVectors, batch_objVectors, \
                        batch_edgeVectors, batch_subLabels, batch_objLabels, batch_rel, z_rand = trainData.next_batch(batch)
                        batch_z = np.random.normal(0, 1, [batch*2, 128]).astype(np.float32)
                        feedDict = {
                            self.subVisual: batch_subVisual,
                            self.objVisual: batch_objVisuals,
                            self.subVector: batch_subVectors,
                            self.objVector: batch_objVectors,
                            self.subLabel: batch_subLabels,
                            self.objLabel: batch_objLabels,
                            self.spatial: batch_edgeVectors,
                            self.rel: batch_rel,
                            self.z:batch_z
                        }
                        _, discLoss, merged = sess.run([discTrain, discriminatorLoss, merged_all],
                                                       feed_dict=feedDict)
                        if j == 0:
                            summary_writer.add_summary(merged, k)
                        tempDisLoss.append(discLoss)
                    epochDisLoss.append(tempDisLoss)
                    batch_subVisual, batch_objVisuals, batch_subVectors, batch_objVectors, \
                    batch_edgeVectors, batch_subLabels, batch_objLabels, batch_rel, z_rand = trainData.next_batch(
                        batch)
                    batch_z = np.random.normal(0, 1, [batch*2, 128]).astype(np.float32)
                    feedDict = {
                        self.subVisual: batch_subVisual,
                        self.objVisual: batch_objVisuals,
                        self.subVector: batch_subVectors,
                        self.objVector: batch_objVectors,
                        self.subLabel: batch_subLabels,
                        self.objLabel: batch_objLabels,
                        self.spatial: batch_edgeVectors,
                        self.rel: batch_rel,
                        self.z:batch_z
                    }
                    _, genLoss, merged = sess.run([generatorTrain, generatorLoss, merged_all], feed_dict=feedDict)
                    summary_writer.add_summary(merged, k)
                    epochGenLoss.append(genLoss)
                    k = k + 1
                allDisLoss.append(epochDisLoss)
                allGenLoss.append(epochGenLoss)
                print("train finish")
                evalTest = EvalRecallUnion()
                subVisuals, objVisuals, subVectors, objVectors, edgeVectors, subLabels, objLabels, rels, values, length = np.load(
                    testData)
                for batch_subVisual, batch_objVisuals, batch_subVectors, batch_objVectors, \
                    batch_edgeVectors, batch_subLabels, batch_objLabels, batch_rel, value \
                        in zip(subVisuals, objVisuals, subVectors, objVectors, edgeVectors, subLabels, objLabels, rels, values):
                    rel, subLabel, objLabel, subject, objects, imgName = value
                    batch_z = np.random.normal(0, 1, [batch*2, 128]).astype(np.float32)
                    feedDict = {
                        self.subVisual: batch_subVisual,
                        self.objVisual: batch_objVisuals,
                        self.subVector: batch_subVectors,
                        self.objVector: batch_objVectors,
                        self.subLabel: batch_subLabels,
                        self.objLabel: batch_objLabels,
                        self.spatial: batch_edgeVectors,
                        self.rel: batch_rel,
                        self.z: batch_z
                    }
                    score = sess.run(EdgeScore, feed_dict=feedDict)
                    evalTest.add(rel, score, subLabel, objLabel, subject, objects, imgName, None)
                evalTest.eval(length)
                evalTest.show()
                temp  = evalTest.getRecall()
                tempZero = evalTest.getZero()
                RecallStore.append((temp, tempZero))
                if temp+tempZero > best:
                    best = temp+tempZero
                    bestZero = tempZero
                    save.save(sess, os.path.join(savePath, "embedding"))
                print("best record:", best-bestZero, "zero recall:", bestZero)
            summary_writer.close()
            np.save(os.path.join("dataset", "GanRecall"),RecallStore)
            np.save(os.path.join("dataset", "GanGenLoss"), allGenLoss)
            np.save(os.path.join("dataset", "GanDisLoss"), allDisLoss)

    def testVisual(self, testPath, restorePath):
        ##########################################
        # build network
        objectLabel = tf.concat((self.subLabel, self.objLabel), axis=0)
        subVector, objVector = self.getWordVector(objectLabel)
        subVector = tf.concat((subVector, self.spatial), axis=-1)
        objVector = tf.concat((objVector, self.spatial), axis=-1)
        # featureVector = tf.concat((subVector, objVector, self.spatial), axis=-1)
        featureVector = tf.concat((subVector, objVector), axis=0)
        noise = tf.concat([self.z, featureVector], axis=1)

        gen_res = self.generator(noise, isTrainable=False)
        classificationLogits, EdgeScore, originalScore, generateScore = self.classificationLayer(gen_res, self.objectClass, objectLabel,
                                                                                         isTrainable=False)
        ########################################
        #get restore params
        predicateParams = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope='predicate')
        predicateSaver = tf.train.Saver(var_list=predicateParams)
        predicatePath = os.path.join("ckpt", "visual", "predicate-乘差-0.5364--0.230", "predicate")

        generateParams = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope='generator')
        generateSaver = tf.train.Saver(var_list=generateParams)
        # generatePath = os.path.join("ckpt", "visual", "genrate-乘差-0.5364--0.230", "embedding")
        generatePath = os.path.join(restorePath, "embedding")
        allSaver = tf.train.Saver()
        ########################################
        # get test result
        evalTest = EvalRecallUnion()
        # subVisuals, objVisuals, subVectors, objVectors, edgeVectors, subLabels, objLabels, rels, values, length = np.load(testPath)
        config = tf.ConfigProto(allow_soft_placement=True)
        config.gpu_options.per_process_gpu_memory_fraction = 0.55
        with tf.Session(config=config) as sess:
            sess.run(tf.global_variables_initializer())
            # predicateSaver.restore(sess, predicatePath)
            # generateSaver.restore(sess, generatePath)
            allSaver.restore(sess, restorePath)
            varList = []
            testFeature, length = np.load(testPath)
            for test in testFeature:
                rel, subLabel, objLabel, subject, objects, imgName = test["value"]
                batch_z = np.random.normal(0, 1, [batch * 2, 128]).astype(np.float32)
                feedDict = {
                    self.subVisual: test["subVisual"],
                    self.objVisual: test["objVisual"],
                    self.subVector: test["subLabelMask"],
                    self.objVector: test["objLabelMask"],
                    self.subLabel: subLabel,
                    self.objLabel: objLabel,
                    self.subEdgeVector: test["subEdgeMask"],
                    self.objEdgeVector: test["objEdgeMask"],
                    self.spatial: test["edgeVector"],
                    self.rel: rel,
                    self.z: batch_z,
                    # self.context: test["context"]
                }
                # score, generateScoreValue = sess.run([EdgeScore, generateScore], feed_dict=feedDict)
                score, originalScoreValue, generateScoreValue = sess.run([EdgeScore, originalScore, generateScore], feed_dict=feedDict)
                evalTest.add(rel, score, subLabel, objLabel, subject, objects, imgName, None)
                varList.append([rel, score, subLabel, objLabel, subject, objects, imgName, originalScoreValue, generateScoreValue])
            evalTest.eval(length)
            evalTest.show()
            savePath = os.path.join(restorePath, "testRes")
            # np.save(savePath, [varList, length])

    def TrainTestAtt(self, trainData, testPath, restorePath, Epoch=1000, batch=16, savePath=None):
        # parameter
        # candidate: GAN, LSGAN, BEGAN, WGAN,
        ganType = "BEGAN"
        discTrain, generatorTrain, discriminatorLoss, generatorLoss, EdgeScore, generateScore = self.getArchOptimizer(att=True)
        reStore, save = self.getRestore()
        # savePath = savePath if savePath else os.path.join("ckpt", "visual", "embeddingAttNew")
        # if not os.path.exists(savePath):
        #     os.makedirs(savePath)
        cytle = 5
        best = 0.0
        bestZero = 0.0
        config = tf.ConfigProto(allow_soft_placement=True)
        config.gpu_options.per_process_gpu_memory_fraction = 0.55

        RecallStore = []
        storeClsLoss = []
        generateLoss = []
        discriminateLoss = []
        with tf.Session(config=config) as sess:
            sess.run(tf.global_variables_initializer())
            # restore the relation matrix and layer
            reStore.restore(sess, restorePath)
            for epoch in range(Epoch):
                for i in range(0, trainData.size, batch):
                    for j in range(cytle):
                        batch_subVisual, batch_objVisuals, batch_subVectors, batch_objVectors, \
                        batch_subEdgeMask, batch_objEdgeMask, batch_context, batch_edgeVectors, batch_subLabels, batch_objLabels, batch_rel, z_rand = trainData.next_batch(batch)
                        batch_z = np.random.normal(0, 1, [batch*2, 128]).astype(np.float32)
                        feedDict = {
                            self.subVisual: batch_subVisual,
                            self.objVisual: batch_objVisuals,
                            self.subVector: batch_subVectors,
                            self.objVector: batch_objVectors,
                            self.subEdgeVector:batch_subEdgeMask,
                            self.objEdgeVector:batch_objEdgeMask,
                            self.subLabel: batch_subLabels,
                            self.objLabel: batch_objLabels,
                            self.spatial: batch_edgeVectors,
                            self.rel: batch_rel,
                            self.z:batch_z
                        }
                        _, discLoss = sess.run([discTrain, discriminatorLoss],
                                                       feed_dict=feedDict)
                    batch_subVisual, batch_objVisuals, batch_subVectors, batch_objVectors, \
                    batch_subEdgeMask, batch_objEdgeMask, batch_context, batch_edgeVectors, batch_subLabels, batch_objLabels, batch_rel, z_rand = trainData.next_batch(
                        batch)
                    batch_z = np.random.normal(0, 1, [batch*2, 128]).astype(np.float32)
                    feedDict = {
                        self.subVisual: batch_subVisual,
                        self.objVisual: batch_objVisuals,
                        self.subVector: batch_subVectors,
                        self.objVector: batch_objVectors,
                        self.subEdgeVector: batch_subEdgeMask,
                        self.objEdgeVector: batch_objEdgeMask,
                        self.subLabel: batch_subLabels,
                        self.objLabel: batch_objLabels,
                        self.spatial: batch_edgeVectors,
                        self.rel: batch_rel,
                        self.z: batch_z
                    }
                    _, genLoss = sess.run([generatorTrain, generatorLoss], feed_dict=feedDict)
                print("train finish")
                evalTest = EvalRecallUnion()
                evalGenerate = EvalRecallUnion()
                testFeature, length = np.load(testPath)
                testClsLoss = []
                for test in testFeature:
                    rel, subLabel, objLabel, subject, objects, imgName = test["value"]
                    batch_z = np.random.normal(0, 1, [batch * 2, 128]).astype(np.float32)
                    feedDict = {
                        self.subVisual: test["subVisual"],
                        self.objVisual: test["objVisual"],
                        self.subVector: test["subLabelMask"],
                        self.objVector: test["objLabelMask"],
                        self.subLabel: subLabel,
                        self.objLabel: objLabel,
                        self.subEdgeVector: test["subEdgeMask"],
                        self.objEdgeVector: test["objEdgeMask"],
                        self.spatial: test["edgeVector"],
                        self.rel: rel,
                        self.z: batch_z,
                    }
                    score, generateScoreValue, clsLossVal = sess.run([EdgeScore, generateScore, self.clsLoss], feed_dict=feedDict)
                    testClsLoss.append(clsLossVal)
                    evalTest.add(rel, score, subLabel, objLabel, subject, objects, imgName, None)
                    evalGenerate.add(rel, generateScoreValue, subLabel, objLabel, subject, objects, imgName, None)
                evalTest.eval(length)
                evalTest.showSimple()
                print("-"*40, "generate Score:")
                evalGenerate.eval(length)
                evalGenerate.showSimple()
                print("*" * 40)
                temp  = evalTest.getRecall()
                tempZero = evalTest.getZero()*0.5
                RecallStore.append((evalGenerate.getRecall(), evalGenerate.getZero()))
                storeClsLoss.append(testClsLoss)
                if temp+tempZero > best:
                    best = temp+tempZero
                    bestZero = tempZero
                print("best record:", best-bestZero, "zero recall:", bestZero*2)
                savePath = os.path.join("ckpt","featureStore", ganType)
                if not os.path.exists(savePath):
                    os.makedirs(savePath)
                np.save(os.path.join(savePath, "recall.npy"), RecallStore)
                np.save(os.path.join(savePath, "clsLoss.npy"), storeClsLoss)

    def getFeature(self, testPath, restorePath):
        discTrain, generatorTrain, discriminatorLoss, generatorLoss, EdgeScore, generateScore = self.getArchOptimizer(
            att=True)
        restore = tf.train.Saver()
        config = tf.ConfigProto(allow_soft_placement=True)
        config.gpu_options.per_process_gpu_memory_fraction = 0.55
        testRes = []
        with tf.Session(config=config) as sess:
            # restore the relation matrix and layer
            restore.restore(sess, os.path.join(restorePath, "embedding"))
            evalTest = EvalRecallUnion()
            evalTestGenerate = EvalRecallUnion()
            testFeature, length = np.load(testPath)
            for test in testFeature:
                rel, subLabel, objLabel, subject, objects, imgName = test["value"]
                batch_z = np.random.normal(0, 1, [batch * 2, 128]).astype(np.float32)
                feedDict = {
                    self.subVisual: test["subVisual"],
                    self.objVisual: test["objVisual"],
                    self.subVector: test["subLabelMask"],
                    self.objVector: test["objLabelMask"],
                    self.subLabel: subLabel,
                    self.objLabel: objLabel,
                    self.subEdgeVector: test["subEdgeMask"],
                    self.objEdgeVector: test["objEdgeMask"],
                    self.spatial: test["edgeVector"],
                    self.rel: rel,
                    self.z: batch_z,
                    # self.context: test["context"]
                }
                score, generateScoreValue = sess.run([EdgeScore, generateScore], feed_dict=feedDict)
                evalTest.add(rel, score, subLabel, objLabel, subject, objects, imgName, None)
                evalTestGenerate.add(rel, generateScoreValue, subLabel, objLabel, subject, objects, imgName, None)
            evalTest.eval(length)
            evalTest.showSimple()
            evalTestGenerate.eval(length)
            evalTestGenerate.showSimple()
            addCorrect = [(i[4], i[-2], i[-1]) for i in evalTest.correctTripe]
            generateCorrect = [(i[4], i[-2], i[-1]) for i in evalTestGenerate.correctTripe]
            savePath = os.path.join(restorePath, "testRes")
            np.save(savePath, (addCorrect, generateCorrect))

class ConditionVAE(Generate):

    def encoder(self, target, condition, reuse=False, isTrainable=True, name="generator"):
        z_dim = 128
        with tf.variable_scope(name, reuse=reuse) as scope:
            x = tf.concat((target, condition), axis=-1)
            net = slim.fully_connected(x, 1024, activation_fn=tf.nn.leaky_relu, scope="gen_fc1", trainable=isTrainable)
            gaussian_params = slim.fully_connected(net, 2 * z_dim, activation_fn=tf.nn.leaky_relu, scope="gen_fc2", trainable=isTrainable)
            # The mean parameter is unconstrained
            mean = gaussian_params[:, :z_dim]
            stddev = 1e-6 + tf.nn.softplus(gaussian_params[:, z_dim:])
            return mean, stddev

    def decoder(self, noise, condition, name="discriminator", reuse=False, isTrainable=True):
        with tf.variable_scope(name, reuse=reuse) as scope:
            x = tf.concat((noise, condition), axis=-1)
            net = slim.fully_connected(x, 4096, activation_fn=tf.nn.leaky_relu, scope="disc_fc1",trainable=isTrainable)
            real_fake = slim.fully_connected(net, 450, activation_fn=tf.nn.relu, scope="disc_rf", trainable=isTrainable)
            return real_fake

    def model(self):
        train = True
        alpha = 1.0
        objectLabel = tf.concat((self.subLabel, self.objLabel), axis=0)
        subVector, objVector = self.getWordVector(objectLabel)
        condition = tf.concat((subVector, objVector), axis=0)
        targetOut = tf.concat((self.subVector, self.objVector), axis=0)
        noise = self.z
        # encoding
        mu, sigma = self.encoder(targetOut, condition, isTrainable=train)

        # sampling by re-parameterization technique
        z = mu + sigma * tf.random_normal(tf.shape(mu), 0, 1, dtype=tf.float32)

        # decoding
        out = self.decoder(z, condition, isTrainable=train)
        out = tf.clip_by_value(out, 1e-8, 1 - 1e-8)

        generateRes = self.decoder(noise, condition, reuse=True, isTrainable=train)
        classificationLogits, score, _, generateScore = self.classificationLayerAtt(generateRes, self.objectClass,
                                                                                    objectLabel, isTrainable=False)
        ############ classification loss #########################
        classificationLoss = tf.reduce_mean(
            tf.nn.sparse_softmax_cross_entropy_with_logits(logits=classificationLogits, labels=self.rel))

        self.clsLoss = classificationLoss
        # loss
        marginal_likelihood = tf.reduce_sum(targetOut * tf.log(out) + (1 - targetOut) * tf.log(1 - out),
                                            [1])
        KL_divergence = 0.5 * tf.reduce_sum(tf.square(mu) + tf.square(sigma) - tf.log(1e-8 + tf.square(sigma)) - 1, [1])

        neg_loglikelihood = -tf.reduce_mean(marginal_likelihood)
        KL_divergence = tf.reduce_mean(KL_divergence)
        ELBO = -neg_loglikelihood - KL_divergence
        loss = -ELBO+alpha*classificationLoss

        # op
        discParams = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES)
        for params in discParams:
            print(params.name)
        discOptimizer = tf.train.GradientDescentOptimizer(learning_rate=self.lr)

        discGradsVars = discOptimizer.compute_gradients(loss, var_list=discParams)
        discTrain = discOptimizer.apply_gradients(discGradsVars)
        return loss, discTrain, score, generateScore

    def trainTest(self, trainData, testPath, restorePath, Epoch=2000, batch=16):
        self.lr = 0.001
        trainLoss, trainStep,EdgeScore, generateScore = self.model()
        reStore, save = self.getRestore()
        best = 0.0
        bestZero = 0.0
        config = tf.ConfigProto(allow_soft_placement=True)
        config.gpu_options.per_process_gpu_memory_fraction = 0.55
        RecallStore = []
        storeClsLoss = []
        generateLoss = []
        discriminateLoss = []
        with tf.Session(config=config) as sess:
            sess.run(tf.global_variables_initializer())
            reStore.restore(sess, restorePath)
            for epoch in range(Epoch):
                for i in range(0, trainData.size, batch):
                    batch_subVisual, batch_objVisuals, batch_subVectors, batch_objVectors, \
                    batch_subEdgeMask, batch_objEdgeMask, batch_context, batch_edgeVectors, batch_subLabels, batch_objLabels, batch_rel, z_rand = trainData.next_batch(
                        batch)
                    batch_z = np.random.normal(0, 1, [batch * 2, 128]).astype(np.float32)
                    feedDict = {
                        self.subVisual: batch_subVisual,
                        self.objVisual: batch_objVisuals,
                        self.subVector: batch_subVectors,
                        self.objVector: batch_objVectors,
                        self.subEdgeVector: batch_subEdgeMask,
                        self.objEdgeVector: batch_objEdgeMask,
                        self.subLabel: batch_subLabels,
                        self.objLabel: batch_objLabels,
                        self.spatial: batch_edgeVectors,
                        self.rel: batch_rel,
                        self.z: batch_z
                    }
                    lossVal, _ = sess.run([trainLoss, trainStep], feed_dict=feedDict)
                print("train finish")
                evalTest = EvalRecallUnion()
                evalGenerate = EvalRecallUnion()
                testFeature, length = np.load(testPath)
                testClsLoss = []
                for test in testFeature:
                    rel, subLabel, objLabel, subject, objects, imgName = test["value"]
                    batch_z = np.random.normal(0, 1, [batch * 2, 128]).astype(np.float32)
                    feedDict = {
                        self.subVisual: test["subVisual"],
                        self.objVisual: test["objVisual"],
                        self.subVector: test["subLabelMask"],
                        self.objVector: test["objLabelMask"],
                        self.subLabel: subLabel,
                        self.objLabel: objLabel,
                        self.subEdgeVector: test["subEdgeMask"],
                        self.objEdgeVector: test["objEdgeMask"],
                        self.spatial: test["edgeVector"],
                        self.rel: rel,
                        self.z: batch_z,
                    }
                    score, generateScoreValue, clsLossVal = sess.run([EdgeScore, generateScore, self.clsLoss], feed_dict=feedDict)
                    testClsLoss.append(clsLossVal)
                    evalTest.add(rel, score, subLabel, objLabel, subject, objects, imgName, None)
                    evalGenerate.add(rel, generateScoreValue, subLabel, objLabel, subject, objects, imgName, None)
                evalTest.eval(length)
                evalTest.showSimple()
                print("*" * 40, "generate-score")
                evalGenerate.eval(length)
                evalGenerate.showSimple()
                print("*" * 40)
                temp = evalTest.getRecall()
                tempZero = evalTest.getZero() * 0.5
                RecallStore.append((evalGenerate.getRecall(), evalGenerate.getZero()))
                storeClsLoss.append(testClsLoss)
                if temp + tempZero > best:
                    best = temp + tempZero
                    bestZero = tempZero
                print("best record:", best - bestZero, "zero recall:", bestZero * 2)
                savePath = os.path.join("ckpt", "featureStore", "VAE")
                if not os.path.exists(savePath):
                    os.makedirs(savePath)
                np.save(os.path.join(savePath, "recall.npy"), RecallStore)
                np.save(os.path.join(savePath, "clsLoss.npy"), storeClsLoss)

class CVAE_GAN(ConditionVAE):

    def encoder(self, target, condition, reuse=False, isTrainable=True, name="encoder"):
        # 在源码中为 输入图片经过VGG后，与condition拼接，经过若干liner层后输出
        z_dim = 128
        with tf.variable_scope(name, reuse=reuse) as scope:
            x = tf.concat((target, condition), axis=-1)
            net = slim.fully_connected(x, 1024, activation_fn=tf.nn.leaky_relu, scope="gen_fc1", trainable=isTrainable)
            gaussian_params = slim.fully_connected(net, 2 * z_dim, activation_fn=tf.nn.leaky_relu, scope="gen_fc2", trainable=isTrainable)
            # The mean parameter is unconstrained
            mean = gaussian_params[:, :z_dim]
            stddev = 1e-6 + tf.nn.softplus(gaussian_params[:, z_dim:])
            return mean, stddev

    def decoder(self, noise, condition, name="decoder", reuse=False, isTrainable=True):
        # 源码中为noise和condition拼接，使用转置卷积至image大小
        with tf.variable_scope(name, reuse=reuse) as scope:
            x = tf.concat((noise, condition), axis=-1)
            net = slim.fully_connected(x, 4096, activation_fn=tf.nn.leaky_relu, scope="disc_fc1",trainable=isTrainable)
            real_fake = slim.fully_connected(net, 450, activation_fn=tf.nn.relu, scope="disc_rf", trainable=isTrainable)
            return real_fake

    def discriminator(self, x, condition, name="discriminator", reuse=False, isTrainable=True):
        with tf.variable_scope(name, reuse=reuse) as scope:
            net = tf.concat((x, condition), axis=-1)
            net = slim.fully_connected(net, 4096, activation_fn=tf.nn.leaky_relu, scope="disc_fc1",trainable=isTrainable)
            real_fake = slim.fully_connected(net, 1, activation_fn=None, scope="disc_rf", trainable=isTrainable)
            # action_dis = tf.nn.sigmoid(real_fake)
            dis = tf.reshape(real_fake, [-1])
            return net, dis

    def classifier(self, generateRes, reuse=False, isTrainable=True):
        print("classification predicate")
        with tf.variable_scope("predicate", reuse=reuse) as scope:
            subVector, objVector = tf.split(generateRes, 2, axis=0)
            subVec = self.subVisual * subVector * self.subEdgeVector
            objVec = self.objVisual * objVector * self.objEdgeVector
            edge = slim.fully_connected(subVec - objVec, self.featureDim, scope="feature")
            # originalEdge = slim.fully_connected(
            #     self.subVisual * self.subVector * self.subEdgeVector - self.objVisual * self.objVector * self.objEdgeVector,
            #     self.featureDim, scope="feature", reuse=True)
            # originalFeature = tf.concat((originalEdge, self.spatial), axis=-1)
            edgeFeature = tf.concat((edge, self.spatial), axis=-1)
            score = slim.fully_connected(edgeFeature, num_outputs=self.relationClass)
            # originalScore = slim.fully_connected(originalFeature, num_outputs=self.relationClass,
            #                                      scope="fully_connected", reuse=True)
            # EdgeScore = tf.nn.softmax(score + originalScore, dim=-1)  # + tf.nn.softmax(originalScore, dim=-1)
        return score, edgeFeature

    def model(self):
        train = True
        alpha = 1.0
        objectLabel = tf.concat((self.subLabel, self.objLabel), axis=0)
        subVector, objVector = self.getWordVector(objectLabel)

        condition = tf.concat((subVector, objVector), axis=0)
        targetOut = tf.concat((self.subVector, self.objVector), axis=0)
        noise = self.z

        # sampling by re-parameterization technique
        mu, sigma = self.encoder(targetOut, condition, isTrainable=train)
        z = mu + sigma * tf.random_normal(tf.shape(mu), 0, 1, dtype=tf.float32)
        KL_divergence = -0.5 * tf.reduce_sum(tf.square(mu) + tf.square(sigma) - tf.log(1e-8 + tf.square(sigma)) - 1, [1])
        kl_loss = 3*KL_divergence

        # decoding, decodeOut:*_f, generateRes:*_p
        decodeOut = self.decoder(z, condition, isTrainable=train)
        generateRes = self.decoder(noise, condition, isTrainable=train, reuse=True)

        # discriminator
        y_real, feature_real = self.discriminator(targetOut, condition, isTrainable=train)
        y_generate, feature_generate = self.discriminator(generateRes, condition, reuse=True, isTrainable=train)
        y_decode, feature_decode = self.discriminator(decodeOut, condition, reuse=True, isTrainable=train)


        #classifier
        generateScore, generateFeature = self.classifier(generateRes, isTrainable=False)
        targetScore, targetFeature = self.classifier(targetOut, isTrainable=False, reuse=True)
        decodeScore, decodeFeature = self.classifier(decodeOut, isTrainable=False, reuse=True)

        # loss
        # G
        loss_x = tf.reduce_mean(tf.square(targetOut - decodeOut))
        loss_d = tf.reduce_mean(tf.square(feature_real - feature_decode))
        loss_c = tf.reduce_mean(tf.square(targetFeature - decodeFeature))
        # D
        d_loss_real = tf.reduce_mean(
            tf.nn.sigmoid_cross_entropy_with_logits(logits=y_real, labels=tf.ones_like(y_real)))
        d_loss_fake = tf.reduce_mean(
            tf.nn.sigmoid_cross_entropy_with_logits(logits=y_generate, labels=tf.zeros_like(y_generate)))
        d_loss_decode = tf.reduce_mean(
            tf.nn.sigmoid_cross_entropy_with_logits(logits=y_decode, labels=tf.zeros_like(y_decode)))
        # C
        clsGenerateLoss = tf.reduce_mean(
            tf.nn.sparse_softmax_cross_entropy_with_logits(logits=generateScore, labels=self.rel))
        clsDecodeLoss = tf.reduce_mean(
            tf.nn.sparse_softmax_cross_entropy_with_logits(logits=decodeScore, labels=self.rel))
        self.clsLoss = clsGenerateLoss

        d_loss = d_loss_real + d_loss_fake + d_loss_decode
        g_loss = loss_x + loss_d + loss_c + alpha*(clsDecodeLoss+clsGenerateLoss)
        gd_loss = 10 ** -3 * 0.5 * tf.reduce_mean(
            tf.square(tf.reduce_mean(feature_real, axis=0) - tf.reduce_mean(feature_generate, axis=0)))
        gc_loss = 10 ** -3 * 0.5 * tf.reduce_mean(
            tf.square(tf.reduce_mean(targetFeature, axis=0) - tf.reduce_mean(generateFeature, axis=0)))

        # op
        discParams = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, scope='discriminator')
        encoderParams = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, scope='encoder')
        decoderParams = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, scope='decoder')
        print("discriminator parameters:")
        for params in discParams:
            print(params.name)
        print("encoder parameters:")
        for params in encoderParams:
            print(params.name)
        print("decoder parameters:")
        for params in decoderParams:
            print(params.name)
        discOptimizer = tf.train.GradientDescentOptimizer(learning_rate=self.lr)
        encOptimizer = tf.train.GradientDescentOptimizer(learning_rate=self.lr)
        decOptimizer = tf.train.GradientDescentOptimizer(learning_rate=self.lr)

        discGradsVars = discOptimizer.compute_gradients(d_loss, var_list=discParams)
        encGradsVars = encOptimizer.compute_gradients(g_loss+kl_loss, var_list=encoderParams)
        decGradsVars = decOptimizer.compute_gradients(g_loss+gd_loss+gc_loss, var_list=decoderParams)
        discTrain = discOptimizer.apply_gradients(discGradsVars)
        encTrain = encOptimizer.apply_gradients(encGradsVars)
        decTrain = decOptimizer.apply_gradients(decGradsVars)

        return discTrain, encTrain, decTrain, d_loss, g_loss+kl_loss, g_loss+gd_loss+gc_loss, \
               tf.nn.softmax(generateScore+targetScore), tf.nn.softmax(generateScore)

    def trainTest(self, trainData, testPath, restorePath, Epoch=1000, batch=16):
        self.lr = 0.001
        discTrain, encTrain, decTrain, dLoss, encLoss, decLoss, EdgeScore, generateScore = self.model()
        reStore, save = self.getRestore()
        best = 0.0
        bestZero = 0.0
        config = tf.ConfigProto(allow_soft_placement=True)
        config.gpu_options.per_process_gpu_memory_fraction = 0.55
        RecallStore = []
        storeClsLoss = []
        generateLoss = []
        discriminateLoss = []
        with tf.Session(config=config) as sess:
            sess.run(tf.global_variables_initializer())
            reStore.restore(sess, restorePath)
            for epoch in range(Epoch):
                for i in range(0, trainData.size, batch):
                    batch_subVisual, batch_objVisuals, batch_subVectors, batch_objVectors, \
                    batch_subEdgeMask, batch_objEdgeMask, batch_context, batch_edgeVectors, batch_subLabels, batch_objLabels, batch_rel, z_rand = trainData.next_batch(
                        batch)
                    batch_z = np.random.normal(0, 1, [batch * 2, 128]).astype(np.float32)
                    feedDict = {
                        self.subVisual: batch_subVisual,
                        self.objVisual: batch_objVisuals,
                        self.subVector: batch_subVectors,
                        self.objVector: batch_objVectors,
                        self.subEdgeVector: batch_subEdgeMask,
                        self.objEdgeVector: batch_objEdgeMask,
                        self.subLabel: batch_subLabels,
                        self.objLabel: batch_objLabels,
                        self.spatial: batch_edgeVectors,
                        self.rel: batch_rel,
                        self.z: batch_z
                    }
                    encLossVal, _ = sess.run([encLoss, encTrain], feed_dict=feedDict)

                    decLossVal, _ = sess.run([decLoss, decTrain], feed_dict=feedDict)

                    dLossVal, _ = sess.run([dLoss, discTrain], feed_dict=feedDict)

                print("train finish")
                evalTest = EvalRecallUnion()
                evalGenerate = EvalRecallUnion()
                testFeature, length = np.load(testPath)
                testClsLoss = []
                for test in testFeature:
                    rel, subLabel, objLabel, subject, objects, imgName = test["value"]
                    batch_z = np.random.normal(0, 1, [batch * 2, 128]).astype(np.float32)
                    feedDict = {
                        self.subVisual: test["subVisual"],
                        self.objVisual: test["objVisual"],
                        self.subVector: test["subLabelMask"],
                        self.objVector: test["objLabelMask"],
                        self.subLabel: subLabel,
                        self.objLabel: objLabel,
                        self.subEdgeVector: test["subEdgeMask"],
                        self.objEdgeVector: test["objEdgeMask"],
                        self.spatial: test["edgeVector"],
                        self.rel: rel,
                        self.z: batch_z,
                    }
                    score, generateScoreValue, clsLossVal = sess.run([EdgeScore, generateScore, self.clsLoss], feed_dict=feedDict)
                    testClsLoss.append(clsLossVal)
                    evalTest.add(rel, score, subLabel, objLabel, subject, objects, imgName, None)
                    evalGenerate.add(rel, generateScoreValue, subLabel, objLabel, subject, objects, imgName, None)
                evalTest.eval(length)
                evalTest.showSimple()
                print("*" * 40, "generate-score")
                evalGenerate.eval(length)
                evalGenerate.showSimple()
                print("*" * 40)
                temp = evalTest.getRecall()
                tempZero = evalTest.getZero() * 0.5
                RecallStore.append((evalGenerate.getRecall(), evalGenerate.getZero()))
                storeClsLoss.append(testClsLoss)
                if temp + tempZero > best:
                    best = temp + tempZero
                    bestZero = tempZero
                print("best record:", best - bestZero, "zero recall:", bestZero * 2)
                savePath = os.path.join("ckpt", "featureStore", "cVAE-GAN")
                if not os.path.exists(savePath):
                    os.makedirs(savePath)
                np.save(os.path.join(savePath, "recall.npy"), RecallStore)
                np.save(os.path.join(savePath, "clsLoss.npy"), storeClsLoss)

if __name__ == "__main__":
    batch = 16
    fileName = "edgeMask--乘---Nocontext--0.5297"
    trainPath = os.path.join("ckpt", "visual", fileName, "trainFeature.npy")
    savePredicatePath = os.path.join("ckpt", "visual", fileName, "predicate")
    trainData = FeatureDataAtt(trainPath, batch=batch)
    testPath = os.path.join("ckpt", "visual", fileName, "testFeature.npy")
    restorePath = os.path.join("ckpt", "visual", fileName, "predicate", "predicate")
    embeddingPath = os.path.join("ckpt", "visual", fileName, "embedding")
    # train for GAN
    # model = Generate()
    # model.TrainTestAtt(trainData, testPath, restorePath)

    # train for VAE
    # model = ConditionVAE()
    # model.trainTest(trainData, testPath, restorePath)

    # train for CVAE_GAN
    # model = CVAE_GAN()
    # model.trainTest(trainData, testPath, restorePath)