import tensorflow as tf
import tensorflow.contrib.slim as slim
from tensorflow.contrib.slim import nets
from LoadMat import DataLoadImg
import numpy as np
import pdb
import pickle
import os
os.environ["CUDA_VISIBLE_DEVICES"] = "0"


class VisualModel(object):
    def __init__(self, BatchSize=32, NumClasses=101):
        self.batch_size = BatchSize
        self.num_classes = NumClasses

    def GetModel(self, inputs, IsTraining):
        with slim.arg_scope(nets.vgg.vgg_arg_scope()):
            net, endpoints, feature = vgg_16(inputs, num_classes=0, is_training=IsTraining)

        with tf.variable_scope('Logits'):
            print("net shape", net.get_shape())
            net = tf.squeeze(net, [1, 2])
            net = slim.dropout(net, keep_prob=0.5, scope='scope')
            logits = slim.fully_connected(net, num_outputs=self.num_classes,
                                          activation_fn=None, scope='fc')
        return net, logits

    def GetOptimizer(self, logits, labels):
        losses = tf.nn.sparse_softmax_cross_entropy_with_logits(
            labels=labels, logits=logits)
        loss = tf.reduce_mean(losses)

        logits = tf.nn.softmax(logits)
        classes = tf.argmax(logits, axis=1, name='classes')
        accuracy = tf.reduce_mean(tf.cast(
            tf.equal(tf.cast(classes, dtype=tf.int32), labels), dtype=tf.float32))
        optimizer = tf.train.AdamOptimizer(learning_rate=0.0001)

        train_step = slim.learning.create_train_op(loss, optimizer)
        # update_ops = tf.get_collection(tf.GraphKeys.UPDATE_OPS)
        # if update_ops:
        #     updates = tf.group(*update_ops)
        #     loss = tf.control_flow_ops.with_dependencies([updates], loss)

        # optimizer = tf.train.AdamOptimizer(learning_rate=0.0001)
        # train_step = optimizer.minimize(loss)

        return loss, accuracy, train_step

    def GetSaver(self, name='Logits'):
        checkpoint_exclude_scopes = name
        exclusions = None
        if checkpoint_exclude_scopes:
            exclusions = [
                scope.strip() for scope in checkpoint_exclude_scopes.split(',')]
        variables_to_restore = []
        for var in slim.get_model_variables():
            print("slim var", var)
            pdb.set_trace()
            excluded = False
            for exclusion in exclusions:
                if var.op.name.startswith(exclusion):
                    excluded = True
            if not excluded:
                variables_to_restore.append(var)
        # path = os.path.join("ckpt", "pretrain", "ResnetVariables.ins")
        # pickle.dump(["resnet_v1_101"], open(path, "wb"))

        saver_restore = tf.train.Saver(var_list=variables_to_restore)
        saver = tf.train.Saver(tf.global_variables())

        return saver_restore, saver

    def Train(self, data, TestData, resnet_model_path, model_save_path):

        inputs = tf.placeholder(tf.float32, shape=[None, 224, 224, 3], name='inputs')
        labels = tf.placeholder(tf.int32, shape=[None], name='labels')
        is_training = tf.placeholder(tf.bool, name='is_training')

        _, logits = self.GetModel(inputs, is_training)
        loss, accuracy, train_step = self.GetOptimizer(logits, labels)

        saver_restore, saver = self.GetSaver()
        config = tf.ConfigProto(allow_soft_placement=True)
        config.gpu_options.per_process_gpu_memory_fraction = 0.95
        init = tf.global_variables_initializer()
        epoch = 10
        best = 0
        with tf.Session(config=config) as sess:
            sess.run(init)
            # Load the pretrained checkpoint file xxx.ckpt
            saver_restore.restore(sess, resnet_model_path)
            for i in range(epoch):
                TrainData = data.NextBatch()
                test = TestData.NextBatch()
                step = 0
                for images, ImgLabels in TrainData:
                    step += 1
                    train_dict = {inputs: images,
                                  labels: ImgLabels,
                                  is_training: True}

                    sess.run(train_step, feed_dict=train_dict)

                    loss_, acc_ = sess.run([loss, accuracy], feed_dict=train_dict)

                    train_text = 'Step: {0}, Loss: {1}, Accuracy: {2}'.format(
                        step + 1, loss_, acc_)
                    if step %100 ==0:
                        print(train_text)
                average = []
                for images, ImgLabels in test:
                    step += 1
                    train_dict = {inputs: images,
                                  labels: ImgLabels,
                                  is_training: False}

                    loss_, acc_ = sess.run([loss, accuracy], feed_dict=train_dict)
                    average.append(acc_)
                temp_acc = sum(average)/average.__len__()
                train_text = 'test Accuracy: {0}'.format(temp_acc)
                print(train_text)
                if temp_acc > best:
                    best = temp_acc
                    saver.save(sess, model_save_path)
                    print('save mode to {}'.format(model_save_path))


def vgg_16(inputs,
           num_classes=1000,
           is_training=True,
           dropout_keep_prob=0.5,
           spatial_squeeze=True,
           scope='vgg_16',
           fc_conv_padding='VALID',
           global_pool=False):
  """Oxford Net VGG 16-Layers version D Example.
  Note: All the fully_connected layers have been transformed to conv2d layers.
        To use in classification mode, resize input to 224x224.
  Args:
    inputs: a tensor of size [batch_size, height, width, channels].
    num_classes: number of predicted classes. If 0 or None, the logits layer is
      omitted and the input features to the logits layer are returned instead.
    is_training: whether or not the model is being trained.
    dropout_keep_prob: the probability that activations are kept in the dropout
      layers during training.
    spatial_squeeze: whether or not should squeeze the spatial dimensions of the
      outputs. Useful to remove unnecessary dimensions for classification.
    scope: Optional scope for the variables.
    fc_conv_padding: the type of padding to use for the fully connected layer
      that is implemented as a convolutional layer. Use 'SAME' padding if you
      are applying the network in a fully convolutional manner and want to
      get a prediction map downsampled by a factor of 32 as an output.
      Otherwise, the output prediction map will be (input / 32) - 6 in case of
      'VALID' padding.
    global_pool: Optional boolean flag. If True, the input to the classification
      layer is avgpooled to size 1x1, for any input size. (This is not part
      of the original VGG architecture.)
  Returns:
    net: the output of the logits layer (if num_classes is a non-zero integer),
      or the input to the logits layer (if num_classes is 0 or None).
    end_points: a dict of tensors with intermediate activations.
  """
  with tf.variable_scope(scope, 'vgg_16', [inputs]) as sc:
    end_points_collection = sc.original_name_scope + '_end_points'
    # Collect outputs for conv2d, fully_connected and max_pool2d.
    with slim.arg_scope([slim.conv2d, slim.fully_connected, slim.max_pool2d],
                        outputs_collections=end_points_collection):
      net = slim.repeat(inputs, 2, slim.conv2d, 64, [3, 3], scope='conv1')
      net = slim.max_pool2d(net, [2, 2], scope='pool1')
      net = slim.repeat(net, 2, slim.conv2d, 128, [3, 3], scope='conv2')
      net = slim.max_pool2d(net, [2, 2], scope='pool2')
      net = slim.repeat(net, 3, slim.conv2d, 256, [3, 3], scope='conv3')
      net = slim.max_pool2d(net, [2, 2], scope='pool3')
      net = slim.repeat(net, 3, slim.conv2d, 512, [3, 3], scope='conv4')
      net = slim.max_pool2d(net, [2, 2], scope='pool4')
      # net = slim.repeat(net, 3, slim.conv2d, 512, [3, 3], scope='conv5')
      # rgirdhar: remove the relu from last layer
      net = slim.repeat(net, 2, slim.conv2d, 512, [3, 3], scope='conv5')
      net = slim.conv2d(net, 512, [3, 3], activation_fn=None,
                        scope='conv5/conv5_3')
      net = tf.nn.relu(net)
      net = slim.max_pool2d(net, [2, 2], scope='pool5')
      conv_feature = net
      # Use conv2d instead of fully_connected layers.
      net = slim.conv2d(net, 4096, [7, 7], padding=fc_conv_padding, scope='fc6')
      net = slim.dropout(net, dropout_keep_prob, is_training=is_training,
                         scope='dropout6')
      net = slim.conv2d(net, 4096, [1, 1], scope='fc7')
      # Convert end_points_collection into a end_point dict.
      end_points = slim.utils.convert_collection_to_dict(end_points_collection)
      if global_pool:
        net = tf.reduce_mean(net, [1, 2], keep_dims=True, name='global_pool')
        end_points['global_pool'] = net
      if num_classes:
        net = slim.dropout(net, dropout_keep_prob, is_training=is_training,
                           scope='dropout7')
        net = slim.conv2d(net, num_classes, [1, 1],
                          activation_fn=None,
                          normalizer_fn=None,
                          scope='fc8')
        if spatial_squeeze:
          net = tf.squeeze(net, [1, 2], name='fc8/squeezed')
        end_points[sc.name + '/fc8'] = net
      return net, end_points, conv_feature

if __name__ == "__main__":
    BatchSize = 32
    TestMat = "annotations_test.json"
    test_data = DataLoadImg(TestMat, "sg_test_images")
    test_data.SetBatch(BatchSize)
    TrainMat = "annotations_train.json"
    train_data = DataLoadImg(TrainMat, "sg_train_images")
    train_data.SetBatch(BatchSize)
    RestorePath = os.path.join("ckpt", "pretrain", "vgg_16.ckpt")
    StorePath = os.path.join("ckpt", "Vgg", "vrd")
    Res = VisualModel()
    Res.Train(train_data, test_data,RestorePath, StorePath)

