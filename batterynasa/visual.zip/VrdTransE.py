import tensorflow as tf
import numpy as np
import datetime
from configparser import ConfigParser
import os
import pdb
from layer import *
from EvalRecall import ErrorAnalysis, EvalRecallUnion
from VIsualModel import vgg_16
from layer import AlternatingHighWayCell
from VrdAttention import VisualAttention
import tensorflow.contrib.slim as slim
from tensorflow.contrib.slim import nets
from LoadMat import DataLoad
from MatDRNet import UnionData
from EvalRecall import EvalRecall
np.set_printoptions(threshold=np.nan)
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
cfg = ConfigParser()
cfg.read("config.ini", encoding="utf-8-sig")
globalWeight = 0.7
negative = 5

class VisualTransE(VisualAttention):
    def __init__(self):
        VisualAttention.__init__(self)
        self.learning_rate = 0.0001
        self.subjectMask = tf.placeholder(tf.float32, [None, self.MaskSize, self.MaskSize])
        self.objectMask = tf.placeholder(tf.float32, [None, self.MaskSize, self.MaskSize])
        self.spatial = tf.placeholder(tf.float32, [None, 4])
        self.simRelation = tf.placeholder(tf.int32, [None, negative])
        self.disSimRelation = tf.placeholder(tf.int32, [None, negative])
        self.oo = tf.placeholder(tf.float32, [None, negative])
        self.relWeight = tf.placeholder(tf.float32, [None,])
        self.varGet = []
    # def getArch(self):
    # transE的直接改进，效果最佳的为0.441 ->0.450
    #     Img = tf.concat((self.subjectImg, self.objectImg), axis=0)
    #     unionVisual = self.GetVisualFeature(Img)
    #     unionVisual = tf.squeeze(unionVisual, 0) if unionVisual.get_shape()[0] == 1 else unionVisual
    #     subVisual, objVisual = tf.split(unionVisual, 2, axis=0)
    #     visual = subVisual - objVisual
    #     visual = slim.fully_connected(visual, num_outputs=150)
    #     with tf.variable_scope("visual_scale", reuse=tf.AUTO_REUSE):
    #         alpha = tf.get_variable(name='alpha', shape=(150,), trainable=True)
    #         beta = tf.get_variable(name='beta', shape=(150,), trainable=True)
    #         output = alpha * visual + beta
    #     visual_feature = output
    #
    #     objectClass = tf.concat((self.subjectLabel, self.objectLabel), axis=0)
    #     WordVector = tf.one_hot(objectClass, depth=self.relationClass)
    #     # WordVector = self.GetWordVector(objectClass, path=None)
    #     # WordVector = tf.squeeze(WordVector, axis=0)
    #     subjectWordVector, objectWordVector = tf.split(WordVector, 2, axis=0)
    #     wordVector = subjectWordVector - objectWordVector
    #     wordVector = slim.fully_connected(wordVector, 300)
    #     wordVector = slim.fully_connected(wordVector, 200)
    #     with tf.variable_scope("word_scale", reuse=False):
    #         alpha = tf.get_variable(name='alpha', shape=(200,), trainable=True)
    #         beta = tf.get_variable(name='beta', shape=(200,), trainable=True)
    #         output = alpha * wordVector + beta
    #     word_feature = output
    #     # edgeMask = tf.stack((self.subjectMask, self.objectMask, self.unionMask), axis=-1)
    #     # edgeMask = tf.squeeze(self.GetPositionMask(edgeMask), axis=0)
    #     edgeMask = self.spatial
    #     edgeVector = slim.fully_connected(edgeMask, 20)
    #     edgeVector = slim.fully_connected(edgeVector, 10)
    #     with tf.variable_scope("spatial_scale", reuse=False):
    #         alpha = tf.get_variable(name='alpha', shape=(10,), trainable=True)
    #         beta = tf.get_variable(name='beta', shape=(10,), trainable=True)
    #         output = alpha * edgeVector + beta
    #     edgeFeature = output
    #
    #     feature = tf.concat((visual_feature, word_feature, edgeFeature), axis=-1)
    #     edge = slim.fully_connected(feature, self.relationClass)
    #     EdgeScore = tf.nn.softmax(edge, dim=-1)
    #
    #     relationWordVector = self.getRelWordVector(self.RelationClass)
    #     relationWordVector = slim.fully_connected(relationWordVector, num_outputs=360)
    #     print("relation feature vector shape:", relationWordVector.get_shape()[-1])
    #
    #     edgeLoss = tf.reduce_sum(tf.square(feature - relationWordVector), axis=-1) * 0.01
    #     # edgeLoss = tf.reduce_mean(edgeLoss, axis=0)*0.01
    #     # edgeLoss = None
    #     loss, accuracy, train_step = self.GetOptimizer(edge, self.RelationClass, maskFeature=edgeLoss)
    #
    #     return loss, accuracy, train_step, EdgeScore,  # index

    # def getArch(self):
    #     # 将visual vector变成250，edge vector变成50, 最佳效果就会变成0.452
    #     Img = tf.concat((self.subjectImg, self.objectImg), axis=0)
    #     unionVisual = self.GetVisualFeature(Img)
    #     unionVisual = tf.squeeze(unionVisual, 0) if unionVisual.get_shape()[0] == 1 else unionVisual
    #     subVisual, objVisual = tf.split(unionVisual, 2, axis=0)
    #     visual = subVisual - objVisual
    #     visual = slim.fully_connected(visual, num_outputs=250)
    #     with tf.variable_scope("visual_scale", reuse=tf.AUTO_REUSE):
    #         alpha = tf.get_variable(name='alpha', shape=(250,), trainable=True)
    #         beta = tf.get_variable(name='beta', shape=(250,), trainable=True)
    #         output = alpha * visual + beta
    #     visual_feature = output
    #
    #     objectClass = tf.concat((self.subjectLabel, self.objectLabel), axis=0)
    #     WordVector = tf.one_hot(objectClass, depth=self.relationClass)
    #     subjectWordVector, objectWordVector = tf.split(WordVector, 2, axis=0)
    #     wordVector = subjectWordVector - objectWordVector
    #     wordVector = slim.fully_connected(wordVector, 300)
    #     wordVector = slim.fully_connected(wordVector, 200)
    #     with tf.variable_scope("word_scale", reuse=False):
    #         alpha = tf.get_variable(name='alpha', shape=(200,), trainable=True)
    #         beta = tf.get_variable(name='beta', shape=(200,), trainable=True)
    #         output = alpha * wordVector + beta
    #     word_feature = output
    #     # edgeMask = tf.stack((self.subjectMask, self.objectMask, self.unionMask), axis=-1)
    #     # edgeMask = tf.squeeze(self.GetPositionMask(edgeMask), axis=0)
    #     edgeMask = self.spatial
    #     edgeVector = slim.fully_connected(edgeMask, 20)
    #     edgeVector = slim.fully_connected(edgeVector, 50)
    #     with tf.variable_scope("spatial_scale", reuse=False):
    #         alpha = tf.get_variable(name='alpha', shape=(50,), trainable=True)
    #         beta = tf.get_variable(name='beta', shape=(50,), trainable=True)
    #         output = alpha * edgeVector + beta
    #     edgeFeature = output
    #
    #     feature = tf.concat((visual_feature, word_feature, edgeFeature), axis=-1)
    #     edge = slim.fully_connected(feature, self.relationClass)
    #     EdgeScore = tf.nn.softmax(edge, dim=-1)
    #
    #     relationWordVector = self.getRelWordVector(self.RelationClass)
    #     relationWordVector = slim.fully_connected(relationWordVector, num_outputs=500)
    #     print("relation feature vector shape:", relationWordVector.get_shape()[-1])
    #
    #     # edgeLoss = tf.reduce_sum(tf.square(feature - relationWordVector), axis=-1) * 0.01
    #     # edgeLoss = tf.reduce_mean(edgeLoss, axis=0)*0.01
    #     edgeLoss = None
    #     loss, accuracy, train_step = self.GetOptimizer(edge, self.RelationClass, maskFeature=edgeLoss)
    #
    #     return loss, accuracy, train_step, EdgeScore,  # index

    # def getArch(self):
    #     # 将visual vector变成250，edge vector变成50, 最佳效果就会变成0.452
    #     # 加入word vector之后会变成最高0.527的样子， 尝试加入extra loss看一下
    #     # 将visual vector变成450，edge vector变成50,不加入word vector时会变成0.504的样子， 加入extra loss则变成0.514,
    #     # 实验波动为0.5095至0.514
    #     Img = tf.concat((self.subjectImg, self.objectImg), axis=0)
    #     unionVisual = self.GetVisualFeature(Img)
    #     unionVisual = tf.squeeze(unionVisual, 0) if unionVisual.get_shape()[0] == 1 else unionVisual
    #     subVisual, objVisual = tf.split(unionVisual, 2, axis=0)
    #     subVisual = slim.fully_connected(subVisual, 450)
    #     objVisual = slim.fully_connected(objVisual, 450)
    #
    #     objectClass = tf.concat((self.subjectLabel, self.objectLabel), axis=0)
    #     # WordVector = tf.squeeze(self.GetWordVector(objectClass), axis=0)
    #     WordVector = tf.one_hot(objectClass, depth=self.relationClass)
    #     subjectWordVector, objectWordVector = tf.split(WordVector, 2, axis=0)
    #     subjectWordVector = slim.fully_connected(subjectWordVector, 450)
    #     objectWordVector = slim.fully_connected(objectWordVector, 450)
    #     # wordVector = subjectWordVector - objectWordVector
    #     # wordVector = slim.fully_connected(wordVector, 300)
    #     # wordVector = slim.fully_connected(wordVector, 200)
    #     subVec = subVisual*subjectWordVector
    #     objVec = objVisual*objectWordVector
    #     edgeVec = slim.fully_connected(subVec-objVec, 450)
    #     # edgeMask = tf.stack((self.subjectMask, self.objectMask, self.unionMask), axis=-1)
    #     # edgeMask = tf.squeeze(self.GetPositionMask(edgeMask), axis=0)
    #     edgeMask = self.spatial
    #     edgeVector = slim.fully_connected(edgeMask, 20)
    #     edgeVector = slim.fully_connected(edgeVector, 50)
    #
    #     feature = tf.concat((edgeVec, edgeVector), axis=-1)
    #     edge = slim.fully_connected(feature, self.relationClass)
    #     EdgeScore = tf.nn.softmax(edge, dim=-1)
    #
    #     relationWordVector = self.getRelWordVector(self.RelationClass)
    #     relationWordVector = slim.fully_connected(relationWordVector, num_outputs=500)
    #     print("relation feature vector shape:", relationWordVector.get_shape()[-1])
    #
    #     edgeLoss = tf.reduce_sum(tf.square(feature - relationWordVector), axis=-1) * 0.01
    #     # edgeLoss = tf.reduce_mean(edgeLoss, axis=0)*0.01
    #     # edgeLoss = None
    #     loss, accuracy, train_step = self.GetOptimizer(edge, self.RelationClass, maskFeature=edgeLoss)
    #
    #     return loss, accuracy, train_step, EdgeScore,  # index

    def getArch(self):
        # 尝试保持relation之间的语义关系
        Img = tf.concat((self.subjectImg, self.objectImg), axis=0)
        unionVisual = self.GetVisualFeature(Img)
        unionVisual = tf.squeeze(unionVisual, 0) if unionVisual.get_shape()[0] == 1 else unionVisual
        subVisual, objVisual = tf.split(unionVisual, 2, axis=0)
        featureDim = 450
        subVisual = slim.fully_connected(subVisual, featureDim)
        objVisual = slim.fully_connected(objVisual, featureDim)

        objectClass = tf.concat((self.subjectLabel, self.objectLabel), axis=0)
        # WordVector = tf.squeeze(self.GetWordVector(objectClass), axis=0)
        WordVector = tf.one_hot(objectClass, depth=self.relationClass)
        subjectWordVector, objectWordVector = tf.split(WordVector, 2, axis=0)

        subjectWordVector = slim.fully_connected(subjectWordVector, featureDim)
        objectWordVector = slim.fully_connected(objectWordVector, featureDim)
        # wordVector = subjectWordVector - objectWordVector
        # wordVector = slim.fully_connected(wordVector, 300)
        # wordVector = slim.fully_connected(wordVector, 200)
        # concat--0.46/0.47; 加--0.45/0.46; 乘--0.512是正常的
        # subVec = subVisual * subjectWordVector
        # objVec = objVisual * objectWordVector
        # 但是在换成wordVector 之后concat, 与乘积的效果相差不多
        # concat: 0.530; 乘积0.523；但是同样加上wordVector后，不加入center Loss后效果变化不大, 0.526的样子
        # original
        # subVisual/subjectWordVector shape: [batch, featureDim]
        # subVec = subVisual * subjectWordVector
        # objVec = objVisual * objectWordVector
        # edgeVec = subVec - objVec
        edgeVec = (subVisual-objVisual)*(subjectWordVector-objectWordVector)
        # concat
        # subVec = tf.concat((subVisual, subjectWordVector), axis=-1)
        # objVec = tf.concat((objVisual, objectWordVector), axis=-1)

        # tensor fuse
        # subVisual/subjectWordVector shape: [batch, featureDim]
        # batchSize = tf.shape(subVisual)[0]
        # subVisual = tf.concat((tf.ones((batchSize, 1)), subVisual), axis=-1)
        # subjectWordVector = tf.concat((tf.ones((batchSize, 1)), subjectWordVector), axis=-1)
        # subVec = tf.matmul(tf.expand_dims(subVisual, axis=2), tf.expand_dims(subjectWordVector, axis=1))
        # dim = subVec.get_shape()[1]
        # subVec = tf.reshape(subVec, [-1, dim*dim])
        #
        # objVisual = tf.concat((tf.ones((batchSize, 1)), objVisual), axis=-1)
        # objectWordVector = tf.concat((tf.ones((batchSize, 1)), objectWordVector), axis=-1)
        # objVec = tf.matmul(tf.expand_dims(objVisual, axis=2), tf.expand_dims(objectWordVector, axis=1))
        # dim = objVec.get_shape()[1]
        # objVec = tf.reshape(objVec, [-1, dim * dim])
        edgeVec = slim.fully_connected(edgeVec, featureDim)
        # edgeMask = self.spatial
        # edgeVector = slim.fully_connected(edgeMask, 50)
        # edgeVector = slim.fully_connected(edgeVector, featureDim)
        # feature = edgeVec * edgeVector
        edgeMask = self.spatial
        edgeVector = slim.fully_connected(edgeMask, 10)
        edgeVector = slim.fully_connected(edgeVector, 50)
        # feature = edgeVec*edgeVector
        feature = tf.concat((edgeVec, edgeVector), axis=-1)
        # 加上来l2正则之后，0.534 ->0.507, 加上曾经的extraLoss为0.508
        # feature = tf.nn.l2_normalize(feature, dim=-1)
        # self.varGet.append(feature)
        edge = slim.fully_connected(feature, self.relationClass)
        EdgeScore = tf.nn.softmax(edge, dim=-1)
        # extraLoss = False
        # if extraLoss:
        #     relationWordVector = self.getRelWordVector(self.RelationClass)
        #     relationWordVector = slim.fully_connected(relationWordVector, num_outputs=500)
        #     # edgeLoss = tf.reduce_sum(tf.square(feature - relationWordVector), axis=-1) * 0.01
        #     edgeLoss = tf.reduce_sum(tf.square(feature - relationWordVector), axis=-1) * 0.01
        # else:
        #     Vectors, simVectors, disSimVectors = self.getRelVector(self.RelationClass, self.simRelation, self.disSimRelation)
        #     # Vectors, simVectors, disSimVectors = self.getRelVec(self.RelationClass, self.simRelation, self.disSimRelation)
        #     # edgeLoss = self.getExtraLoss(feature, Vectors, simVectors, disSimVectors, vectorWeight)
        #     edgeLoss = self.getExtraLoss(feature, Vectors, simVectors, disSimVectors)
        # print("relation feature vector shape:", relationWordVector.get_shape()[-1])
        # edgeLoss = tf.reduce_sum(tf.square(feature - Vectors), axis=-1) * 0.1
        # edgeLoss = tf.reduce_mean(edgeLoss, axis=0)*0.01
        edgeLoss = None
        loss, accuracy, train_step = self.GetOptimizer(edge, self.RelationClass, maskFeature=edgeLoss)

        return loss, accuracy, train_step, EdgeScore,  # index

    def getRelVector(self, relation, simRelation, disSimRelation, path=None, dims=500):
        with tf.variable_scope("rel2Vec"):
            LoadPath = path if path else os.path.join("dataset", "InitRelEmbedding.npy")
            init = tf.constant(np.load(LoadPath), dtype=tf.float32)
            relEmbedding = tf.get_variable("relEmbedding", initializer=init, trainable=True)
            # # trans the vector
            # Vectors = tf.nn.embedding_lookup(relEmbedding, relation)
            # Vectors = tf.expand_dims(Vectors, axis=1)
            # simVectors = tf.nn.embedding_lookup(relEmbedding, simRelation)
            # disSimVectors = tf.nn.embedding_lookup(relEmbedding, disSimRelation)
            # vec = tf.concat((Vectors, simVectors, disSimVectors), axis=1)
            # vec = slim.fully_connected(vec, num_outputs=dims)
            # Vectors, simVectors, disSimVectors = tf.split(vec, [1, negative, negative], axis=1)
            # Vectors = tf.squeeze(Vectors, axis=1)

            # # trans the all martix
            relEmbedding = slim.fully_connected(relEmbedding, dims, scope="rel_full")
            self.relEmbedding = relEmbedding
            # initPath = os.path.join("dataset", "relWeight.npy")
            # initWeight = tf.constant(np.load(initPath), dtype=tf.float32)
            # relWeight = tf.get_variable("relWeight", initializer=initWeight, trainable=False)

            Vectors = tf.nn.embedding_lookup(relEmbedding, relation)
            simVectors = tf.nn.embedding_lookup(relEmbedding, simRelation)
            disSimVectors = tf.nn.embedding_lookup(relEmbedding, disSimRelation)
            # vectorWeight = tf.nn.embedding_lookup(relWeight, relation)
        return Vectors, simVectors, disSimVectors#, vectorWeight

    def getRelVec(self, relation, simRelation, disSimRelation, path=None, dims=500):
        with tf.variable_scope("rel"):
            r = tf.sqrt(tf.cast(6 / dims, dtype=tf.float32))
            relEmbedding = tf.get_variable("relEmbedding", shape=[self.relationClass, dims],
                                           initializer=tf.random_uniform_initializer(
                                               minval=-r, maxval=r))
            Vectors = tf.nn.embedding_lookup(relEmbedding, relation)
            Vectors = tf.expand_dims(Vectors, axis=1)
            simVectors = tf.nn.embedding_lookup(relEmbedding, simRelation)
            disSimVectors = tf.nn.embedding_lookup(relEmbedding, disSimRelation)

        return Vectors, simVectors, disSimVectors

    def getExtraLoss(self, feature, Vectors, simVectors, disSimVectors, relWeight=True):
        # 在单独使用simLoss时，获得了改善但是代码被改烂了， 只能看出是使用了margin loss的方式
        def cosine(q, a, mode=True):
            if mode is True:
                pooled_len_1 = tf.sqrt(tf.reduce_sum(q * q, -1))
                pooled_len_2 = tf.sqrt(tf.reduce_sum(a * a, -1))
                pooled_mul_12 = tf.reduce_sum(q * a, -1)
                score = tf.div(pooled_mul_12, pooled_len_1 * pooled_len_2 + 1e-8)
            else:
                score = tf.reduce_sum(tf.square(q - a), axis=-1)
            return score
        # sameLoss = -cosine(feature, Vectors)
        # sameLoss = tf.reduce_sum(tf.square(feature - Vectors), axis=-1)* 0.008
        # disSimLoss = tf.reduce_mean(cosine(simFeature, disSimVectors)*simWeight, axis=-1)
        # disSimLoss = -tf.reduce_mean(tf.reduce_sum(tf.square(simFeature-disSimVectors), axis=-1)*simWeight, axis=-1)

        # same+sim best 0.514
        # sim = tf.reduce_sum(tf.square(simFeature-simVectors), axis=-1)* 0.1
        # margin = 5
        # sim = tf.maximum(0., margin - sim)
        # simLoss = tf.reduce_mean(sim, axis=-1)
        # allLoss = simLoss + sameLoss
        # # simLoss = tf.maximum(0., globalWeight-sim) + tf.maximum(0., sim-self.oo)
        # # simLoss = tf.reduce_mean(simLoss, -1)

        # same + sim 使用margin loss约束类间向量
        # # 使用margin loss 拉大类别中心间的距离
        # margin = 1.0
        # sim = tf.reduce_sum(tf.square(simVectors - tf.expand_dims(Vectors, 1)), axis=-1)* 0.01
        # simLoss = tf.maximum(0., margin-sim)
        # simLoss = tf.reduce_mean(simLoss, axis=-1)*0.01
        # allLoss = sameLoss

        # #约束类别中心至相同的模值
        # sameLoss = tf.reduce_sum(tf.square(feature - Vectors), axis=-1) * 0.01
        # disLabel = tf.reduce_mean(tf.reduce_sum(tf.square(self.relEmbedding), axis=-1), axis=-1)
        # disVector = tf.reduce_sum(tf.square(Vectors), axis=-1)
        # dis = tf.square(disVector - disLabel)
        # disLoss = tf.maximum(0., dis)*0.001
        # # best 0.515--0.513 差不多
        # allLoss = disLoss*0.25+sameLoss*0.5
        if relWeight is None:
            sameLoss = tf.reduce_sum(tf.square(feature - Vectors), axis=-1) * 0.008
        else:
            print("with extra weight")
            sameLoss = tf.reduce_sum(tf.square(feature - Vectors), axis=-1) * (0.008+self.relWeight)
        disLabel = tf.reduce_mean(tf.reduce_sum(tf.square(self.relEmbedding), axis=-1), axis=-1)
        disVector = tf.reduce_sum(tf.square(Vectors), axis=-1)
        dis = tf.square(disVector - disLabel)
        disLoss = tf.maximum(0., dis)*0.001
        allLoss = sameLoss*0.5 + disLoss*0.25
        return allLoss

    def GetVisualFeature(self, Regions):
        ResNetInput = tf.reshape(Regions, (-1, self.ImgSize, self.ImgSize, 3))
        with slim.arg_scope(nets.vgg.vgg_arg_scope()):
            net, endpoints, feature = vgg_16(ResNetInput, num_classes=None, is_training=self.IsTraining)
        # x_h, out = CANAttention(feature, is_training=self.IsTraining)
        # out = SpatialATT(feature)

        # feature pool5 对应的feature map
        out = feature
        # with tf.variable_scope("visual_concept"):
        #     visualConcept = slim.conv2d(out, 256, kernel_size=1, stride=1)
        #     visualConcept = slim.dropout(visualConcept, self.dropout, is_training=self.IsTraining, scope="drop6")
        #     voting = slim.conv2d(visualConcept, 512, kernel_size=15, stride=1)
        # out, weight = SelfATT(feature)
        with tf.variable_scope('vgg_16', reuse=True):
            # Use conv2d instead of fully_connected layers.
            out = slim.conv2d(out, 4096, [7, 7], padding="VALID", scope='fc6')
            out = slim.dropout(out, 0.5, is_training=self.IsTraining,
                               scope='dropout6')
            out = slim.conv2d(out, 4096, [1, 1], scope='fc7')
        VectorDim = out.get_shape()[-1]
        out = tf.reshape(out, (1, -1, VectorDim))
        # out = tf.concat((x_h, out), axis=-1)
        return out

    def GetOptimizer(self, logits, labels, Teacher=True, alpha=0.5, maskFeature=None):
        edgeLabel = labels
        edgeLosses = tf.nn.softmax_cross_entropy_with_logits(
                     labels=tf.one_hot(edgeLabel, depth=self.relationClass), logits=logits)
        losses = edgeLosses # + maskLosses + actionLosses
        optimizer = tf.train.AdamOptimizer(learning_rate=self.learning_rate)
        if maskFeature is not None:
            losses += maskFeature
            maskLoss = tf.reduce_mean(maskFeature)
            print("add extra loss")
        else:
            maskLoss = tf.reduce_mean(tf.zeros_like(losses))
        logits = tf.nn.softmax(logits)
        classes = tf.argmax(logits, axis=1, name='classes')
        accuracy = tf.reduce_mean(tf.cast(
            tf.equal(tf.cast(classes, dtype=tf.int32), edgeLabel), dtype=tf.float32))
        loss = tf.reduce_mean(losses)
        train_step = slim.learning.create_train_op(loss, optimizer)#, variables_to_train=var_list)
        # # use different lr
        # varRel = [i for i in tf.trainable_variables() if "rel2Vec/relEmbedding" in i.name]
        # varList = [i for i in tf.trainable_variables() if "rel2Vec/relEmbedding" not in i.name]
        # # 0.05/0.04时最佳0.516, 可以哟；0.01时，为0.512；0.005时，为0.506，
        # # 0.03时为0.510；0.07时为0.514; 0.09时,为0.510;
        # lr = 0.05
        # optimizerRel = tf.train.AdamOptimizer(lr)
        # grads = tf.gradients(loss, varList + varRel)
        # grads1 = grads[:len(varList)]
        # grads2 = grads[len(varList):]
        # train_op1 = optimizer.apply_gradients(zip(grads1, varList))
        # train_op2 = optimizerRel.apply_gradients(zip(grads2, varRel))
        # train_step = tf.group(train_op1, train_op2)
        return [loss, maskLoss], accuracy, train_step

    def TrainTest(self, TrainData, resnet_model_path, TestData, Error=True, epoch=10, save=True):
        BatchSize = TrainData.Batch
        def floatShow(a, b=5):
            a = str(a)
            return a[:b]
        loss, accuracy, train_step, EdgeScore = self.getArch()
        saver_restore, saver = self.GetSaver()
        relSim = relationSim(globalWeight)
        config = tf.ConfigProto(allow_soft_placement=True)
        config.gpu_options.per_process_gpu_memory_fraction = 0.95
        init = tf.global_variables_initializer()
        bestRecall = 0.0
        path = os.path.join("dataset", "relWeight.npy")
        relWeight = np.load(path).item()
        with tf.Session(config=config) as sess:
            sess.run(init)
            # Load the pretrained checkpoint file xxx.ckpt
            saver_restore.restore(sess, resnet_model_path)
            Acc = []
            for i in range(epoch):
                train = TrainData.getNext()
                test = TestData.getNext()
                TestData.Length = []
                TrainStep = 0
                for temp_train in train:
                    inter, union, subject, objects, subLabel, objLabel, rel, spatial, imgName = temp_train
                    simRelations, disSimRelations, disSimRelationScore = relSim.each(rel, num=negative)
                    TrainDict = {
                            self.subjectImg: subject[0],
                            self.subjectMask: subject[1],
                            self.subjectLabel: subLabel,
                            self.spatial: spatial,
                            self.objectImg: objects[0],
                            self.objectMask: objects[1],
                            self.objectLabel: objLabel,

                            self.RelationClass: rel,
                            self.unionImg: union[0],
                            self.unionMask: union[1],

                            self.simRelation: simRelations,
                            self.disSimRelation: disSimRelations,
                            self.oo: disSimRelationScore,
                            self.relWeight: [relWeight.get(i, 0.0) for i in rel],
                            self.IsTraining: True}
                    if TrainStep > 500 or i >= 0:
                        TrainDict[self.a] = 0.5
                    else:
                        TrainDict[self.a] = 1.0
                    sess.run(train_step, feed_dict=TrainDict)
                    TrainLoss, TrainAcc = sess.run([loss, accuracy], feed_dict=TrainDict)
                    Acc.append(TrainAcc)
                    if TrainStep % 100 == 0:
                        TrainResult = "train step:{0}, all loss:{1}, extra loss:{3},acc:{2}".format(TrainStep, TrainLoss[0],
                                                                                 sum(Acc) / Acc.__len__(), floatShow(TrainLoss[1]))
                        Acc = []
                        print(TrainResult)
                    TrainStep += 1
                evalTest = EvalRecallUnion()
                if Error and isinstance(Error, str):
                    error = ErrorAnalysis(i, startPath=Error)
                Acc = []
                testImgName = (i for i in TestData.ImgName)
                # testFeature = []
                for temp_test in test:
                    inter, union, subject, objects, subLabel, objLabel, rel, spatial, imgName = temp_test
                    simRelations, disSimRelations, disSimRelationScore = relSim.each(rel, num=negative)
                    feedDict = {
                            self.subjectImg: subject[0],
                            self.subjectMask: subject[1],
                            self.subjectLabel: subLabel,
                            self.spatial: spatial,
                            self.objectImg: objects[0],
                            self.objectMask: objects[1],
                            self.objectLabel: objLabel,

                            self.unionImg: union[0],
                            self.unionMask: union[1],
                            self.RelationClass: rel,

                            self.simRelation: simRelations,
                            self.disSimRelation: disSimRelations,
                            self.oo: disSimRelationScore,

                            self.IsTraining: False}
                    Score = sess.run(EdgeScore, feed_dict=feedDict)
                    evalTest.add(rel, Score, subLabel, objLabel, subject[-1], objects[-1])

                    # varGet = sess.run(self.varGet, feed_dict=feedDict)
                    # assert varGet[0].__len__() == rel.__len__()
                    # visual = [(feature, relation) for feature, relation in zip(varGet[0], rel)]
                    # testFeature.extend(visual)

                evalTest.eval(TestData.Length)
                evalTest.show()
                # save the best model
                testRecall = evalTest.getRecall()
                if testRecall > bestRecall and save and testRecall>0.49:
                    time = datetime.datetime.now().strftime("%Y-%m-%d--%H:%M:%S")
                    bestRecall = testRecall
                    path = os.path.join("ckpt", "visual", time)
                    if not os.path.exists(path):
                        os.makedirs(path)
                    savePath = os.path.join(path, "transE")
                    # np.save(savePath, testFeature)
                    saver.save(sess, savePath)
                    print(time)
                if Error:
                    error.write()


if __name__ == "__main__":
    batch = 16
    TrainMat = "annotations_train.json"
    train_data = UnionData(TrainMat, "sg_train_images", batch=batch)
    RestorePath = os.path.join("ckpt", "Vgg", "vrd")
    # RestorePath = os.path.join("ckpt", "pretrain", "vgg_16.ckpt")
    TestMat = "annotations_test.json"
    test_data = UnionData(TestMat, "sg_test_images", batch=batch)
    StorePath = os.path.join("ckpt", "Vrd", "vrd")
    Res = VisualTransE()
    Res.TrainTest(train_data, RestorePath, test_data, Error=False, epoch=10)
