# import tensorflow as tf

# import numpy as np
# from configparser import ConfigParser
# import os
# import pdb
# from layer import *
# from EvalRecall import ErrorAnalysis
# from VIsualModel import vgg_16
# from layer import AlternatingHighWayCell
# from VrdContext import ContextModel
# import tensorflow.contrib.slim as slim
# from tensorflow.contrib.slim import nets
# from LoadMat import DataLoad
# from EvalRecall import EvalRecall
# from utils import leaky_relu, upconv
# import cv2
# np.set_printoptions(threshold=np.nan)
# os.environ["CUDA_VISIBLE_DEVICES"] = "1"
# cfg = ConfigParser()
# cfg.read("config.ini", encoding="utf-8-sig")
#
# class SpatialData(DataLoad):
#
#     def __init__(self, MatPath, ImagePath, negative=False, shuffle=False, Batch=1):
#         # load data from mat
#         path = os.path.join("dataset", "dataset", MatPath)
#         self.img_files = ImagePath
#         key = MatPath.split(".")[0]
#         # loading the object information and relation label from txt in dict
#         object_list_path = os.path.join("dataset", "dataset", "objectListN.txt")
#         self.object2id, self.id2object = self.load_list(object_list_path)
#         relation_list_path = os.path.join("dataset", "dataset", "predicate.txt")
#         self.rel2id, self.id2rel = self.load_list(relation_list_path)
#         relation_trans_path = os.path.join("dataset", "RelationAnalysis.txt")
#         self.relationAna = self.load_analysis(relation_trans_path)
#         # loading data from mat file in dict and get GroundTruth
#         # self.MatData = self.treat_data(key, sio.loadmat(path)[key][0])
#         self.MatData = self.TreatJSON(MatPath)
#         self.ImgName, self.Rols, self.RelationId, self.Length = self.GetData(self.MatData, negative=negative, PaddingSize=None)
#         self.Teacher, self.spatialTeacher = self.GetTeacherProb()
#         # set batch default
#         self.Batch = Batch
#
#
# class VisualSpatial(ContextModel):
#
#     def __init__(self):
#         ContextModel.__init__(self)
#         self.Regions = tf.placeholder(tf.float32, [None, self.ImgSize, self.ImgSize, 3])
#         self.ObjectClass = tf.placeholder(tf.int32, [None])
#         self.Mask = tf.placeholder(tf.float32, [None, self.MaskSize, self.MaskSize])
#
#     def GetArch(self, NumLayers=4, BatchSize=1, teacher=False):
#         # Regions = tf.concat((self.Regions, self.UnionImg), axis=0)
#         # print("Regions shape:", Regions.get_shape())
#         Visual = self.GetVisualFeature(self.Regions)
#         # SubVisual = Visual[:,:self.length,:]
#         # UnionVisual = Visual[:,self.length:,:]
#         Word = self.GetWordVector(self.ObjectClass, path=None)
#         WordVector = slim.fully_connected(Word, num_outputs=100, activation_fn=None, biases_initializer=None)
#         VisualWord = tf.concat((Visual, WordVector), axis=-1)
#         # Subjects, Objects = self.RelationLSTM(Visual, Word, BatchSize=BatchSize)
#         Subjects = slim.fully_connected(VisualWord, num_outputs=self.dim, activation_fn=None, biases_initializer=None)
#         Objects = slim.fully_connected(VisualWord, num_outputs=self.dim, activation_fn=None, biases_initializer=None)
#
#         # UnionVisual = slim.fully_connected(UnionVisual, num_outputs=self.dim, activation_fn=None, biases_initializer=None)
#         edge, index, maskScore, actionScore = self.getEdgeScore(Subjects, Objects, self.Mask)
#         # Edge, index = self.GetRelationCandidate(Subjects, Objects)
#         EdgeScore = tf.nn.softmax(edge, dim=-1)
#         ganLoss = self.GetGanLoss(Visual)
#         loss, accuracy, train_step = self.GetOptimizer(edge, ganLoss, self.RelationClass, Teacher=False)
#
#         return loss, accuracy, train_step, EdgeScore, index
#
#     @staticmethod
#     def GetPredict(RelationScore, index, IsKL=True):
#         """
#         :param RelationScore: [self.length*self.length, self.RelationClass]
#         :param index: [self.length*self.length, 2 ]
#         :return:
#         """
#         if np.asarray(index).shape[0] == 1:
#             index = np.squeeze(np.asarray(index),0)
#
#         relationClass = 71
#         candidate = np.reshape(np.repeat(index, repeats=relationClass, axis=0), (index.shape[0], -1, 2))
#         CandidateCls = np.tile(np.asarray(range(relationClass)), index.shape[0])
#         CandidateCls = np.reshape(CandidateCls, (index.shape[0], relationClass, 1))
#         candidate = np.concatenate((candidate, CandidateCls,np.expand_dims(RelationScore, axis=-1)), axis=-1)
#         candidate = np.reshape(candidate, (-1, 4))
#         candidate = sorted(candidate, key=lambda x: x[-1], reverse=True)
#         candidate = np.delete(candidate, -1, axis=-1)
#
#         RelationCls = np.expand_dims(np.argmax(RelationScore, axis=-1), -1)
#         Score = np.expand_dims(np.max(RelationScore, axis=-1), -1)
#         PredictTriad = np.concatenate((index, RelationCls, Score), axis=-1)
#         # print(PredictTriad.shape)
#         PredictTriad = sorted(PredictTriad, key=lambda x:x[-1], reverse=True)
#         PredictTriad = np.delete(PredictTriad, -1, axis=-1)
#
#         return PredictTriad, Score, candidate
#
#     def GetGanLoss(self, visualFeature):
#         with tf.variable_scope("gan"):
#             semantic_size = 312
#             visual_feature = visualFeature
#             recon_size, enc_inputsize = 256, 224
#             print("visual feature", visual_feature.get_shape())
#
#             recon_img, _ = self.generator_caffenet_fc6(visual_feature)
#             recon_topleft = (int((recon_size - enc_inputsize) / 2), int((recon_size - enc_inputsize) / 2))
#             recon_img = tf.reshape(recon_img, (-1, recon_size, recon_size, 3))
#             recon_img = recon_img[:, recon_topleft[0]:recon_topleft[0]+enc_inputsize,
#                                                 recon_topleft[1]:recon_topleft[1]+enc_inputsize, :]
#             print("recon img shape", recon_img.get_shape())
#             L_recon_img = 0.003 * tf.losses.mean_squared_error(labels=self.Regions, predictions=recon_img)
#
#             # visual feature 这个部分应该经过两层全连接转化为semantic域
#             fc1 = leaky_relu(slim.fully_connected(visual_feature, num_outputs=1024, activation_fn=None))
#             output = slim.fully_connected(fc1, 1, scope='output', activation_fn=None)
#             L_rank_gen_E = -5 * tf.reduce_mean(tf.sigmoid(output))
#
#
#             map1 = leaky_relu(slim.fully_connected(visual_feature, num_outputs=1024, activation_fn=None, scope="gan_f"))
#             map_rank_semantic = leaky_relu(slim.fully_connected(map1, num_outputs=semantic_size, activation_fn=None, scope="gan_f1"))
#             map_rank_semantic_norm = tf.norm(map_rank_semantic, axis=1)
#             L_map_rank = 0.2 * tf.losses.mean_squared_error(
#                 labels=tf.ones_like(map_rank_semantic_norm) * 1,
#                 predictions=map_rank_semantic_norm)
#             return L_recon_img+L_map_rank+L_rank_gen_E
#
#     def GetOptimizer(self, logits, ganLoss, labels, Teacher=False, alpha=0.5):
#         print("label shape", labels[:, 2].get_shape())
#         edgeLabel, maskLabel, actionLabel = labels[:, 2], labels[:, 3], labels[:, 4]
#         edgeLosses = tf.nn.sparse_softmax_cross_entropy_with_logits(
#             labels=edgeLabel, logits=logits)
#         # L_recon_feat = 3 * tf.losses.mean_squared_error(labels=self.input_image_comp, predictions=self.recon_image_comp)
#         vars = tf.trainable_variables()
#         lossL2 = tf.add_n([tf.nn.l2_loss(v) for v in vars
#                            if 'bias' not in v.name]) * 0.0001
#         loss = tf.reduce_mean(edgeLosses) + ganLoss # + lossL2
#         optimizer = tf.train.AdamOptimizer(learning_rate=self.learning_rate, beta1=0.5, beta2=0.999)
#
#         logits = tf.nn.softmax(logits)
#         classes = tf.argmax(logits, axis=1, name='classes')
#         accuracy = tf.reduce_mean(tf.cast(
#             tf.equal(tf.cast(classes, dtype=tf.int32), edgeLabel), dtype=tf.float32))
#
#         train_step = slim.learning.create_train_op(loss, optimizer)
#         return loss, accuracy, train_step
#
#     def generator_caffenet_fc6(self, input_feat, reuse=False, trainable=True):
#         with tf.variable_scope('generator', reuse=reuse) as vs:
#             assert input_feat.get_shape().as_list()[-1] == 4096
#             # input_feat = tf.placeholder(tf.float32, shape=(None, 4096), name='feat')
#             relu_defc7 = leaky_relu(slim.fully_connected(input_feat, 4096, scope='defc7', activation_fn=None))
#             relu_defc6 = leaky_relu(slim.fully_connected(relu_defc7, 4096, scope='defc6', activation_fn=None))
#             relu_defc5 = leaky_relu(slim.fully_connected(relu_defc6, 4096, scope='defc5', activation_fn=None))
#             reshaped_defc5 = tf.reshape(relu_defc5, [-1, 256, 4, 4])
#
#             relu_deconv5 = leaky_relu(upconv(tf.transpose(reshaped_defc5, perm=[0, 2, 3, 1]), 256, 4, 2,
#                                              'deconv5', biased=True, trainable=trainable))
#             relu_conv5_1 = leaky_relu(upconv(relu_deconv5, 512, 3, 1, 'conv5_1', biased=True, trainable=trainable))
#             relu_deconv4 = leaky_relu(upconv(relu_conv5_1, 256, 4, 2, 'deconv4', biased=True, trainable=trainable))
#             relu_conv4_1 = leaky_relu(upconv(relu_deconv4, 256, 3, 1, 'conv4_1', biased=True, trainable=trainable))
#             relu_deconv3 = leaky_relu(upconv(relu_conv4_1, 128, 4, 2, 'deconv3', biased=True, trainable=trainable))
#             relu_conv3_1 = leaky_relu(upconv(relu_deconv3, 128, 3, 1, 'conv3_1', biased=True, trainable=trainable))
#             deconv2 = leaky_relu(upconv(relu_conv3_1, 64, 4, 2, 'deconv2', biased=True, trainable=trainable))
#             deconv1 = leaky_relu(upconv(deconv2, 32, 4, 2, 'deconv1', biased=True, trainable=trainable))
#             deconv0 = upconv(deconv1, 3, 4, 2, 'deconv0', biased=True, trainable=trainable)
#
#         variables = tf.contrib.framework.get_variables(vs)
#
#         return deconv0, variables
#
# if __name__ == "__main__":
#     TrainMat = "annotations_train.json"
#     train_data = SpatialData(TrainMat, "sg_train_images", False)
#     RestorePath = os.path.join("ckpt", "Vgg", "vrd")
#     TestMat = "annotations_test.json"
#     test_data = SpatialData(TestMat, "sg_test_images", False)
#     StorePath = os.path.join("ckpt", "Vrd", "vrd")
#     Res = VisualSpatial()
#     Res.TrainTest(train_data, RestorePath, test_data, Error="GanTry")

import os
import json
import pdb
from scipy.io import loadmat
import numpy as np

# path = os.path.join("dataset", "json_dataset", "annotations_train.json")
# trainData = json.load(open(path))
# trainPhrase = []
# for name, rels in trainData.items():
#     for rel in rels:
#         temp = (rel["subject"]["category"], rel["object"]["category"], rel["predicate"])
#         trainPhrase.append(temp)
# print(trainPhrase.__len__(), set(trainPhrase).__len__())
savePath = os.path.join("dataset", "json_dataset", "zeroShot.npy")
data = np.load(savePath)
extraData = dict(zip([tuple(i) for i in data], [1]*len(data)))
path = os.path.join("dataset", "json_dataset", "annotations_test.json")
testData = json.load(open(path))
testPhrase = []
testLength = []
for name, rels in testData.items():
    tempPhrase = []
    if name == "4392556686_44d71ff5a0_o.jpg":
        print(len(rels))
    for rel in rels:
        temp = (rel["subject"]["category"],rel["object"]["category"], rel["predicate"])
        if extraData.get(temp, None):
            tempPhrase.append(temp)
    testPhrase.extend(tempPhrase)
    testLength.append(len(rels))
print(testPhrase.__len__())
# zero = [i for i in testPhrase if i not in trainPhrase]
# print(zero.__len__())
sumRes = 0
path = os.path.join("dataset", "json_dataset", "zeroShot.mat")
zeroShotData = loadmat(path)["zeroShot"]
gtPath = os.path.join("dataset", "json_dataset", "gt.mat")
gtData = loadmat(gtPath)

labelData = gtData['gt_tuple_label']
subBbox = gtData["gt_sub_bboxes"]
objBbox = gtData["gt_obj_bboxes"]
zeroShotPhrase = []

# for phrases, labels, subs, objs in zip(labelData[0], zeroShotData[0], subBbox[0], objBbox[0]):
#     try:
#         for phrase, label, sub, obj in zip(phrases, labels[0], subs, objs):
#             if label == 1:
#                 zeroShotPhrase.append(tuple(phrase))
#     except IndexError:
#         pass
# # savePath = os.path.join("dataset", "json_dataset", "zeroShot")
# print(zeroShotPhrase.__len__())
# np.save(savePath, zero)
# print("save success")
