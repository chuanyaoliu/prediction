import tensorflow as tf
import numpy as np
import datetime
from configparser import ConfigParser
import os
import pdb
from layer import *
from EvalRecall import ErrorAnalysis, EvalRecallUnion
from VIsualModel import vgg_16
from layer import AlternatingHighWayCell
from VrdAttention import VisualAttention
import tensorflow.contrib.slim as slim
from tensorflow.contrib.slim import nets
from LoadMat import DataLoad
from MatDRNet import UnionData
from EvalRecall import EvalRecall
np.set_printoptions(threshold=np.nan)
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
cfg = ConfigParser()
cfg.read("config.ini", encoding="utf-8-sig")

class VisualTransE(VisualAttention):
    def __init__(self):
        VisualAttention.__init__(self)
        self.learning_rate = 0.0001
        self.subjectMask = tf.placeholder(tf.float32, [None, self.MaskSize, self.MaskSize])
        self.objectMask = tf.placeholder(tf.float32, [None, self.MaskSize, self.MaskSize])
        self.spatial = tf.placeholder(tf.float32, [None, 4])
        self.varGet = []
    # def getArch(self):
    # transE的直接改进，效果最佳的为0.441 ->0.450
    #     Img = tf.concat((self.subjectImg, self.objectImg), axis=0)
    #     unionVisual = self.GetVisualFeature(Img)
    #     unionVisual = tf.squeeze(unionVisual, 0) if unionVisual.get_shape()[0] == 1 else unionVisual
    #     subVisual, objVisual = tf.split(unionVisual, 2, axis=0)
    #     visual = subVisual - objVisual
    #     visual = slim.fully_connected(visual, num_outputs=150)
    #     with tf.variable_scope("visual_scale", reuse=tf.AUTO_REUSE):
    #         alpha = tf.get_variable(name='alpha', shape=(150,), trainable=True)
    #         beta = tf.get_variable(name='beta', shape=(150,), trainable=True)
    #         output = alpha * visual + beta
    #     visual_feature = output
    #
    #     objectClass = tf.concat((self.subjectLabel, self.objectLabel), axis=0)
    #     WordVector = tf.one_hot(objectClass, depth=self.relationClass)
    #     # WordVector = self.GetWordVector(objectClass, path=None)
    #     # WordVector = tf.squeeze(WordVector, axis=0)
    #     subjectWordVector, objectWordVector = tf.split(WordVector, 2, axis=0)
    #     wordVector = subjectWordVector - objectWordVector
    #     wordVector = slim.fully_connected(wordVector, 300)
    #     wordVector = slim.fully_connected(wordVector, 200)
    #     with tf.variable_scope("word_scale", reuse=False):
    #         alpha = tf.get_variable(name='alpha', shape=(200,), trainable=True)
    #         beta = tf.get_variable(name='beta', shape=(200,), trainable=True)
    #         output = alpha * wordVector + beta
    #     word_feature = output
    #     # edgeMask = tf.stack((self.subjectMask, self.objectMask, self.unionMask), axis=-1)
    #     # edgeMask = tf.squeeze(self.GetPositionMask(edgeMask), axis=0)
    #     edgeMask = self.spatial
    #     edgeVector = slim.fully_connected(edgeMask, 20)
    #     edgeVector = slim.fully_connected(edgeVector, 10)
    #     with tf.variable_scope("spatial_scale", reuse=False):
    #         alpha = tf.get_variable(name='alpha', shape=(10,), trainable=True)
    #         beta = tf.get_variable(name='beta', shape=(10,), trainable=True)
    #         output = alpha * edgeVector + beta
    #     edgeFeature = output
    #
    #     feature = tf.concat((visual_feature, word_feature, edgeFeature), axis=-1)
    #     edge = slim.fully_connected(feature, self.relationClass)
    #     EdgeScore = tf.nn.softmax(edge, dim=-1)
    #
    #     relationWordVector = self.getRelWordVector(self.RelationClass)
    #     relationWordVector = slim.fully_connected(relationWordVector, num_outputs=360)
    #     print("relation feature vector shape:", relationWordVector.get_shape()[-1])
    #
    #     edgeLoss = tf.reduce_sum(tf.square(feature - relationWordVector), axis=-1) * 0.01
    #     # edgeLoss = tf.reduce_mean(edgeLoss, axis=0)*0.01
    #     # edgeLoss = None
    #     loss, accuracy, train_step = self.GetOptimizer(edge, self.RelationClass, maskFeature=edgeLoss)
    #
    #     return loss, accuracy, train_step, EdgeScore,  # index

    # def getArch(self):
    #     # 将visual vector变成250，edge vector变成50, 最佳效果就会变成0.452
    #     Img = tf.concat((self.subjectImg, self.objectImg), axis=0)
    #     unionVisual = self.GetVisualFeature(Img)
    #     unionVisual = tf.squeeze(unionVisual, 0) if unionVisual.get_shape()[0] == 1 else unionVisual
    #     subVisual, objVisual = tf.split(unionVisual, 2, axis=0)
    #     visual = subVisual - objVisual
    #     visual = slim.fully_connected(visual, num_outputs=250)
    #     with tf.variable_scope("visual_scale", reuse=tf.AUTO_REUSE):
    #         alpha = tf.get_variable(name='alpha', shape=(250,), trainable=True)
    #         beta = tf.get_variable(name='beta', shape=(250,), trainable=True)
    #         output = alpha * visual + beta
    #     visual_feature = output
    #
    #     objectClass = tf.concat((self.subjectLabel, self.objectLabel), axis=0)
    #     WordVector = tf.one_hot(objectClass, depth=self.relationClass)
    #     subjectWordVector, objectWordVector = tf.split(WordVector, 2, axis=0)
    #     wordVector = subjectWordVector - objectWordVector
    #     wordVector = slim.fully_connected(wordVector, 300)
    #     wordVector = slim.fully_connected(wordVector, 200)
    #     with tf.variable_scope("word_scale", reuse=False):
    #         alpha = tf.get_variable(name='alpha', shape=(200,), trainable=True)
    #         beta = tf.get_variable(name='beta', shape=(200,), trainable=True)
    #         output = alpha * wordVector + beta
    #     word_feature = output
    #     # edgeMask = tf.stack((self.subjectMask, self.objectMask, self.unionMask), axis=-1)
    #     # edgeMask = tf.squeeze(self.GetPositionMask(edgeMask), axis=0)
    #     edgeMask = self.spatial
    #     edgeVector = slim.fully_connected(edgeMask, 20)
    #     edgeVector = slim.fully_connected(edgeVector, 50)
    #     with tf.variable_scope("spatial_scale", reuse=False):
    #         alpha = tf.get_variable(name='alpha', shape=(50,), trainable=True)
    #         beta = tf.get_variable(name='beta', shape=(50,), trainable=True)
    #         output = alpha * edgeVector + beta
    #     edgeFeature = output
    #
    #     feature = tf.concat((visual_feature, word_feature, edgeFeature), axis=-1)
    #     edge = slim.fully_connected(feature, self.relationClass)
    #     EdgeScore = tf.nn.softmax(edge, dim=-1)
    #
    #     relationWordVector = self.getRelWordVector(self.RelationClass)
    #     relationWordVector = slim.fully_connected(relationWordVector, num_outputs=500)
    #     print("relation feature vector shape:", relationWordVector.get_shape()[-1])
    #
    #     # edgeLoss = tf.reduce_sum(tf.square(feature - relationWordVector), axis=-1) * 0.01
    #     # edgeLoss = tf.reduce_mean(edgeLoss, axis=0)*0.01
    #     edgeLoss = None
    #     loss, accuracy, train_step = self.GetOptimizer(edge, self.RelationClass, maskFeature=edgeLoss)
    #
    #     return loss, accuracy, train_step, EdgeScore,  # index

    # def getArch(self):
    #     # 将visual vector变成250，edge vector变成50, 最佳效果就会变成0.452
    #     # 加入word vector之后会变成最高0.527的样子， 尝试加入extra loss看一下
    #     # 将visual vector变成450，edge vector变成50,不加入word vector时会变成0.504的样子， 加入extra loss则变成0.514,
    #     # 实验波动为0.5095至0.514
    #     Img = tf.concat((self.subjectImg, self.objectImg), axis=0)
    #     unionVisual = self.GetVisualFeature(Img)
    #     unionVisual = tf.squeeze(unionVisual, 0) if unionVisual.get_shape()[0] == 1 else unionVisual
    #     subVisual, objVisual = tf.split(unionVisual, 2, axis=0)
    #     subVisual = slim.fully_connected(subVisual, 450)
    #     objVisual = slim.fully_connected(objVisual, 450)
    #
    #     objectClass = tf.concat((self.subjectLabel, self.objectLabel), axis=0)
    #     # WordVector = tf.squeeze(self.GetWordVector(objectClass), axis=0)
    #     WordVector = tf.one_hot(objectClass, depth=self.relationClass)
    #     subjectWordVector, objectWordVector = tf.split(WordVector, 2, axis=0)
    #     subjectWordVector = slim.fully_connected(subjectWordVector, 450)
    #     objectWordVector = slim.fully_connected(objectWordVector, 450)
    #     # wordVector = subjectWordVector - objectWordVector
    #     # wordVector = slim.fully_connected(wordVector, 300)
    #     # wordVector = slim.fully_connected(wordVector, 200)
    #     subVec = subVisual*subjectWordVector
    #     objVec = objVisual*objectWordVector
    #     edgeVec = slim.fully_connected(subVec-objVec, 450)
    #     # edgeMask = tf.stack((self.subjectMask, self.objectMask, self.unionMask), axis=-1)
    #     # edgeMask = tf.squeeze(self.GetPositionMask(edgeMask), axis=0)
    #     edgeMask = self.spatial
    #     edgeVector = slim.fully_connected(edgeMask, 20)
    #     edgeVector = slim.fully_connected(edgeVector, 50)
    #
    #     feature = tf.concat((edgeVec, edgeVector), axis=-1)
    #     edge = slim.fully_connected(feature, self.relationClass)
    #     EdgeScore = tf.nn.softmax(edge, dim=-1)
    #
    #     relationWordVector = self.getRelWordVector(self.RelationClass)
    #     relationWordVector = slim.fully_connected(relationWordVector, num_outputs=500)
    #     print("relation feature vector shape:", relationWordVector.get_shape()[-1])
    #
    #     edgeLoss = tf.reduce_sum(tf.square(feature - relationWordVector), axis=-1) * 0.01
    #     # edgeLoss = tf.reduce_mean(edgeLoss, axis=0)*0.01
    #     # edgeLoss = None
    #     loss, accuracy, train_step = self.GetOptimizer(edge, self.RelationClass, maskFeature=edgeLoss)
    #
    #     return loss, accuracy, train_step, EdgeScore,  # index

    def getArch(self):
        # 尝试保持relation之间的语义关系
        Img = tf.concat((self.subjectImg, self.objectImg), axis=0)
        unionVisual = self.GetVisualFeature(Img)
        unionVisual = tf.squeeze(unionVisual, 0) if unionVisual.get_shape()[0] == 1 else unionVisual
        subVisual, objVisual = tf.split(unionVisual, 2, axis=0)
        featureDim = 450
        subVisual = slim.fully_connected(subVisual, featureDim)
        objVisual = slim.fully_connected(objVisual, featureDim)
        self.varGet.append([subVisual, objVisual])
        objectClass = tf.concat((self.subjectLabel, self.objectLabel), axis=0)
        # WordVector = tf.squeeze(self.GetWordVector(objectClass), axis=0)
        WordVector = tf.one_hot(objectClass, depth=self.relationClass)
        subjectWordVector, objectWordVector = tf.split(WordVector, 2, axis=0)

        subjectWordVector = slim.fully_connected(subjectWordVector, featureDim)
        objectWordVector = slim.fully_connected(objectWordVector, featureDim)
        self.varGet.append([subjectWordVector, objectWordVector])
        # wordVector = subjectWordVector - objectWordVector
        # wordVector = slim.fully_connected(wordVector, 300)
        # wordVector = slim.fully_connected(wordVector, 200)
        # subVec = subVisual*subjectWordVector
        # objVec = objVisual*objectWordVector
        # subVec = tf.concat((subVisual,subjectWordVector), axis=-1)
        # objVec = tf.concat((objVisual, objectWordVector), axis=-1)
        # edgeVec = slim.fully_connected(subVec-objVec, featureDim)
        edgeVec = slim.fully_connected((subVisual-objVisual)*(subjectWordVector-objectWordVector), featureDim)
        # edgeMask = self.spatial
        # edgeVector = slim.fully_connected(edgeMask, 50)
        # edgeVector = slim.fully_connected(edgeVector, featureDim)
        # feature = edgeVec * edgeVector
        edgeMask = self.spatial
        edgeVector = slim.fully_connected(edgeMask, 20)
        edgeVector = slim.fully_connected(edgeVector, 50)
        self.varGet.append(edgeVector)
        feature = tf.concat((edgeVec, edgeVector), axis=-1)
        # 加上来l2正则之后，0.534 ->0.507, 加上曾经的extraLoss为0.508
        # feature = tf.nn.l2_normalize(feature, dim=-1)
        edge = slim.fully_connected(feature, self.relationClass)
        EdgeScore = tf.nn.softmax(edge, dim=-1)
        self.varGet.append(EdgeScore)
        # extraLoss = False
        # if extraLoss:
        #     relationWordVector = self.getRelWordVector(self.RelationClass)
        #     relationWordVector = slim.fully_connected(relationWordVector, num_outputs=500)
        #     # edgeLoss = tf.reduce_sum(tf.square(feature - relationWordVector), axis=-1) * 0.01
        #     edgeLoss = tf.reduce_sum(tf.square(feature - relationWordVector), axis=-1) * 0.01
        # else:
        #     Vectors = self.getRelVector(self.RelationClass)
        #     self.varGet.append(self.relEmbedding)
        #     # self.varGet.append(Vectors)
        #     # Vectors = self.getRelVec(self.RelationClass)
        #     edgeLoss = self.getExtraLoss(feature, Vectors)
        # edgeLoss = tf.reduce_sum(tf.square(feature - Vectors), axis=-1) * 0.1
        # edgeLoss = tf.reduce_mean(edgeLoss, axis=0)*0.01
        # for i in tf.global_variables():
        #     print(i)
        # pdb.set_trace()
        edgeLoss = None
        loss, accuracy, train_step = self.GetOptimizer(edge, self.RelationClass, maskFeature=edgeLoss)
        return loss, accuracy, train_step, EdgeScore,  # index

    def getRelVector(self, relation, path=None, dims=500):
        with tf.variable_scope("rel2Vec"):
            LoadPath = path if path else os.path.join("dataset", "InitRelEmbedding.npy")
            init = tf.constant(np.load(LoadPath), dtype=tf.float32)
            relEmbedding = tf.get_variable("relEmbedding", initializer=init, trainable=True)
            # # trans the vector
            # Vectors = tf.nn.embedding_lookup(relEmbedding, relation)
            # Vectors = tf.expand_dims(Vectors, axis=1)
            # simVectors = tf.nn.embedding_lookup(relEmbedding, simRelation)
            # disSimVectors = tf.nn.embedding_lookup(relEmbedding, disSimRelation)
            # vec = tf.concat((Vectors, simVectors, disSimVectors), axis=1)
            # vec = slim.fully_connected(vec, num_outputs=dims)
            # Vectors, simVectors, disSimVectors = tf.split(vec, [1, negative, negative], axis=1)
            # Vectors = tf.squeeze(Vectors, axis=1)

            # # trans the all martix
            relEmbedding = slim.fully_connected(relEmbedding, dims, scope="rel_full")
            self.relEmbedding = relEmbedding
            Vectors = tf.nn.embedding_lookup(relEmbedding, relation)

        return Vectors

    def getRelVec(self, relation, path=None, dims=500):
        with tf.variable_scope("rel2vec"):
            r = tf.sqrt(tf.cast(6 / dims, dtype=tf.float32))
            relEmbedding = tf.get_variable("relEmbedding", shape=[self.relationClass, dims],
                                           initializer=tf.random_uniform_initializer(
                                               minval=-r, maxval=r))
            Vectors = tf.nn.embedding_lookup(relEmbedding, relation)
            Vectors = tf.expand_dims(Vectors, axis=1)

        return Vectors

    def getExtraLoss(self, feature, Vectors):
        # 在单独使用simLoss时，获得了改善但是代码被改烂了， 只能看出是使用了margin loss的方式
        def cosine(q, a, mode=True):
            if mode is True:
                pooled_len_1 = tf.sqrt(tf.reduce_sum(q * q, -1))
                pooled_len_2 = tf.sqrt(tf.reduce_sum(a * a, -1))
                pooled_mul_12 = tf.reduce_sum(q * a, -1)
                score = tf.div(pooled_mul_12, pooled_len_1 * pooled_len_2 + 1e-8)
            else:
                score = tf.reduce_sum(tf.square(q - a), axis=-1)
            return score
        # sameLoss = -cosine(feature, Vectors)
        # sameLoss = tf.reduce_sum(tf.square(feature - Vectors), axis=-1)* 0.008
        # disSimLoss = tf.reduce_mean(cosine(simFeature, disSimVectors)*simWeight, axis=-1)
        # disSimLoss = -tf.reduce_mean(tf.reduce_sum(tf.square(simFeature-disSimVectors), axis=-1)*simWeight, axis=-1)

        # same+sim best 0.514
        # sim = tf.reduce_sum(tf.square(simFeature-simVectors), axis=-1)* 0.1
        # margin = 5
        # sim = tf.maximum(0., margin - sim)
        # simLoss = tf.reduce_mean(sim, axis=-1)
        # allLoss = simLoss + sameLoss
        # # simLoss = tf.maximum(0., globalWeight-sim) + tf.maximum(0., sim-self.oo)
        # # simLoss = tf.reduce_mean(simLoss, -1)

        # same + sim 使用margin loss约束类间向量
        # # 使用margin loss 拉大类别中心间的距离
        # margin = 1.0
        # sim = tf.reduce_sum(tf.square(simVectors - tf.expand_dims(Vectors, 1)), axis=-1)* 0.01
        # simLoss = tf.maximum(0., margin-sim)
        # simLoss = tf.reduce_mean(simLoss, axis=-1)*0.01
        # allLoss = sameLoss

        # #约束类别中心至相同的模值
        # sameLoss = tf.reduce_sum(tf.square(feature - Vectors), axis=-1) * 0.01
        # disLabel = tf.reduce_mean(tf.reduce_sum(tf.square(self.relEmbedding), axis=-1), axis=-1)
        # disVector = tf.reduce_sum(tf.square(Vectors), axis=-1)
        # dis = tf.square(disVector - disLabel)
        # disLoss = tf.maximum(0., dis)*0.001
        # # best 0.515--0.513 差不多
        # allLoss = disLoss*0.25+sameLoss*0.5
        sameLoss = tf.reduce_sum(tf.square(feature - Vectors), axis=-1) * 0.008
        disLabel = tf.reduce_mean(tf.reduce_sum(tf.square(self.relEmbedding), axis=-1), axis=-1)
        disVector = tf.reduce_sum(tf.square(Vectors), axis=-1)
        dis = tf.square(disVector - disLabel)
        disLoss = tf.maximum(0., dis)*0.001
        allLoss = sameLoss*0.5 + disLoss*0.25
        # allLoss = sameLoss*0.5
        return allLoss

    def GetVisualFeature(self, Regions):
        ResNetInput = tf.reshape(Regions, (-1, self.ImgSize, self.ImgSize, 3))
        with slim.arg_scope(nets.vgg.vgg_arg_scope()):
            net, endpoints, feature = vgg_16(ResNetInput, num_classes=None, is_training=self.IsTraining)
        # x_h, out = CANAttention(feature, is_training=self.IsTraining)
        # out = SpatialATT(feature)

        # feature pool5 对应的feature map
        out = feature
        # with tf.variable_scope("visual_concept"):
        #     visualConcept = slim.conv2d(out, 256, kernel_size=1, stride=1)
        #     visualConcept = slim.dropout(visualConcept, self.dropout, is_training=self.IsTraining, scope="drop6")
        #     voting = slim.conv2d(visualConcept, 512, kernel_size=15, stride=1)
        # out, weight = SelfATT(feature)
        with tf.variable_scope('vgg_16', reuse=True):
            # Use conv2d instead of fully_connected layers.
            out = slim.conv2d(out, 4096, [7, 7], padding="VALID", scope='fc6')
            out = slim.dropout(out, 0.5, is_training=self.IsTraining,
                               scope='dropout6')
            out = slim.conv2d(out, 4096, [1, 1], scope='fc7')
        VectorDim = out.get_shape()[-1]
        out = tf.reshape(out, (1, -1, VectorDim))
        # out = tf.concat((x_h, out), axis=-1)
        return out

    def GetOptimizer(self, logits, labels, Teacher=True, alpha=0.5, maskFeature=None):
        edgeLabel = labels
        edgeLosses = tf.nn.softmax_cross_entropy_with_logits(
                     labels=tf.one_hot(edgeLabel, depth=self.relationClass), logits=logits)
        losses = edgeLosses # + maskLosses + actionLosses
        optimizer = tf.train.AdamOptimizer(learning_rate=self.learning_rate)
        if maskFeature is not None:
            losses += maskFeature
            maskLoss = tf.reduce_mean(maskFeature)
            print("add extra loss")
        else:
            maskLoss = tf.reduce_mean(tf.zeros_like(losses))
        logits = tf.nn.softmax(logits)
        classes = tf.argmax(logits, axis=1, name='classes')
        accuracy = tf.reduce_mean(tf.cast(
            tf.equal(tf.cast(classes, dtype=tf.int32), edgeLabel), dtype=tf.float32))
        loss = tf.reduce_mean(losses)
        train_step = slim.learning.create_train_op(loss, optimizer)#, variables_to_train=var_list)
        # # use different lr
        # varRel = [i for i in tf.trainable_variables() if "rel2Vec/relEmbedding" in i.name]
        # varList = [i for i in tf.trainable_variables() if "rel2Vec/relEmbedding" not in i.name]
        # # 0.05/0.04时最佳0.516, 可以哟；0.01时，为0.512；0.005时，为0.506，
        # # 0.03时为0.510；0.07时为0.514; 0.09时,为0.510;
        # lr = 0.05
        # optimizerRel = tf.train.AdamOptimizer(lr)
        # grads = tf.gradients(loss, varList + varRel)
        # grads1 = grads[:len(varList)]
        # grads2 = grads[len(varList):]
        # train_op1 = optimizer.apply_gradients(zip(grads1, varList))
        # train_op2 = optimizerRel.apply_gradients(zip(grads2, varRel))
        # train_step = tf.group(train_op1, train_op2)
        return [loss, maskLoss], accuracy, train_step

    def TrainTest(self, TrainData, resnet_model_path, TestData, Error=True, epoch=10, save=True):
        BatchSize = TrainData.Batch
        def floatShow(a, b=5):
            a = str(a)
            return a[:b]
        loss, accuracy, train_step, EdgeScore = self.getArch()
        saver_restore, saver = self.GetSaver()
        config = tf.ConfigProto(allow_soft_placement=True)
        config.gpu_options.per_process_gpu_memory_fraction = 0.95
        init = tf.global_variables_initializer()
        bestRecall = 0.0
        with tf.Session(config=config) as sess:
            sess.run(init)
            # Load the pretrained checkpoint file xxx.ckpt
            saver_restore.restore(sess, resnet_model_path)
            Acc = []
            for i in range(epoch):
                train = TrainData.getNext()
                test = TestData.getNext()
                TestData.Length = []
                TrainStep = 0
                for temp_train in train:
                    inter, union, subject, objects, subLabel, objLabel, rel, spatial,imgName = temp_train
                    # simRelations, disSimRelations, disSimRelationScore = relSim.each(rel, num=negative)
                    TrainDict = {
                            self.subjectImg: subject[0],
                            self.subjectMask: subject[1],
                            self.subjectLabel: subLabel,
                            self.spatial: spatial,
                            self.objectImg: objects[0],
                            self.objectMask: objects[1],
                            self.objectLabel: objLabel,

                            self.RelationClass: rel,
                            self.unionImg: union[0],
                            self.unionMask: union[1],

                            # self.simRelation: simRelations,
                            # self.disSimRelation: disSimRelations,
                            # self.oo: disSimRelationScore,

                            self.IsTraining: True}
                    if TrainStep > 500 or i >= 0:
                        TrainDict[self.a] = 0.5
                    else:
                        TrainDict[self.a] = 1.0
                    sess.run(train_step, feed_dict=TrainDict)
                    TrainLoss, TrainAcc = sess.run([loss, accuracy], feed_dict=TrainDict)
                    Acc.append(TrainAcc)
                    if TrainStep % 100 == 0:
                        TrainResult = "train step:{0}, all loss:{1}, extra loss:{3},acc:{2}".format(TrainStep, TrainLoss[0],
                                                                                 sum(Acc) / Acc.__len__(), floatShow(TrainLoss[1]))
                        Acc = []
                        print(TrainResult)
                    TrainStep += 1
                evalTest = EvalRecallUnion()
                if Error and isinstance(Error, str):
                    error = ErrorAnalysis(i, startPath=Error)
                Acc = []
                testImgName = (i for i in TestData.ImgName)
                # testFeature = []
                for temp_test in test:
                    inter, union, subject, objects, subLabel, objLabel, rel, spatial, imgName = temp_test
                    # simRelations, disSimRelations, disSimRelationScore = relSim.each(rel, num=negative)
                    feedDict = {
                            self.subjectImg: subject[0],
                            self.subjectMask: subject[1],
                            self.subjectLabel: subLabel,
                            self.spatial: spatial,
                            self.objectImg: objects[0],
                            self.objectMask: objects[1],
                            self.objectLabel: objLabel,

                            self.unionImg: union[0],
                            self.unionMask: union[1],
                            self.RelationClass: rel,

                            # self.simRelation: simRelations,
                            # self.disSimRelation: disSimRelations,
                            # self.oo: disSimRelationScore,

                            self.IsTraining: False}
                    Score = sess.run(EdgeScore, feed_dict=feedDict)
                    evalTest.add(rel, Score, subLabel, objLabel, subject[-1], objects[-1])

                    # varGet = sess.run(self.varGet, feed_dict=feedDict)
                    # assert varGet[0].__len__() == rel.__len__()
                    # visual = [(feature, relation) for feature, relation in zip(varGet[0], rel)]
                    # testFeature.extend(visual)

                evalTest.eval(TestData.Length)
                evalTest.show()
                # save the best model
                testRecall = evalTest.getRecall()
                if testRecall > bestRecall and save:
                    time = datetime.datetime.now().strftime("%Y-%m-%d--%H:%M:%S")
                    bestRecall = testRecall
                    path = os.path.join("ckpt", "visual", time)
                    if not os.path.exists(path):
                        os.makedirs(path)
                    savePath = os.path.join(path, "transE")
                    # np.save(savePath, testFeature)
                    saver.save(sess, savePath)
                    print(time)
                if Error:
                    error.write()

    def testVisual(self, testData, restore, trainData):
        loss, accuracy, train_step, EdgeScore = self.getArch()
        saver = tf.train.Saver()
        config = tf.ConfigProto(allow_soft_placement=True)
        config.gpu_options.per_process_gpu_memory_fraction = 0.95
        init = tf.global_variables_initializer()
        with tf.Session(config=config) as sess:
            sess.run(init)
            # Load the pretrained checkpoint file xxx.ckpt
            saver.restore(sess, restore)
            test = testData.getNext()
            train = trainData.getNext()
            testData.Length = []
            evalTest = EvalRecallUnion()
            # error = ErrorAnalysis(0)
            subVisuals, objVisuals = [], []
            subVectors, objVectors = [], []
            subLabels, objLabels = [], []
            edgeVectors, rels = [], []
            values = []
            for temp_train in train:
                inter, union, subject, objects, subLabel, objLabel, rel, spatial, imgName = temp_train
                # simRelations, disSimRelations, disSimRelationScore = relSim.each(rel, num=negative)
                feedDict = {
                    self.subjectImg: subject[0],
                    self.subjectMask: subject[1],
                    self.subjectLabel: subLabel,
                    self.spatial: spatial,
                    self.objectImg: objects[0],
                    self.objectMask: objects[1],
                    self.objectLabel: objLabel,
                    self.unionImg: union[0],
                    self.unionMask: union[1],
                    self.RelationClass: rel,
                    self.IsTraining: False}
                # Score = sess.run(EdgeScore, feed_dict=feedDict)
                varGet = sess.run(self.varGet, feed_dict=feedDict)
                # feature, Score, relEmbedding = varGet
                visual, wordVector, edgeVector, _ = varGet
                subVisual, objVisual = visual
                subVector, objVector = wordVector

                subLabels.append(subLabel)
                objLabels.append(objLabel)
                subVisuals.append(subVisual)
                objVisuals.append(objVisual)
                subVectors.append(subVector)
                objVectors.append(objVector)
                edgeVectors.append(edgeVector)
                values.append([rel, subLabel, objLabel, subject[-1], objects[-1], imgName])
                rels.append(rel)
            # savePath = os.path.join("ckpt", "visual", "predicate", "trainFeature")
            savePath = os.path.join("ckpt", "visual", "imgNameTrainFeature")
            np.save(savePath, [subVisuals, objVisuals, subVectors, objVectors, edgeVectors, subLabels, objLabels,rels, values])
            print("train set save finish")
            # subVisuals, objVisuals = [], []
            # subVectors, objVectors = [], []
            # subLabels, objLabels = [], []
            # edgeVectors, rels = [], []
            # features, imgNames = [], []
            # scores, values, relVectors = [], [], []
            # for temp_test in test:
            #     inter, union, subject, objects, subLabel, objLabel, rel, spatial,imgName = temp_test
            #     # simRelations, disSimRelations, disSimRelationScore = relSim.each(rel, num=negative)
            #     feedDict = {
            #         self.subjectImg: subject[0],
            #         self.subjectMask: subject[1],
            #         self.subjectLabel: subLabel,
            #         self.spatial: spatial,
            #         self.objectImg: objects[0],
            #         self.objectMask: objects[1],
            #         self.objectLabel: objLabel,
            #         self.unionImg: union[0],
            #         self.unionMask: union[1],
            #         self.RelationClass: rel,
            #         self.IsTraining: False}
            #     # Score = sess.run(EdgeScore, feed_dict=feedDict)
            #     varGet = sess.run(self.varGet, feed_dict=feedDict)
            #     # feature, Score = varGet
            #     visual, wordVector, edgeVector, Score = varGet
            #     subVisual, objVisual = visual
            #     subVector, objVector = wordVector
            #     subLabels.append(subLabel)
            #     objLabels.append(objLabel)
            #     subVisuals.append(subVisual)
            #     objVisuals.append(objVisual)
            #     subVectors.append(subVector)
            #     objVectors.append(objVector)
            #     edgeVectors.append(edgeVector)
            #     rels.append(rel)
            #     # feature, Score, relVector = varGet
            #     evalTest.add(rel, Score, subLabel, objLabel, subject[-1], objects[-1])
            #     # features.append(feature)
            #     # scores.append(Score)
            #     # relVectors.append(rel)
            #     # relVectors.append(relVector)
            #     values.append([rel,subLabel, objLabel, subject[-1], objects[-1], imgName])
            # # savePath = os.path.join("ckpt", "visual", "ConcatNoExtraLoss-0.45->best-0.46","testRes")
            # # np.save(savePath, [features, scores, values, testData.Length])
            # savePath = os.path.join("ckpt", "visual", "predicate", "testFeature")
            # # print(np.asarray(relEmbedding))
            # # print("feature/values/imgNames shape", np.asarray(features).shape, np.asarray(values).shape)
            # np.save(savePath, [subVisuals, objVisuals, subVectors, objVectors, edgeVectors, subLabels, objLabels,rels, values, testData.Length])
            # evalTest.eval(testData.Length)
            # evalTest.show()
            return None

class VisualSelfAttention(VisualTransE):
    def __init__(self):
        VisualTransE.__init__(self)
        featureDim = 450
        self.subVisual = tf.placeholder(tf.float32, [None, featureDim])
        self.objVisual = tf.placeholder(tf.float32, [None, featureDim])
        self.subVector = tf.placeholder(tf.float32, [None, featureDim])
        self.objVector = tf.placeholder(tf.float32, [None, featureDim])
        self.subLabel = tf.placeholder(tf.int32, [None])
        self.objLabel = tf.placeholder(tf.int32, [None])
        self.context = tf.placeholder(tf.int32, [None, 21])
        self.contextSpatial = tf.placeholder(tf.float32, [None, 21, 4])
        self.subId = tf.placeholder(tf.int32, [None,])
        self.objId = tf.placeholder(tf.int32, [None,])
        self.var = []

    # get self attention result
    def GetWordVector(self, Object, path=None):
        """
        Get WordVector for object
        :param Object: [Batch, step]: objectId
        :return: 
        """
        with tf.variable_scope("Word2Vec"):
            LoadPath = path if path else os.path.join("dataset", "InitEmbedding.npy")
            init = tf.constant(np.load(LoadPath), dtype=tf.float32)
            ObjectEmbedding = tf.get_variable("ObjectEmbedding", initializer=init, trainable=True)
            Vectors = tf.nn.embedding_lookup(ObjectEmbedding, Object)
            VectorsDim = Vectors.get_shape()[-1]
        print("get word vector, shape:", Vectors.get_shape())
        return Vectors

    def getContext(self, objectLabel, spatial, subIndex, objIndex):
        with tf.variable_scope("self-attention"):
            wordVectorSeq = self.GetWordVector(objectLabel)
            spatialSeq = slim.fully_connected(spatial, num_outputs=20)
            spatialSeq = slim.fully_connected(spatialSeq, num_outputs=50)
            attentionInput = tf.concat((wordVectorSeq, spatialSeq), axis=-1)
            attentionResult = self.attentionLayer(attentionInput, name="attention1")
            attentionResult = self.attentionLayer(attentionResult, name="attention2")
            # attentionResult = self.attentionLayer(attentionResult, name="attention3")
            # useful id
            subId = tf.expand_dims(tf.one_hot(self.subId, depth=21), -1)
            objId = tf.expand_dims(tf.one_hot(self.objId, depth=21), -1)
            sub = tf.reduce_sum(subId * attentionResult, axis=1)
            obj = tf.reduce_sum(objId * attentionResult, axis=1)
            # sum is the bad idea
            # sub = self.getSpecificContext(attentionResult, self.subId)
            # obj = self.getSpecificContext(attentionResult, self.objId)
            context = tf.concat((sub, obj), axis=-1)
            # dim: 50:0.508; 100:0.516; 150:0.524; 200:0.526/0.531; 250:0.5351
            context = slim.fully_connected(context, 250)
            return context

    def getSpecificContext(self, contexts, SpecificId):
        # specificContext = tf.gather(contexts, SpecificId, axis=1)
        SpecificId = tf.expand_dims(tf.one_hot(SpecificId, depth=21), -1)
        specificContext = tf.reduce_sum(SpecificId * contexts, axis=1)
        specificContext = tf.tile(tf.expand_dims(specificContext, axis=1), [1, 21, 1])

        context = tf.concat((specificContext, contexts), axis=-1)
        weight = tf.squeeze(slim.fully_connected(context, num_outputs=1), axis=-1)
        weight = tf.expand_dims(tf.nn.softmax(weight, dim=-1), -1)
        result = tf.reduce_sum(contexts*weight, axis=1)
        return result

    def getWordContext(self, objectClass, featureDim=250):
        with tf.variable_scope("wordContext"):
            objectWord = self.GetWordVector(objectClass)
            subWord, objWord = tf.split(objectWord, 2, axis=0)
            wordContext = slim.fully_connected(subWord-objWord, featureDim)
            return wordContext

    def attentionLayer(self, objSeq, numHeads=7, hiddenNum=350, name="attention", highWay=True):
        with tf.variable_scope(name):
            batch, length, channel = objSeq.get_shape()
            channel = int(channel)
            query = slim.fully_connected(objSeq, channel)
            key = slim.fully_connected(objSeq, channel)
            value = slim.fully_connected(objSeq, channel)
            # split and concat
            query_ = tf.concat(tf.split(query, numHeads, axis=2), axis=0)
            key_ = tf.concat(tf.split(key, numHeads, axis=2), axis=0)
            value_ = tf.concat(tf.split(value, numHeads, axis=2), axis=0)

            energy = tf.matmul(query_, key_, transpose_b=True)
            energy = tf.nn.softmax(energy, dim=-1)

            att = tf.matmul(value_, energy, transpose_a=True)
            att = tf.transpose(att, perm=[0, 2, 1])
            att = tf.concat(tf.split(att, numHeads, axis=0), axis=2)
            gamma = tf.get_variable("g", shape=(1), initializer=tf.constant_initializer(0.01), trainable=True)
            out = att*gamma + objSeq
        return out

    def getArch(self):
        Img = tf.concat((self.subjectImg, self.objectImg), axis=0)
        unionVisual = self.GetVisualFeature(Img)
        unionVisual = tf.squeeze(unionVisual, 0) if unionVisual.get_shape()[0] == 1 else unionVisual
        subVisual, objVisual = tf.split(unionVisual, 2, axis=0)

        featureDim = 450
        subVisual = slim.fully_connected(subVisual, featureDim)
        objVisual = slim.fully_connected(objVisual, featureDim)
        self.var.append([subVisual, objVisual])

        # # sub/obj position
        # subId = tf.expand_dims(tf.one_hot(self.subId, depth=21), -1)
        # objId = tf.expand_dims(tf.one_hot(self.objId, depth=21), -1)
        # subSpatial = tf.reduce_sum(subId * self.contextSpatial, axis=1)
        # objSpatial = tf.reduce_sum(objId * self.contextSpatial, axis=1)

        # edgeMask = tf.concat((self.spatial, subSpatial, objSpatial), axis=-1)
        edgeMask = self.spatial
        edgeVector = slim.fully_connected(edgeMask, 20)
        edgeVector = slim.fully_connected(edgeVector, 50)
        self.var.append(edgeVector)
        # objectClass = tf.concat((self.subjectLabel, self.objectLabel), axis=0)
        # WordVector = tf.one_hot(objectClass, depth=self.relationClass)
        # subjectWordVector, objectWordVector = tf.split(WordVector, 2, axis=0)
        # # label mask with spatial 最高0.510
        # # subjectWordVector = tf.concat((subjectWordVector), axis=-1)
        # # objectWordVector = tf.concat((objectWordVector), axis=-1)
        # subjectWordVector = slim.fully_connected(subjectWordVector, featureDim)
        # objectWordVector = slim.fully_connected(objectWordVector, featureDim)
        # self.var.append([subjectWordVector, objectWordVector])
        # # # use edgeVector label mask add/multi spatial mask 乘积:0.527/加和:0.5314 and the
        # # use self.spatial multi 乘积0.5452/ add: 0.5412
        # # only use edge mask 0.468-0.478
        # # subjectEdge = slim.fully_connected(self.spatial, featureDim)
        # # objectEdge = slim.fully_connected(self.spatial, featureDim)
        # # use context spatial
        # subjectEdge = slim.fully_connected(edgeMask, featureDim)
        # objectEdge = slim.fully_connected(edgeMask, featureDim)
        # self.var.append([subjectEdge, objectEdge])
        # subjectWordVector *= subjectEdge
        # objectWordVector *= objectEdge
        # edgeVec = slim.fully_connected(subVisual*subjectWordVector - objVisual*objectWordVector, featureDim)
        #no mask feature
        edgeVec = slim.fully_connected(subVisual - objVisual, featureDim)

        context = self.getContext(self.context, self.contextSpatial, self.subId, self.objId)
        # context = self.getWordContext(objectClass)
        self.var.append(context)
        feature = tf.concat((edgeVec, edgeVector, context), axis=-1)
        edge = slim.fully_connected(feature, self.relationClass)
        EdgeScore = tf.nn.softmax(edge, dim=-1)
        self.var.append(EdgeScore)
        edgeLoss = None
        loss, accuracy, train_step = self.GetOptimizer(edge, self.RelationClass, maskFeature=edgeLoss)
        return loss, accuracy, train_step, EdgeScore,  # index

    def getIndex(self, boxs, allBoxs):
        assert len(boxs) == len(allBoxs)
        result = []
        for box, boxSet in zip(boxs, allBoxs):
            for index, temp in enumerate(boxSet):
                if box == tuple(temp):
                    findIndex = index
                    break
            try:
                result.append(findIndex)
            except UnboundLocalError:
                pdb.set_trace()
        # extraIndex = [list(range(21)) for _ in range(len(boxs))]
        # result = np.expand_dims(result, -1)
        # sigma = np.expand_dims(np.var(result- extraIndex, axis=1), axis=-1)
        # g = np.exp(-((result - extraIndex) ** 2 / (2.0 * sigma)))
        return result

    def getSaver(self):
        params = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES)
        restore = [i for i in params if "fully_connected_4" in i.name]
        restoreSaver = tf.train.Saver(restore)
        save = tf.train.Saver()
        return restoreSaver, save

    def TrainTest(self, trainData, resnet_model_path, testData, Error=True, epoch=10, save=True):
        def floatShow(a, b=5):
            a = str(a)
            return a[:b]
        loss, accuracy, train_step, EdgeScore = self.getArch()
        saver_restore, saver = self.GetSaver()
        path = os.path.join("dataset", 'context.npy')
        trainContext, testContext = np.load(path)
        config = tf.ConfigProto(allow_soft_placement=True)
        config.gpu_options.per_process_gpu_memory_fraction = 0.95
        init = tf.global_variables_initializer()
        bestRecall = 0.0
        with tf.Session(config=config) as sess:
            sess.run(init)
            # Load the pretrained checkpoint file xxx.ckpt
            saver_restore.restore(sess, resnet_model_path)
            Acc = []
            for i in range(epoch):
                TrainStep = 0
                train = trainData.getNext()
                test = testData.getNext()
                testData.Length = []
                for temp_train in train:
                    inter, union, subject, objects, subLabel, objLabel, rel, spatial,imgName = temp_train
                    # simRelations, disSimRelations, disSimRelationScore = relSim.each(rel, num=negative)
                    contextLabel = [trainContext[name]["label"] for name in imgName]
                    contextSpatial = [trainContext[name]["spatial"] for name in imgName]
                    contextBox = [trainContext[name]["box"] for name in imgName]
                    subIndex = self.getIndex(subject[2], contextBox)
                    objIndex = self.getIndex(objects[2], contextBox)
                    TrainDict = {
                            self.subjectImg: subject[0],
                            self.subjectMask: subject[1],
                            self.subjectLabel: subLabel,
                            self.spatial: spatial,
                            self.objectImg: objects[0],
                            self.objectMask: objects[1],
                            self.objectLabel: objLabel,

                            self.RelationClass: rel,
                            self.context: contextLabel,
                            self.contextSpatial: contextSpatial,
                            self.subId: subIndex,
                            self.objId: objIndex,
                            self.IsTraining: True}
                    sess.run(train_step, feed_dict=TrainDict)
                    TrainLoss, TrainAcc = sess.run([loss, accuracy], feed_dict=TrainDict)
                    Acc.append(TrainAcc)
                    if TrainStep % 100 == 0:
                        TrainResult = "train step:{0}, all loss:{1}, extra loss:{3},acc:{2}".format(TrainStep, TrainLoss[0],
                                                                                 sum(Acc) / Acc.__len__(), floatShow(TrainLoss[1]))
                        Acc = []
                        print(TrainResult)
                    TrainStep += 1
                evalTest = EvalRecallUnion()
                Acc = []
                # testFeature = []
                for temp_test in test:
                    inter, union, subject, objects, subLabel, objLabel, rel, spatial, imgName = temp_test
                    contextLabel = [testContext[name]["label"] for name in imgName]
                    contextSpatial = [testContext[name]["spatial"] for name in imgName]
                    contextBox = [testContext[name]["box"] for name in imgName]
                    subIndex = self.getIndex(subject[2], contextBox)
                    objIndex = self.getIndex(objects[2], contextBox)
                    feedDict = {
                            self.subjectImg: subject[0],
                            self.subjectMask: subject[1],
                            self.subjectLabel: subLabel,
                            self.spatial: spatial,
                            self.objectImg: objects[0],
                            self.objectMask: objects[1],
                            self.objectLabel: objLabel,

                            self.RelationClass: rel,
                            self.context: contextLabel,
                            self.contextSpatial: contextSpatial,
                            self.subId: subIndex,
                            self.objId: objIndex,
                            self.IsTraining: False}
                    Score = sess.run(EdgeScore, feed_dict=feedDict)
                    evalTest.add(rel, Score, subLabel, objLabel, subject[2], objects[2])
                evalTest.eval(testData.Length)
                evalTest.show()
                # save the best model
                testRecall = evalTest.getRecall()
                if testRecall > bestRecall and save:
                    time = datetime.datetime.now().strftime("%Y-%m-%d--%H:%M:%S")
                    bestRecall = testRecall
                    path = os.path.join("ckpt", "visual", time)
                    if not os.path.exists(path):
                        os.makedirs(path)
                    savePath = os.path.join(path, "transE")
                    # np.save(savePath, testFeature)
                    if bestRecall >0.51:
                        saver.save(sess, savePath)
                        print(time)
                # if Error:
                #     error.write()

    def testVisual(self, testData, restore, trainData):
        loss, accuracy, train_step, EdgeScore = self.getArch()
        saver = tf.train.Saver()
        config = tf.ConfigProto(allow_soft_placement=True)
        config.gpu_options.per_process_gpu_memory_fraction = 0.95
        init = tf.global_variables_initializer()
        # path = os.path.join("dataset", 'context.npy')
        # trainContext, testContext = np.load(path)
        with tf.Session(config=config) as sess:
            sess.run(init)
            saver.restore(sess, restore)
            test = testData.getNext()
            train = trainData.getNext()
            testData.Length = []
            evalTest = EvalRecallUnion()
            # error = ErrorAnalysis(0)
            trainFeature = []
            for temp_train in train:
                temp = dict()
                inter, union, subject, objects, subLabel, objLabel, rel, spatial, imgName = temp_train
                contextLabel = [trainContext[name]["label"] for name in imgName]
                contextSpatial = [trainContext[name]["spatial"] for name in imgName]
                contextBox = [trainContext[name]["box"] for name in imgName]
                subIndex = self.getIndex(subject[2], contextBox)
                objIndex = self.getIndex(objects[2], contextBox)
                TrainDict = {
                    self.subjectImg: subject[0],
                    self.subjectMask: subject[1],
                    self.subjectLabel: subLabel,
                    self.spatial: spatial,
                    self.objectImg: objects[0],
                    self.objectMask: objects[1],
                    self.objectLabel: objLabel,

                    self.RelationClass: rel,
                    self.context: contextLabel,
                    self.contextSpatial: contextSpatial,
                    self.subId: subIndex,
                    self.objId: objIndex,
                    self.IsTraining: True}
                # Score = sess.run(EdgeScore, feed_dict=feedDict)
                varGet = sess.run(self.var, feed_dict=TrainDict)
                # feature, Score, relEmbedding = varGet
                value = [rel, subLabel, objLabel, subject[-1], objects[-1], imgName]
                visual, edgeVector, labelMask, edgeMask, contextFeature, score = varGet
                subVisual, objVisual = visual
                subLabelMask, objLabelMask = labelMask
                subEdgeMask, objEdgeMask = edgeMask
                temp["subVisual"] = subVisual
                temp["objVisual"] = objVisual
                temp["subLabelMask"] = subLabelMask
                temp["objLabelMask"] = objLabelMask
                temp["subEdgeMask"] = subEdgeMask
                temp["objEdgeMask"] = objEdgeMask
                temp["context"] = contextFeature
                temp["edgeVector"] = edgeVector
                temp["value"] = value
                trainFeature.append(temp)
            # savePath = os.path.join("ckpt", "visual", "predicate", "trainFeature")
            savePath = os.path.join("ckpt", "visual", "edgeMask*labelMask+selfAttention-multihead-0.5484", "trainFeature")
            np.save(savePath,trainFeature)
            print("train set save finish")
            testFeature = []
            for temp_test in test:
                temp = dict()
                inter, union, subject, objects, subLabel, objLabel, rel, spatial, imgName = temp_test
                contextLabel = [testContext[name]["label"] for name in imgName]
                contextSpatial = [testContext[name]["spatial"] for name in imgName]
                contextBox = [testContext[name]["box"] for name in imgName]
                subIndex = self.getIndex(subject[2], contextBox)
                objIndex = self.getIndex(objects[2], contextBox)
                feedDict = {
                    self.subjectImg: subject[0],
                    self.subjectMask: subject[1],
                    self.subjectLabel: subLabel,
                    self.spatial: spatial,
                    self.objectImg: objects[0],
                    self.objectMask: objects[1],
                    self.objectLabel: objLabel,

                    self.RelationClass: rel,
                    self.context: contextLabel,
                    self.contextSpatial: contextSpatial,
                    self.subId: subIndex,
                    self.objId: objIndex,
                    self.IsTraining: False}
                varGet = sess.run(self.var, feed_dict=feedDict)
                # feature, Score = varGet
                value = [rel, subLabel, objLabel, subject[-1], objects[-1], imgName]
                visual, edgeVector, labelMask, edgeMask, contextFeature, score = varGet
                subVisual, objVisual = visual
                subLabelMask, objLabelMask = labelMask
                subEdgeMask, objEdgeMask = edgeMask
                temp["subVisual"] = subVisual
                temp["objVisual"] = objVisual
                temp["subLabelMask"] = subLabelMask
                temp["objLabelMask"] = objLabelMask
                temp["subEdgeMask"] = subEdgeMask
                temp["objEdgeMask"] = objEdgeMask
                temp["context"] = contextFeature
                temp["edgeVector"] = edgeVector
                temp["value"] = value
                testFeature.append(temp)
                evalTest.add(rel, score, subLabel, objLabel, subject[-1], objects[-1])

            savePath = os.path.join("ckpt", "visual", "edgeMask*labelMask+selfAttention-multihead-0.5484", "testFeature")
            np.save(savePath, [testFeature, testData.Length])
            evalTest.eval(testData.Length)
            evalTest.show()
            return None

if __name__ == "__main__":
    batch = 16
    TrainMat = "annotations_train.json"
    train_data = UnionData(TrainMat, "sg_train_images", batch=batch)
    RestorePath = os.path.join("ckpt", "Vgg", "vrd")
    # RestorePath = os.path.join("ckpt", "pretrain", "vgg_16.ckpt")
    TestMat = "annotations_test.json"
    test_data = UnionData(TestMat, "sg_test_images", batch=batch)
    StorePath = os.path.join("ckpt", "Vrd", "vrd")
    # Res = VisualTransE()
    Res = VisualSelfAttention()
    # trainPath = os.path.join("ckpt", "visual", "imgNameTrainFeature.npy")
    # testPath = os.path.join("ckpt", "visual", "predicate-乘差-0.5364--0.230", "testFeature.npy")
    # Res.TrainTest(train_data, RestorePath, test_data, Error=False, epoch=10)
    # reStorePath = os.path.join("ckpt", "visual", "allin-lr-0.05-0.5159", "transE")
    # reStorePath = os.path.join("ckpt", "visual", "baseline--0.505", "transE")
    # reStorePath = os.path.join("ckpt", "visual", "先差再乘-0.5069", "transE")
    # reStorePath = os.path.join("ckpt", "visual", "ConcatNoExtraLoss-0.45->best-0.46", "transE")
    # reStorePath = os.path.join("ckpt", "visual", "withExtraWeight--0.517", "transE")
    reStorePath = os.path.join("ckpt", "visual", "edgeMask*labelMask+selfAttention-multihead-0.5484", "transE")
    Res.TrainTest(train_data, RestorePath, test_data, Error=False, epoch=10)
    # Res.testVisual(test_data, reStorePath, train_data)