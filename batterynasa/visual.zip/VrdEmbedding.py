import tensorflow as tf
import numpy as np
from configparser import ConfigParser
import os
import pdb
from layer import *
import time
from EvalRecall import ErrorAnalysis
from VIsualModel import vgg_16
from layer import AlternatingHighWayCell
from MatDRNet import FeatureData, FeatureDataAtt
from VrdTransE import VisualTransE
from EvalRecall import EvalRecallUnion
import tensorflow.contrib.slim as slim
from tensorflow.contrib.slim import nets
from LoadMat import DataLoad
from EvalRecall import EvalRecall
np.set_printoptions(threshold=np.nan)
os.environ["CUDA_VISIBLE_DEVICES"] = "0"

## new idea
# use gan network to generate the relation feature from the input img feature, it's word Vector and it's spatial feature
# try to make the relation feature similar to the relation word vector
# 类似于stack gan的text2img反向操作
class Classifier(object):
    def __init__(self):
        self.relationClass = 71
        self.lr = 0.0001
        featureDim = 450
        self.subVisual = tf.placeholder(tf.float32, [None, featureDim])
        self.objVisual = tf.placeholder(tf.float32, [None, featureDim])
        self.subVector = tf.placeholder(tf.float32, [None, featureDim])
        self.objVector = tf.placeholder(tf.float32, [None, featureDim])
        self.subEdgeVector = tf.placeholder(tf.float32, [None, featureDim])
        self.objEdgeVector = tf.placeholder(tf.float32, [None, featureDim])
        self.subLabel = tf.placeholder(tf.int32, [None])
        self.objLabel = tf.placeholder(tf.int32, [None])
        self.spatial = tf.placeholder(tf.float32, [None, 50])
        self.rel = tf.placeholder(tf.int64, [None])
        self.context = tf.placeholder(tf.float32, [None, 250])

    def getWordVector(self, Object, path=None):
        with tf.variable_scope("Word2Vec"):
            LoadPath = path if path else os.path.join("dataset", "InitEmbedding.npy")
            init = tf.constant(np.load(LoadPath), dtype=tf.float32)
            ObjectEmbedding = tf.get_variable("ObjectEmbedding", initializer=init, trainable=True)
            Vectors = tf.nn.embedding_lookup(ObjectEmbedding, Object)
            VectorsDim = Vectors.get_shape()[-1]
        print("get word vector and shape is:", Vectors.get_shape())
        sub, obj = tf.split(Vectors, 2, axis=0)
        return sub, obj

    def getOptimizer(self):
        with tf.variable_scope("predicate"):
            # objectClass = tf.concat((self.subLabel, self.objLabel), axis=0)
            # sub, obj = self.getWordVector(objectClass)
            # edge = sub - obj
            edge = self.subVisual*self.subVector - self.objVisual*self.objVector
            # edge = (self.subVisual-self.objVisual)*(self.subVector-self.objVector)
            feature = slim.fully_connected(edge, num_outputs=450, scope="feature")
            feature = tf.concat((feature, self.spatial), axis=-1)
            predicate = slim.fully_connected(feature, self.relationClass)
            loss = tf.nn.softmax_cross_entropy_with_logits(logits=predicate, labels=tf.one_hot(self.rel, depth=self.relationClass))
            loss = tf.reduce_mean(loss)
            optimizer = tf.train.AdamOptimizer(learning_rate=self.lr)
            train_step = slim.learning.create_train_op(loss, optimizer)
            score = tf.nn.softmax(predicate)
            res = tf.argmax(score, axis=-1)
            acc = tf.reduce_mean(tf.cast(tf.equal(res, self.rel), dtype=tf.int32))
        return train_step, loss, acc, score

    def getAttentionOptimizer(self):
        with tf.variable_scope("predicate"):
            # objectClass = tf.concat((self.subLabel, self.objLabel), axis=0)
            # sub, obj = self.getWordVector(objectClass)
            # edge = sub - obj
            subVector = self.subVector*self.subEdgeVector
            objVector = self.objVector*self.objEdgeVector
            # subVector = self.subVector
            # objVector = self.objVector
            edge = self.subVisual*subVector - self.objVisual*objVector
            # edge = (self.subVisual-self.objVisual)*(self.subVector-self.objVector)
            feature = slim.fully_connected(edge, num_outputs=450, scope="feature")
            # feature = tf.concat((feature, self.spatial, self.context), axis=-1)
            feature = tf.concat((feature, self.spatial), axis=-1)
            predicate = slim.fully_connected(feature, self.relationClass)

            loss = tf.nn.softmax_cross_entropy_with_logits(logits=predicate, labels=tf.one_hot(self.rel, depth=self.relationClass))
            loss = tf.reduce_mean(loss)
            optimizer = tf.train.AdamOptimizer(learning_rate=self.lr)
            train_step = slim.learning.create_train_op(loss, optimizer)
            score = tf.nn.softmax(predicate)
            res = tf.argmax(score, axis=-1)
            acc = tf.reduce_mean(tf.cast(tf.equal(res, self.rel), dtype=tf.int32))
        # for i in tf.global_variables():
        #     print(i)
        # pdb.set_trace()
        return train_step, loss, acc, score

    def getSave(self):
        saveVar = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, scope='predicate')
        for i in saveVar:
            print(i)
        save = tf.train.Saver(var_list=saveVar)
        return save

    def trainTest(self, trainData, testData, batch=16, savePath=None):
        train_step, loss, acc, EdgeScore = self.getOptimizer()
        config = tf.ConfigProto(allow_soft_placement=True)
        config.gpu_options.per_process_gpu_memory_fraction = 0.95
        init = tf.global_variables_initializer()
        save = self.getSave()
        bestRecall = 0.0
        with tf.Session(config=config) as sess:
            sess.run(init)
            for epoch in range(20):
                for i in range(0, trainData.size, batch):
                    batch_subVisual, batch_objVisuals, batch_subVectors, batch_objVectors, \
                    batch_edgeVectors, batch_subLabels, batch_objLabels, batch_rel = trainData.getNext(i)
                    feedDict = {
                        self.subVisual:batch_subVisual,
                        self.objVisual:batch_objVisuals,
                        self.subVector:batch_subVectors,
                        self.objVector:batch_objVectors,
                        self.subLabel:batch_subLabels,
                        self.objLabel:batch_objLabels,
                        self.spatial:batch_edgeVectors,
                        self.rel:batch_rel,
                    }
                    trainAcc, trainLoss, _ = sess.run([acc, loss, train_step],
                                                      feed_dict=feedDict)
                savePath = savePath if savePath else os.path.join("ckpt", "visual", "predicate")
                if not os.path.exists(savePath):
                    os.makedirs(savePath)

                evalTest = EvalRecallUnion()
                subVisuals, objVisuals, subVectors, objVectors, edgeVectors, subLabels, objLabels, rels, values,length = np.load(testData)
                for batch_subVisual, batch_objVisuals, batch_subVectors, batch_objVectors, \
                    batch_edgeVectors, batch_subLabels, batch_objLabels, batch_rel, value \
                        in zip(subVisuals, objVisuals, subVectors, objVectors, edgeVectors, subLabels, objLabels, rels, values):
                    rel, subLabel, objLabel, subject, objects, imgName = value

                    feedDict = {
                        self.subVisual: batch_subVisual,
                        self.objVisual: batch_objVisuals,
                        self.subVector: batch_subVectors,
                        self.objVector: batch_objVectors,
                        self.subLabel: batch_subLabels,
                        self.objLabel: batch_objLabels,
                        self.spatial: batch_edgeVectors,
                        self.rel: batch_rel,
                    }
                    score = sess.run(EdgeScore, feed_dict=feedDict)
                    evalTest.add(rel, score, subLabel, objLabel, subject, objects, imgName, None)
                evalTest.eval(length)
                evalTest.show()
                tempRecall = evalTest.getZero()
                if tempRecall>bestRecall:
                    bestRecall = tempRecall
                    path = os.path.join(savePath, "predicate")
                    save.save(sess, path)
                    print("best recall:{1}".format(time.time(), bestRecall))

    def trainTestAtt(self, trainData, testPath, batch=16, savePath=None):
        train_step, loss, acc, EdgeScore = self.getAttentionOptimizer()
        config = tf.ConfigProto(allow_soft_placement=True)
        config.gpu_options.per_process_gpu_memory_fraction = 0.95
        init = tf.global_variables_initializer()
        save = self.getSave()
        bestRecall = 0.0
        with tf.Session(config=config) as sess:
            sess.run(init)
            for epoch in range(10):
                for i in range(0, trainData.size, batch):
                    batch_subVisual, batch_objVisuals, batch_subVectors, batch_objVectors, \
                    batch_subEdgeMask, batch_objEdgeMask, batch_context, batch_edgeVectors, batch_subLabels, batch_objLabels, batch_rel = trainData.getNext(i)
                    feedDict = {
                        self.subVisual:batch_subVisual,
                        self.objVisual:batch_objVisuals,
                        self.subVector:batch_subVectors,
                        self.objVector:batch_objVectors,
                        self.subLabel:batch_subLabels,
                        self.objLabel:batch_objLabels,
                        self.spatial:batch_edgeVectors,
                        self.subEdgeVector: batch_subEdgeMask,
                        self.objEdgeVector: batch_objEdgeMask,
                        self.rel:batch_rel,
                        # self.context:batch_context
                    }
                    trainAcc, trainLoss, _ = sess.run([acc, loss, train_step],
                                                      feed_dict=feedDict)
                savePath = savePath if savePath else os.path.join("ckpt", "visual", "predicateNew")
                if not os.path.exists(savePath):
                    os.makedirs(savePath)
                evalTest = EvalRecallUnion()
                testFeature, length= np.load(testPath)
                for test in testFeature:
                    rel, subLabel, objLabel, subject, objects, imgName = test["value"]
                    feedDict = {
                        self.subVisual: test["subVisual"],
                        self.objVisual: test["objVisual"],
                        self.subVector: test["subLabelMask"],
                        self.objVector: test["objLabelMask"],
                        self.subLabel: subLabel,
                        self.objLabel: objLabel,
                        self.subEdgeVector: test["subEdgeMask"],
                        self.objEdgeVector: test["objEdgeMask"],
                        self.spatial: test["edgeVector"],
                        self.rel: rel,
                        #self.context:test["context"]
                    }
                    score = sess.run(EdgeScore, feed_dict=feedDict)
                    evalTest.add(rel, score, subLabel, objLabel, subject, objects, imgName, None)
                evalTest.eval(length)
                evalTest.show()
                tempRecall = evalTest.getRecall()+evalTest.getZero()
                if tempRecall>bestRecall:
                    bestRecall = tempRecall
                    path = os.path.join(savePath, "predicate")
                    # save.save(sess, path)
                print("best recall:{1}, zero:{2}".format(time.time(), bestRecall-evalTest.getZero(), evalTest.getZero()))

    def reNameVar(self, restorePath):
        savePath = os.path.join("ckpt", "visual", "predicateNew")
        if not os.path.exists(savePath):
            os.makedirs(savePath)
        reNameVar = []
        with tf.Session() as sess:
            for var_name, shape in tf.contrib.framework.list_variables(restorePath):
                # Load the variable
                var = tf.contrib.framework.load_variable(restorePath, var_name)
                # Set the new name
                if "beta1_power" in var_name:
                    new_name = "predicate/" + "/".join(var_name.split("/"))
                    var = tf.Variable(var, name=new_name)
                    reNameVar.append(var)

                if "fully_connected_8" in var_name:
                    new_name = "predicate/feature/" + "/".join(var_name.split("/")[1:])
                    var = tf.Variable(var, name=new_name)
                    reNameVar.append(var)
                if "fully_connected_9" in var_name:
                    new_name = "predicate/fully_connected/" + "/".join(var_name.split("/")[1:])
                    var = tf.Variable(var, name=new_name)
                    reNameVar.append(var)
            # Save the variables
            saver = tf.train.Saver(var_list=reNameVar)
            sess.run(tf.global_variables_initializer())
            saver.save(sess, os.path.join(savePath, "predicate"))

    def testReName(self, testPath, restorePath):
        train_step, loss, acc, EdgeScore = self.getAttentionOptimizer()
        config = tf.ConfigProto(allow_soft_placement=True)
        config.gpu_options.per_process_gpu_memory_fraction = 0.95
        init = tf.global_variables_initializer()
        restore = tf.train.Saver(var_list=tf.trainable_variables())
        testFeature, length = np.load(testPath)
        with tf.Session(config=config) as sess:
            sess.run(init)
            restore.restore(sess, restorePath)
            evalTest = EvalRecallUnion()
            for test in testFeature:
                rel, subLabel, objLabel, subject, objects, imgName = test["value"]
                feedDict = {
                    self.subVisual: test["subVisual"],
                    self.objVisual: test["objVisual"],
                    self.subVector: test["subLabelMask"],
                    self.objVector: test["objLabelMask"],
                    self.subLabel: subLabel,
                    self.objLabel: objLabel,
                    self.subEdgeVector: test["subEdgeMask"],
                    self.objEdgeVector: test["objEdgeMask"],
                    self.spatial: test["edgeVector"],
                    self.rel: rel,
                    self.context: test["context"]
                }
                score = sess.run(EdgeScore, feed_dict=feedDict)
                evalTest.add(rel, score, subLabel, objLabel, subject, objects, imgName, None)
            evalTest.eval(length)
            evalTest.show()

class Adversarial_Generator(object):

    def __init__(self):
        self.relationClass = 71
        self.objectClass = 100
        self.lr = 0.0001
        featureDim = 450
        self.featureDim = featureDim
        self.subVisual = tf.placeholder(tf.float32, [None, featureDim])
        self.objVisual = tf.placeholder(tf.float32, [None, featureDim])
        self.subVector = tf.placeholder(tf.float32, [None, featureDim])
        self.objVector = tf.placeholder(tf.float32, [None, featureDim])
        self.subEdgeVector = tf.placeholder(tf.float32, [None, featureDim])
        self.objEdgeVector = tf.placeholder(tf.float32, [None, featureDim])
        self.subLabel = tf.placeholder(tf.int32, [None])
        self.objLabel = tf.placeholder(tf.int32, [None])
        self.spatial = tf.placeholder(tf.float32, [None, 50])
        self.rel = tf.placeholder(tf.int64, [None])
        self.z = tf.placeholder(tf.float32, [None, 128])
        self.context = tf.placeholder(tf.float32, [None, 250])

        self.relFeature = []

    def getRelVector(self, rel, path=None):
        with tf.variable_scope("rel2Vec"):
            # LoadPath = path if path else os.path.join("ckpt", "visual", "withExtraWeight--0.517", "relEmbedding.npy")
            LoadPath = path if path else os.path.join("dataset", "InitRelEmbedding.npy")
            init = tf.constant(np.load(LoadPath), dtype=tf.float32)
            relEmbedding = tf.get_variable("relEmbedding", initializer=init, trainable=True)
            Vectors = tf.nn.embedding_lookup(relEmbedding, rel)
            return Vectors

    def generator(self, x, name="generator", reuse=False, isTrainable=True):
        with tf.variable_scope(name, reuse=reuse) as scope:
            net = slim.fully_connected(x, 1024, activation_fn=tf.nn.leaky_relu, scope="gen_fc1", trainable=isTrainable)
            net = slim.fully_connected(net, self.featureDim, activation_fn=tf.nn.leaky_relu, scope="gen_fc2", trainable=isTrainable)
            # net = tf.layers.dense(inputs=x, units=opt.ngh,kernel_initializer=tf.random_normal_initializer(mean=0, stddev=0.02), \
            #                       activation=tf.nn.leaky_relu, name='gen_fc1', trainable=isTrainable, reuse=reuse)
            #
            # net = tf.layers.dense(inputs=net, units=opt.resSize,kernel_initializer=tf.random_normal_initializer(mean=0, stddev=0.02),
            #                      activation=tf.nn.relu, name='gen_fc2', trainable=isTrainable, reuse=reuse)
            # the output is relu'd as the encoded representation is also the activations by relu
            return net

    def discriminator(self, x, name="discriminator", reuse=False, isTrainable=True):
        with tf.variable_scope(name, reuse=reuse) as scope:
            net = slim.fully_connected(x, 4096, activation_fn=tf.nn.leaky_relu, scope="disc_fc1",trainable=isTrainable)
            real_fake = slim.fully_connected(net, 1, activation_fn=None, scope="disc_rf", trainable=isTrainable)
            # net = tf.layers.dense(inputs=x, units=opt.ndh, \
            #                       kernel_initializer=tf.random_normal_initializer(mean=0, stddev=0.02), \
            #                       activation=tf.nn.leaky_relu, name='disc_fc1', trainable=isTrainable, reuse=reuse)
            #
            # real_fake = tf.layers.dense(inputs=net, units=1, \
            #                             kernel_initializer=tf.random_normal_initializer(mean=0, stddev=0.02), \
            #                             activation=None, name='disc_rf', trainable=isTrainable, reuse=reuse)
            return tf.reshape(real_fake, [-1])

    def classificationLayer(self, gan_res, classes, classLabel=None, name="predicate", reuse=False, isTrainable=True):
        with tf.variable_scope(name, reuse=reuse) as scope:
            subVector, objVector = tf.split(gan_res, 2, axis=0)
            subVec = self.subVisual*subVector
            objVec = self.objVisual*objVector
            edge = slim.fully_connected(subVec - objVec, self.featureDim, scope="feature")
            # subVector = subVisual
            # objVector = objVisual
            # 先差再乘
            # visual = self.subVisual - self.objVisual
            # edge = slim.fully_connected(visual*gan_res, self.featureDim, scope="feature")
            # originalEdge = slim.fully_connected((self.subVisual-self.objVisual)*(self.subVector-self.objVector), self.featureDim,
            #                                     scope="feature", reuse=True)
            originalEdge = slim.fully_connected(self.subVisual*self.subVector-self.objVisual*self.objVector, self.featureDim,
                                                scope="feature", reuse=True)
            originalFeature = tf.concat((originalEdge, self.spatial), axis=-1)
            edgeFeature = tf.concat((edge, self.spatial), axis=-1)
            score = slim.fully_connected(edgeFeature, num_outputs=self.relationClass)
            originalScore = slim.fully_connected(originalFeature, num_outputs=self.relationClass, scope="fully_connected", reuse=True)
            EdgeScore = tf.nn.softmax(score+originalScore, dim=-1)# + tf.nn.softmax(originalScore, dim=-1)

        return score, EdgeScore, originalScore, tf.nn.softmax(score, dim=-1)

    def classificationLayerAtt(self, gan_res, classes, classLabel=None, name="predicate", reuse=False, isTrainable=True):
        print("use attention predicate")
        with tf.variable_scope(name, reuse=reuse) as scope:
            subVector, objVector = tf.split(gan_res, 2, axis=0)
            subVec = self.subVisual*subVector*self.subEdgeVector
            objVec = self.objVisual*objVector*self.objEdgeVector
            # subVec = self.subVisual * subVector
            # objVec = self.objVisual * objVector
            edge = slim.fully_connected(subVec - objVec, self.featureDim, scope="feature")

            originalEdge = slim.fully_connected(self.subVisual*self.subVector*self.subEdgeVector-self.objVisual*self.objVector*self.objEdgeVector,
                                                self.featureDim, scope="feature", reuse=True)
            # originalEdge = slim.fully_connected(
            #     self.subVisual * self.subVector - self.objVisual * self.objVector,
            #     self.featureDim, scope="feature", reuse=True)
            # originalFeature = tf.concat((originalEdge, self.spatial, self.context), axis=-1)
            originalFeature = tf.concat((originalEdge, self.spatial), axis=-1)
            edgeFeature = tf.concat((edge, self.spatial), axis=-1)

            self.relFeature = [originalFeature, edgeFeature]

            score = slim.fully_connected(edgeFeature, num_outputs=self.relationClass)
            originalScore = slim.fully_connected(originalFeature, num_outputs=self.relationClass, scope="fully_connected", reuse=True)
            EdgeScore = tf.nn.softmax(score+originalScore, dim=-1)# + tf.nn.softmax(originalScore, dim=-1)

        return score, EdgeScore, originalScore, tf.nn.softmax(score, dim=-1)

    def getWordVector(self, Object, path=None):
        with tf.variable_scope("Word2Vec"):
            LoadPath = path if path else os.path.join("dataset", "InitEmbedding.npy")
            init = tf.constant(np.load(LoadPath), dtype=tf.float32)
            ObjectEmbedding = tf.get_variable("ObjectEmbedding", initializer=init, trainable=True)
            Vectors = tf.nn.embedding_lookup(ObjectEmbedding, Object)
            VectorsDim = Vectors.get_shape()[-1]
        print("get word vector and shape is:", Vectors.get_shape())
        sub, obj = tf.split(Vectors, 2, axis=0)
        return sub, obj

    def getArchOptimizer(self, batch_size=16, att=None):
        # best record: 0.534796573875803 zero recall: 0.22070145423438836
        # new 乘差: 0.5346627408993576 0.2309666381522669

        # train with feature vector no spatial 0.001:0.530
        train = True
        # use label and spatial feature to generate the cnn feature
        objectLabel = tf.concat((self.subLabel, self.objLabel), axis=0)
        subVector, objVector = self.getWordVector(objectLabel)
        # subVector = tf.concat((subVector, self.spatial), axis=-1)
        # objVector = tf.concat((objVector, self.spatial), axis=-1)
        featureVector = tf.concat((subVector, objVector), axis=0)
        visualRes = tf.concat((self.subVector, self.objVector), axis=0)
        # featureVector = tf.concat((subVector, objVector, self.spatial), axis=-1)
        # visualRes = self.subVector - self.objVector
        noise = tf.concat([self.z, featureVector], axis=1)

        gen_res = self.generator(noise, isTrainable=train)
        if att is None:
            classificationLogits, score, _, generateScore = self.classificationLayer(gen_res, self.objectClass, objectLabel, isTrainable=False)
        else:
            # with self attention--best-0.5550
            # No self attention--best-0.5360-0.540和之前的差不多
            classificationLogits, score, _, generateScore = self.classificationLayerAtt(gen_res, self.objectClass, objectLabel, isTrainable=False)

        targetEmbd = tf.concat([visualRes, featureVector], axis=1)
        targetDisc = self.discriminator(targetEmbd, isTrainable=train)

        genTargetEmbd = tf.concat([gen_res, featureVector], axis=1)
        genTargetDisc = self.discriminator(genTargetEmbd, isTrainable=train, reuse=True)

        ############ classification loss #########################
        classificationLoss = tf.reduce_mean(
            tf.nn.sparse_softmax_cross_entropy_with_logits(logits=classificationLogits, labels=self.rel))
        ############ discriminator loss ##########################
        genDiscMean = tf.reduce_mean(genTargetDisc)
        # targetDiscMean = tf.reduce_mean(targetDisc)
        discriminatorLoss = tf.reduce_mean(genTargetDisc-targetDisc)

        alpha = tf.random_uniform(shape=[tf.shape(visualRes)[0], 1], minval=0., maxval=1.)

        # differences = genTargetEnc - targetEnc
        # interpolates = targetEnc + (alpha*differences)
        interpolates = alpha * visualRes + ((1 - alpha) * gen_res)
        interpolate = tf.concat([interpolates, featureVector], axis=1)
        gradients = tf.gradients(self.discriminator(interpolate, reuse=True, isTrainable=train), [interpolates])[0]
        slopes = tf.sqrt(tf.reduce_sum(tf.square(gradients), reduction_indices=[1]))
        gradientPenalty = tf.reduce_mean((slopes - 1.) ** 2)

        gradientPenalty = 10* gradientPenalty
        ## visual
        tf.summary.scalar("DiscriminatorLoss", discriminatorLoss)
        discriminatorLoss = discriminatorLoss + gradientPenalty

        # Wasserstein generator loss
        # 0.01: 0.5121/0.1745; 0.1: 0.5303/0.1796 ;1.0: 0.5282/0.1976
        genLoss = -genDiscMean
        tf.summary.scalar("GeneratorLoss", genLoss)
        generatorLoss = genLoss + classificationLoss*0.1

        #################### getting parameters to optimize ####################
        discParams = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, scope='discriminator')
        generatorParams = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, scope='generator')

        for params in discParams:
            print(params.name)

        for params in generatorParams:
            print(params.name)

        #################### what all to visualize  ############################

        tf.summary.scalar("ClassificationLoss", classificationLoss)

        tf.summary.scalar("GradientPenaltyTerm", gradientPenalty)

        # discOptimizer = tf.train.AdamOptimizer(learning_rate=self.lr)
        discOptimizer = tf.train.GradientDescentOptimizer(learning_rate=self.lr)
        # genOptimizer = tf.train.AdamOptimizer(learning_rate=self.lr)
        genOptimizer = tf.train.GradientDescentOptimizer(learning_rate=self.lr)

        discGradsVars = discOptimizer.compute_gradients(discriminatorLoss, var_list=discParams)
        genGradsVars = genOptimizer.compute_gradients(generatorLoss, var_list=generatorParams)

        discTrain = discOptimizer.apply_gradients(discGradsVars)
        generatorTrain = genOptimizer.apply_gradients(genGradsVars)
        return discTrain, generatorTrain, discriminatorLoss, generatorLoss, score, generateScore

    def getRestore(self):
        params = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope='predicate')
        saver = tf.train.Saver(var_list=params)

        generatorParams = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, scope='generator')
        save = tf.train.Saver()
        return saver, save

    def TrainTest(self, trainData, testData, restorePath,Epoch=200, batch=16):
        discTrain, generatorTrain, discriminatorLoss, generatorLoss, EdgeScore, originalScore = self.getArchOptimizer()
        reStore, save = self.getRestore()
        savePath = os.path.join("ckpt", "visual", "embeddingNoSpatial")
        if not os.path.exists(savePath):
            os.makedirs(savePath)
        cytle = 5
        best = 0.0
        bestZero = 0.0
        config = tf.ConfigProto(allow_soft_placement=True)
        config.gpu_options.per_process_gpu_memory_fraction = 0.55
        RecallStore = []
        merged_all = tf.summary.merge_all()
        logdir = os.path.join("result", "record")
        k = 1
        with tf.Session(config=config) as sess:
            sess.run(tf.global_variables_initializer())
            # restore the relation matrix and layer
            reStore.restore(sess, restorePath)
            summary_writer = tf.summary.FileWriter(logdir, sess.graph)
            allDisLoss, allGenLoss = [], []
            for epoch in range(Epoch):
                epochDisLoss, epochGenLoss = [], []
                for i in range(0, trainData.size, batch):
                    tempDisLoss = []
                    for j in range(cytle):
                        batch_subVisual, batch_objVisuals, batch_subVectors, batch_objVectors, \
                        batch_edgeVectors, batch_subLabels, batch_objLabels, batch_rel, z_rand = trainData.next_batch(batch)
                        batch_z = np.random.normal(0, 1, [batch*2, 128]).astype(np.float32)
                        feedDict = {
                            self.subVisual: batch_subVisual,
                            self.objVisual: batch_objVisuals,
                            self.subVector: batch_subVectors,
                            self.objVector: batch_objVectors,
                            self.subLabel: batch_subLabels,
                            self.objLabel: batch_objLabels,
                            self.spatial: batch_edgeVectors,
                            self.rel: batch_rel,
                            self.z:batch_z
                        }
                        _, discLoss, merged = sess.run([discTrain, discriminatorLoss, merged_all],
                                                       feed_dict=feedDict)
                        if j == 0:
                            summary_writer.add_summary(merged, k)
                        tempDisLoss.append(discLoss)
                    epochDisLoss.append(tempDisLoss)
                    batch_subVisual, batch_objVisuals, batch_subVectors, batch_objVectors, \
                    batch_edgeVectors, batch_subLabels, batch_objLabels, batch_rel, z_rand = trainData.next_batch(
                        batch)
                    batch_z = np.random.normal(0, 1, [batch*2, 128]).astype(np.float32)
                    feedDict = {
                        self.subVisual: batch_subVisual,
                        self.objVisual: batch_objVisuals,
                        self.subVector: batch_subVectors,
                        self.objVector: batch_objVectors,
                        self.subLabel: batch_subLabels,
                        self.objLabel: batch_objLabels,
                        self.spatial: batch_edgeVectors,
                        self.rel: batch_rel,
                        self.z:batch_z
                    }
                    _, genLoss, merged = sess.run([generatorTrain, generatorLoss, merged_all], feed_dict=feedDict)
                    summary_writer.add_summary(merged, k)
                    epochGenLoss.append(genLoss)
                    k = k + 1
                allDisLoss.append(epochDisLoss)
                allGenLoss.append(epochGenLoss)
                print("train finish")
                evalTest = EvalRecallUnion()
                subVisuals, objVisuals, subVectors, objVectors, edgeVectors, subLabels, objLabels, rels, values, length = np.load(
                    testData)
                for batch_subVisual, batch_objVisuals, batch_subVectors, batch_objVectors, \
                    batch_edgeVectors, batch_subLabels, batch_objLabels, batch_rel, value \
                        in zip(subVisuals, objVisuals, subVectors, objVectors, edgeVectors, subLabels, objLabels, rels, values):
                    rel, subLabel, objLabel, subject, objects, imgName = value
                    batch_z = np.random.normal(0, 1, [batch*2, 128]).astype(np.float32)
                    feedDict = {
                        self.subVisual: batch_subVisual,
                        self.objVisual: batch_objVisuals,
                        self.subVector: batch_subVectors,
                        self.objVector: batch_objVectors,
                        self.subLabel: batch_subLabels,
                        self.objLabel: batch_objLabels,
                        self.spatial: batch_edgeVectors,
                        self.rel: batch_rel,
                        self.z: batch_z
                    }
                    score = sess.run(EdgeScore, feed_dict=feedDict)
                    evalTest.add(rel, score, subLabel, objLabel, subject, objects, imgName, None)
                evalTest.eval(length)
                evalTest.show()
                temp  = evalTest.getRecall()
                tempZero = evalTest.getZero()
                RecallStore.append((temp, tempZero))
                if temp+tempZero > best:
                    best = temp+tempZero
                    bestZero = tempZero
                    save.save(sess, os.path.join(savePath, "embedding"))
                print("best record:", best-bestZero, "zero recall:", bestZero)
            summary_writer.close()
            np.save(os.path.join("dataset", "GanRecall"),RecallStore)
            np.save(os.path.join("dataset", "GanGenLoss"), allGenLoss)
            np.save(os.path.join("dataset", "GanDisLoss"), allDisLoss)

    def testVisual(self, testPath, restorePath):

        ##########################################
        # build network
        objectLabel = tf.concat((self.subLabel, self.objLabel), axis=0)
        subVector, objVector = self.getWordVector(objectLabel)
        subVector = tf.concat((subVector, self.spatial), axis=-1)
        objVector = tf.concat((objVector, self.spatial), axis=-1)
        # featureVector = tf.concat((subVector, objVector, self.spatial), axis=-1)
        featureVector = tf.concat((subVector, objVector), axis=0)
        noise = tf.concat([self.z, featureVector], axis=1)

        gen_res = self.generator(noise, isTrainable=False)
        classificationLogits, EdgeScore, originalScore, generateScore = self.classificationLayer(gen_res, self.objectClass, objectLabel,
                                                                                         isTrainable=False)
        ########################################
        #get restore params
        predicateParams = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope='predicate')
        predicateSaver = tf.train.Saver(var_list=predicateParams)
        predicatePath = os.path.join("ckpt", "visual", "predicate-乘差-0.5364--0.230", "predicate")

        generateParams = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope='generator')
        generateSaver = tf.train.Saver(var_list=generateParams)
        # generatePath = os.path.join("ckpt", "visual", "genrate-乘差-0.5364--0.230", "embedding")
        generatePath = os.path.join(restorePath, "embedding")
        allSaver = tf.train.Saver()
        ########################################
        # get test result
        evalTest = EvalRecallUnion()
        # subVisuals, objVisuals, subVectors, objVectors, edgeVectors, subLabels, objLabels, rels, values, length = np.load(testPath)
        config = tf.ConfigProto(allow_soft_placement=True)
        config.gpu_options.per_process_gpu_memory_fraction = 0.55
        with tf.Session(config=config) as sess:
            sess.run(tf.global_variables_initializer())
            # predicateSaver.restore(sess, predicatePath)
            # generateSaver.restore(sess, generatePath)
            allSaver.restore(sess, restorePath)
            varList = []
            testFeature, length = np.load(testPath)
            for test in testFeature:
                rel, subLabel, objLabel, subject, objects, imgName = test["value"]
                batch_z = np.random.normal(0, 1, [batch * 2, 128]).astype(np.float32)
                feedDict = {
                    self.subVisual: test["subVisual"],
                    self.objVisual: test["objVisual"],
                    self.subVector: test["subLabelMask"],
                    self.objVector: test["objLabelMask"],
                    self.subLabel: subLabel,
                    self.objLabel: objLabel,
                    self.subEdgeVector: test["subEdgeMask"],
                    self.objEdgeVector: test["objEdgeMask"],
                    self.spatial: test["edgeVector"],
                    self.rel: rel,
                    self.z: batch_z,
                    # self.context: test["context"]
                }
                # score, generateScoreValue = sess.run([EdgeScore, generateScore], feed_dict=feedDict)
                score, originalScoreValue, generateScoreValue = sess.run([EdgeScore, originalScore, generateScore], feed_dict=feedDict)
                evalTest.add(rel, score, subLabel, objLabel, subject, objects, imgName, None)
                varList.append([rel, score, subLabel, objLabel, subject, objects, imgName, originalScoreValue, generateScoreValue])
            evalTest.eval(length)
            evalTest.show()
            savePath = os.path.join(restorePath, "testRes")
            # np.save(savePath, [varList, length])

    def TrainTestAtt(self, trainData, testPath, restorePath,Epoch=1000, batch=16, savePath=None):
        discTrain, generatorTrain, discriminatorLoss, generatorLoss, EdgeScore, generateScore = self.getArchOptimizer(att=True)
        reStore, save = self.getRestore()
        savePath = savePath if savePath else os.path.join("ckpt", "visual", "embeddingAttNew")
        if not os.path.exists(savePath):
            os.makedirs(savePath)
        cytle = 5
        best = 0.0
        bestZero = 0.0
        config = tf.ConfigProto(allow_soft_placement=True)
        config.gpu_options.per_process_gpu_memory_fraction = 0.55
        RecallStore = []
        merged_all = tf.summary.merge_all()
        logdir = os.path.join("result", "record")
        k = 1
        with tf.Session(config=config) as sess:
            sess.run(tf.global_variables_initializer())
            # restore the relation matrix and layer
            reStore.restore(sess, restorePath)
            # summary_writer = tf.summary.FileWriter(logdir, sess.graph)
            allDisLoss, allGenLoss = [], []
            for epoch in range(Epoch):
                epochDisLoss, epochGenLoss = [], []
                for i in range(0, trainData.size, batch):
                    tempDisLoss = []
                    for j in range(cytle):
                        batch_subVisual, batch_objVisuals, batch_subVectors, batch_objVectors, \
                        batch_subEdgeMask, batch_objEdgeMask, batch_context, batch_edgeVectors, batch_subLabels, batch_objLabels, batch_rel, z_rand = trainData.next_batch(batch)
                        batch_z = np.random.normal(0, 1, [batch*2, 128]).astype(np.float32)
                        feedDict = {
                            self.subVisual: batch_subVisual,
                            self.objVisual: batch_objVisuals,
                            self.subVector: batch_subVectors,
                            self.objVector: batch_objVectors,
                            self.subEdgeVector:batch_subEdgeMask,
                            self.objEdgeVector:batch_objEdgeMask,
                            self.subLabel: batch_subLabels,
                            self.objLabel: batch_objLabels,
                            self.spatial: batch_edgeVectors,
                            # self.context: batch_context,
                            self.rel: batch_rel,
                            self.z:batch_z
                        }
                        _, discLoss, merged = sess.run([discTrain, discriminatorLoss, merged_all],
                                                       feed_dict=feedDict)
                    #     if j == 0:
                    #         summary_writer.add_summary(merged, k)
                    #     tempDisLoss.append(discLoss)
                    # epochDisLoss.append(tempDisLoss)
                    batch_subVisual, batch_objVisuals, batch_subVectors, batch_objVectors, \
                    batch_subEdgeMask, batch_objEdgeMask, batch_context, batch_edgeVectors, batch_subLabels, batch_objLabels, batch_rel, z_rand = trainData.next_batch(
                        batch)
                    batch_z = np.random.normal(0, 1, [batch*2, 128]).astype(np.float32)
                    feedDict = {
                        self.subVisual: batch_subVisual,
                        self.objVisual: batch_objVisuals,
                        self.subVector: batch_subVectors,
                        self.objVector: batch_objVectors,
                        self.subEdgeVector: batch_subEdgeMask,
                        self.objEdgeVector: batch_objEdgeMask,
                        self.subLabel: batch_subLabels,
                        self.objLabel: batch_objLabels,
                        self.spatial: batch_edgeVectors,
                        # self.context: batch_context,
                        self.rel: batch_rel,
                        self.z: batch_z
                    }
                    _, genLoss, merged = sess.run([generatorTrain, generatorLoss, merged_all], feed_dict=feedDict)
                    # summary_writer.add_summary(merged, k)
                    # epochGenLoss.append(genLoss)
                    # k = k + 1
                # allDisLoss.append(epochDisLoss)
                # allGenLoss.append(epochGenLoss)
                print("train finish")
                evalTest = EvalRecallUnion()
                evalTestGenerate = EvalRecallUnion()
                testFeature, length = np.load(testPath)
                for test in testFeature:
                    rel, subLabel, objLabel, subject, objects, imgName = test["value"]
                    batch_z = np.random.normal(0, 1, [batch * 2, 128]).astype(np.float32)
                    feedDict = {
                        self.subVisual: test["subVisual"],
                        self.objVisual: test["objVisual"],
                        self.subVector: test["subLabelMask"],
                        self.objVector: test["objLabelMask"],
                        self.subLabel: subLabel,
                        self.objLabel: objLabel,
                        self.subEdgeVector: test["subEdgeMask"],
                        self.objEdgeVector: test["objEdgeMask"],
                        self.spatial: test["edgeVector"],
                        self.rel: rel,
                        self.z: batch_z,
                        # self.context: test["context"]
                    }
                    score, generateScoreValue = sess.run([EdgeScore, generateScore], feed_dict=feedDict)
                    evalTest.add(rel, score, subLabel, objLabel, subject, objects, imgName, None)
                    evalTestGenerate.add(rel, generateScoreValue, subLabel, objLabel, subject, objects, imgName, None)
                evalTest.eval(length)
                evalTest.showSimple()
                print("*"*40, "generate-score")
                evalTestGenerate.eval(length)
                evalTestGenerate.showSimple()
                print("*" * 40)
                temp  = evalTest.getRecall()
                tempZero = evalTest.getZero()*0.5
                generateTemp = evalTestGenerate.getRecall()
                generateTempZero = evalTestGenerate.getZero()
                RecallStore.append((temp, tempZero*2, generateTemp, generateTempZero))
                if temp+tempZero > best:
                    best = temp+tempZero
                    bestZero = tempZero
                #     save.save(sess, os.path.join(savePath,"embedding"))
                print("best record:", best-bestZero, "zero recall:", bestZero*2)
            # summary_writer.close()
            # np.save(os.path.join(savePath, "GanRecall-adam"), RecallStore)

    def getFeature(self, testPath, restorePath):
        discTrain, generatorTrain, discriminatorLoss, generatorLoss, EdgeScore, generateScore = self.getArchOptimizer(
            att=True)
        restore = tf.train.Saver()
        config = tf.ConfigProto(allow_soft_placement=True)
        config.gpu_options.per_process_gpu_memory_fraction = 0.55
        relGenerate, relOriginal = [], []
        with tf.Session(config=config) as sess:
            # restore the relation matrix and layer
            restore.restore(sess, os.path.join(restorePath, "embedding"))
            evalTest = EvalRecallUnion()
            testFeature, length = np.load(testPath)
            for test in testFeature:
                rel, subLabel, objLabel, subject, objects, imgName = test["value"]
                batch_z = np.random.normal(0, 1, [batch * 2, 128]).astype(np.float32)
                feedDict = {
                    self.subVisual: test["subVisual"],
                    self.objVisual: test["objVisual"],
                    self.subVector: test["subLabelMask"],
                    self.objVector: test["objLabelMask"],
                    self.subLabel: subLabel,
                    self.objLabel: objLabel,
                    self.subEdgeVector: test["subEdgeMask"],
                    self.objEdgeVector: test["objEdgeMask"],
                    self.spatial: test["edgeVector"],
                    self.rel: rel,
                    self.z: batch_z,
                    # self.context: test["context"]
                }
                score, generateScoreValue, relFeature = sess.run([EdgeScore, generateScore, self.relFeature], feed_dict=feedDict)
                tempGe, tempOr = record(relFeature[1], relFeature[0], generateScoreValue, score, rel)
                relGenerate.extend(tempGe)
                relOriginal.extend(tempOr)
                evalTest.add(rel, score, subLabel, objLabel, subject, objects, imgName, None)
            evalTest.eval(length)
            evalTest.showSimple()
            savePath = os.path.join("ckpt", "feature")
            if not os.path.exists(savePath):
                os.makedirs(savePath)
            np.save(os.path.join(savePath, "generateFea.npy"), relGenerate)
            np.save(os.path.join(savePath, "originalFea.npy"), relOriginal)
            # addCorrect = [(i[4], i[-2], i[-1]) for i in evalTest.correctTripe]
            # generateCorrect = [(i[4], i[-2], i[-1]) for i in evalTestGenerate.correctTripe]
            # savePath = os.path.join(restorePath, "testRes")
            # np.save(savePath, (addCorrect, generateCorrect))

class GeneratorFuse(Adversarial_Generator):

    def __init__(self):
        Adversarial_Generator.__init__(self)
        self.lr = 0.00001
        self.weight = tf.placeholder(tf.float32, [None,])

    def getRestore(self, train):
        generateParams = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope='generator')
        generateSaver = tf.train.Saver(var_list=generateParams)
        if train:
            predicateParams = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, scope='predicate')
        else:
            predicateParams = tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES, scope='predicate')
        predicateSaver = tf.train.Saver(var_list=predicateParams)
        save = tf.train.Saver()
        return generateSaver, predicateSaver, save

    def fuse(self, predicateTrain):
        train = False
        ###############################
        # build network
        objectLabel = tf.concat((self.subLabel, self.objLabel), axis=0)
        subVector, objVector = self.getWordVector(objectLabel)
        # subVector = tf.concat((subVector, self.spatial), axis=-1)
        # objVector = tf.concat((objVector, self.spatial), axis=-1)
        featureVector = tf.concat((subVector, objVector), axis=0)

        noise = tf.concat([self.z, featureVector], axis=1)
        gan_res = self.generator(noise, isTrainable=train)

        #build classify
        with tf.variable_scope("predicate"):
            subVector, objVector = tf.split(gan_res, 2, axis=0)
            subVec = self.subVisual*subVector
            objVec = self.objVisual*objVector
            edge = slim.fully_connected(subVec - objVec, self.featureDim, scope="feature", trainable=predicateTrain)
            originalEdge = slim.fully_connected(self.subVisual*self.subVector-self.objVisual*self.objVector, self.featureDim,
                                                scope="feature", reuse=True, trainable=predicateTrain)
            originalFeature = tf.concat((originalEdge, self.spatial), axis=-1)
            edgeFeature = tf.concat((edge, self.spatial), axis=-1)
            score = slim.fully_connected(edgeFeature, num_outputs=self.relationClass, trainable=predicateTrain)
            originalScore = slim.fully_connected(originalFeature, num_outputs=self.relationClass, scope="fully_connected",
                                                 reuse=True, trainable=predicateTrain)
            EdgeScore = tf.nn.softmax(score+originalScore, dim=-1)# + tf.nn.softmax(originalScore, dim=-1)

        # fuse the subVector/objVector and gan generate subVector/objVector
        # two ways: self-attention and Differential context information
        # different context information ------fuck
        with tf.variable_scope("attention-fuse"):
            subSimVector = tf.reduce_sum(subVector*self.subVector, axis=-1, keep_dims=True)*(subVector/tf.norm(subVector, ord=2, axis=-1, keep_dims=True))
            attSubVector = subSimVector + subVector

            objSimVector = tf.reduce_sum(objVector*self.objVector, axis=-1, keep_dims=True)*(objVector/tf.norm(objVector, ord=2, axis=-1, keep_dims=True))
            attObjVector = objSimVector + objVector
        with tf.variable_scope("predicate"):
            attentionEdge = slim.fully_connected(self.subVisual*attSubVector-self.objVisual*attObjVector, self.featureDim,
                                                 scope="feature", reuse=True, trainable=predicateTrain)
            attentionEdge = tf.concat((attentionEdge, self.spatial), axis=-1)
            attentionScore = slim.fully_connected(attentionEdge, self.relationClass, scope="fully_connected",
                                                  reuse=True, trainable=predicateTrain)
            attentionScoreValue = tf.nn.softmax(attentionScore, dim=-1)
        # # self-attention:query, key, value: value*(query X key)
        # subVecAttention = slim.fully_connected(tf.concat((subVector, objVector), axis=-1), num_outputs=self.featureDim)
        # attentionSubVector = subVecAttention*self.subVisual
        #
        # objVecAttention = slim.fully_connected(tf.concat((subVector, objVector), axis=-1), num_outputs=self.featureDim)
        # attentionObjVector = objVecAttention*self.objVisual
        # with tf.variable_scope("predicate"):
        #     attentionEdge = slim.fully_connected(attentionSubVector-attentionObjVector, self.featureDim,
        #                                          scope="feature", reuse=True, trainable=predicateTrain)
        #     attentionEdge = tf.concat((attentionEdge, self.spatial), axis=-1)
        #     attentionScore = slim.fully_connected(attentionEdge, self.relationClass, scope="fully_connected",
        #                                           reuse=True, trainable=predicateTrain)
        #     attentionScoreValue = tf.nn.softmax(attentionScore, dim=-1)

        # different edgeScore
        # best weight: 0.5453/0.2095 (此时attention sum: 0.5441/0.2053)
        # best attention:
        originalScoreValue = tf.nn.softmax(originalScore, dim=-1)
        scoreValue = tf.nn.softmax(score, dim=-1)
        weight = tf.expand_dims(1/(1+tf.exp(-self.weight))-0.5, axis=-1)
        weightScore = weight*originalScoreValue+(1-weight)*scoreValue
        attentionScore = attentionScoreValue
        allScore = [originalScoreValue, scoreValue, EdgeScore, weightScore, attentionScore]

        classificationLoss = tf.reduce_mean(
            tf.nn.sparse_softmax_cross_entropy_with_logits(logits=score, labels=self.rel))
        # optimize process
        # Optimizer = tf.train.GradientDescentOptimizer(learning_rate=self.lr)
        # params = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, scope='predicate')
        # discGradsVars = Optimizer.compute_gradients(classificationLoss, var_list=params)
        # trainStep = Optimizer.apply_gradients(discGradsVars)
        optimizer = tf.train.AdamOptimizer(learning_rate=self.lr)
        train_step = slim.learning.create_train_op(classificationLoss, optimizer)
        return train_step, classificationLoss, allScore

    @staticmethod
    def getTrainCount():
        trainPath = os.path.join("dataset", "json_dataset", "annotations_train.json")
        trainData = json.load(open(trainPath))
        trainPhrase = []
        for name, rels in trainData.items():
            for rel in rels:
                sub = rel["subject"]["category"]
                obj = rel["object"]["category"]
                predicate = rel["predicate"]
                trainPhrase.append((sub, obj, predicate))
        trainCount = dict()
        for sub, obj, rel in trainPhrase:
            trainCount[(sub, obj, rel)] = trainCount.get((sub, obj, rel), 0) + 1
        return trainCount

    def trainTest(self, trainData, testData, restorePath, batch=16, Epoch=1000):
        predicateTrain = True
        trainStep, trainLoss,EdgeScore = self.fuse(predicateTrain)
        generateReStore, predicateReStore,save = self.getRestore(predicateTrain)
        savePath = os.path.join("ckpt", "visual", "embeddingNoSpatialAttention")
        if not os.path.exists(savePath):
            os.makedirs(savePath)
        trainCount = self.getTrainCount()
        best = 0.0
        bestZero = 0.0
        config = tf.ConfigProto(allow_soft_placement=True)
        config.gpu_options.per_process_gpu_memory_fraction = 0.55
        RecallStore = []
        with tf.Session(config=config) as sess:
            sess.run(tf.global_variables_initializer())
            # restore the relation matrix and layer
            generateReStore.restore(sess, restorePath)
            predicateReStore.restore(sess, restorePath)
            for epoch in range(Epoch):
                for i in range(0, trainData.size, batch):
                    batch_subVisual, batch_objVisuals, batch_subVectors, batch_objVectors, \
                    batch_edgeVectors, batch_subLabels, batch_objLabels, batch_rel, z_rand = trainData.next_batch(
                        batch)
                    batch_z = np.random.normal(0, 1, [batch * 2, 128]).astype(np.float32)
                    feedDict = {
                        self.subVisual: batch_subVisual,
                        self.objVisual: batch_objVisuals,
                        self.subVector: batch_subVectors,
                        self.objVector: batch_objVectors,
                        self.subLabel: batch_subLabels,
                        self.objLabel: batch_objLabels,
                        self.spatial: batch_edgeVectors,
                        self.rel: batch_rel,
                        self.z: batch_z
                    }
                    _, discLoss = sess.run([trainStep, trainLoss], feed_dict=feedDict)
                print("train finish")
                evalTestAdd = EvalRecallUnion()
                evalTestOriginal = EvalRecallUnion()
                evalTestGenerate = EvalRecallUnion()
                evalTestWeight = EvalRecallUnion()
                evalTestAttention = EvalRecallUnion()
                subVisuals, objVisuals, subVectors, objVectors, edgeVectors, subLabels, objLabels, rels, values, length = np.load(
                    testData)
                for batch_subVisual, batch_objVisuals, batch_subVectors, batch_objVectors, \
                    batch_edgeVectors, batch_subLabels, batch_objLabels, batch_rel, value \
                        in zip(subVisuals, objVisuals, subVectors, objVectors, edgeVectors, subLabels, objLabels, rels,
                               values):
                    rel, subLabel, objLabel, subject, objects, imgName = value
                    batch_z = np.random.normal(0, 1, [batch * 2, 128]).astype(np.float32)
                    weight = [trainCount.get((sub, obj, relTemp), 0) for sub, obj, relTemp in zip(subLabel, objLabel, rel)]
                    feedDict = {
                        self.subVisual: batch_subVisual,
                        self.objVisual: batch_objVisuals,
                        self.subVector: batch_subVectors,
                        self.objVector: batch_objVectors,
                        self.subLabel: batch_subLabels,
                        self.objLabel: batch_objLabels,
                        self.spatial: batch_edgeVectors,
                        self.rel: batch_rel,
                        self.weight:weight,
                        self.z: batch_z
                    }
                    score = sess.run(EdgeScore, feed_dict=feedDict)
                    # get different case edgeScore
                    originalScore, generateScore, addScore, weightScore, attentionScore = score
                    evalTestAdd.add(rel, addScore, subLabel, objLabel, subject, objects, imgName, None)
                    evalTestOriginal.add(rel, originalScore, subLabel, objLabel, subject, objects, imgName, None)
                    evalTestGenerate.add(rel, generateScore, subLabel, objLabel, subject, objects, imgName, None)
                    evalTestWeight.add(rel, weightScore, subLabel, objLabel, subject, objects, imgName, None)
                    evalTestAttention.add(rel, attentionScore, subLabel, objLabel, subject, objects, imgName, None)
                evalTestAdd.eval(length)
                evalTestOriginal.eval(length)
                evalTestGenerate.eval(length)
                evalTestWeight.eval(length)
                evalTestAttention.eval(length)

                evalTestAdd.show()
                print("*"*30, "original")
                evalTestOriginal.show()
                print("*" * 30, "generate")
                evalTestGenerate.show()
                print("*" * 30, "weight")
                evalTestWeight.show()
                print("*" * 30, "attention")
                evalTestAttention.show()
                print("-"*50)
                temp = evalTestWeight.getRecall()
                tempZero = evalTestWeight.getZero()
                RecallStore.append((temp, tempZero))
                if temp + tempZero > best:
                    best = temp + tempZero
                    bestZero = tempZero
                    save.save(sess, os.path.join(savePath, "embedding"))
                print("best record:", best - bestZero, "zero recall:", bestZero)

if __name__ == "__main__":
    batch = 16
    # trainPath = os.path.join("ckpt", "visual", "predicate-乘差-经典", "trainFeature.npy")
    # trainData = FeatureData(trainPath, batch=batch)
    # testPath = os.path.join("ckpt", "visual", "predicate-乘差-经典", "testFeature.npy")
    # trainPath = os.path.join("ckpt", "visual", "withExtraWeight--0.517", "trainFeature.npy")
    # trainData = FeatureData(trainPath, batch=batch)
    # testPath = os.path.join("ckpt", "visual", "withExtraWeight--0.517", "testFeature.npy")
    # testData = None
    # testData = FeatureData(testPath,batch=batch)
    # model = Classifier()
    # model.trainTest(trainData, testPath, batch)
    # restorePath = os.path.join("ckpt", "visual", "predicate-乘差-经典", "predicate")
    # trainPath = os.path.join("ckpt", "visual", "predicate", "trainFeature.npy")
    # trainData = FeatureData(trainPath, batch=batch)
    # testPath = os.path.join("ckpt", "visual", "predicate", "testFeature.npy")
    fileName = "edgeMask--乘---Nocontext--0.5297"
    trainPath = os.path.join("ckpt", "visual", fileName, "trainFeature.npy")
    savePredicatePath = os.path.join("ckpt", "visual", fileName, "predicate")
    # trainData = FeatureDataAtt(trainPath, batch=batch)
    trainData = FeatureDataAtt(trainPath, batch=batch)
    testPath = os.path.join("ckpt", "visual", fileName, "testFeature.npy")
    # model = Classifier()
    # model.trainTestAtt(trainData, testPath, batch, savePath=savePredicatePath)
    # restorePath = os.path.join("ckpt", "visual", fileName, "transE")
    # savePath = os.path.join("ckpt", "visual", "predicateNew", "predicate")
    # model.reNameVar(restorePath)
    # model.testReName(testPath, savePath)
    # restorePath = os.path.join("ckpt", "visual", "predicate", "predicate")

    # restorePath = os.path.join("ckpt", "visual", "predicateNew", "predicate")
    restorePath = os.path.join("ckpt", "visual", fileName, "predicate", "predicate")
    # embeddingPath = os.path.join("ckpt", "visual", fileName, "embedding")
    embeddingPath = os.path.join("ckpt", "visual", fileName, "embedding")
    model = Adversarial_Generator()
    model.getFeature(testPath, embeddingPath)
    # model.TrainTestAtt(trainData, testPath, restorePath, savePath=embeddingPath)
    # model.testVisual(testPath, restorePath)

    # trainPath = os.path.join("ckpt", "visual", "predicate-乘差-0.5364--0.230", "trainFeature.npy")
    # trainData = FeatureData(trainPath, batch=batch)
    # testPath = os.path.join("ckpt", "visual", "predicate-乘差-0.5364--0.230", "testFeature.npy")

    # restorePath = os.path.join("ckpt", "visual", "embeddingNoSpatial", "embedding")
    # model = GeneratorFuse()
    # model.trainTest(trainData, testPath, restorePath)