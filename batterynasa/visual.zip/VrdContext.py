import tensorflow as tf
import numpy as np
import os
import pdb
from layer import SelfATT
from EvalRecall import ErrorAnalysis
from VIsualModel import vgg_16
from layer import AlternatingHighWayCell
import tensorflow.contrib.slim as slim
from tensorflow.contrib.slim import nets
from LoadMat import DataLoad
from EvalRecall import EvalRecall
np.set_printoptions(threshold=np.nan)
from configparser import ConfigParser
os.environ["CUDA_VISIBLE_DEVICES"] = "1"
cfg = ConfigParser()
cfg.read("config.ini", encoding="utf-8-sig")

class ContextModel(object):
    def __init__(self):
        self.learning_rate = 0.0001
        self.relationClass = 71
        self.actionClass = 34
        self.prepClass = 26
        self.objectClass = 101

        self.HiddenSize = 100
        self.ImgSize = 224
        self.MaskSize = cfg.getint("data", "mask_shape")
        self.length = 21
        self.size = 1024
        self.iters = 8
        self.dim = 4096
        self.dropout = 1.0
        self.C = 0.5
        # tf placeholder
        self.Regions = tf.placeholder(tf.float32, [self.length, self.ImgSize, self.ImgSize, 3])
        self.ObjectClass =tf.placeholder(tf.int32, [self.length])
        self.RelationClass = tf.placeholder(tf.int32, [None, 5])
        self.BatchSize = tf.placeholder(tf.int32)
        self.TeacherInput = tf.placeholder(tf.float32, [None, self.relationClass])
        self.UnionImg = tf.placeholder(tf.float32, [None, self.ImgSize, self.ImgSize, 3])
        self.SeqLength = tf.placeholder(tf.int32, [1,])
        self.Mask = tf.placeholder(tf.float32, [self.length, self.MaskSize, self.MaskSize])
        self.IsTraining = tf.placeholder(tf.bool, name='is_training')

    def GetArch(self, NumLayers=4, BatchSize=1, teacher=False):
        # Regions = tf.concat((self.Regions, self.UnionImg), axis=0)
        # print("Regions shape:", Regions.get_shape())
        Visual = self.GetVisualFeature(self.Regions)
        # SubVisual = Visual[:,:self.length,:]
        # UnionVisual = Visual[:,self.length:,:]
        Word = self.GetWordVector(self.ObjectClass, path=None)
        WordVector = slim.fully_connected(Word, num_outputs=100, activation_fn=None, biases_initializer=None)
        Visual = tf.concat((Visual, WordVector), axis=-1)
        # # Subjects, Objects = self.RelationLSTM(Visual, Word, BatchSize=BatchSize)
        Subjects = slim.fully_connected(Visual, num_outputs=self.dim, activation_fn=None, biases_initializer=None)
        Objects = slim.fully_connected(Visual, num_outputs=self.dim, activation_fn=None, biases_initializer=None)

        # UnionVisual = slim.fully_connected(UnionVisual, num_outputs=self.dim, activation_fn=None, biases_initializer=None)
        edge, index, maskScore, actionScore = self.getEdgeScore(Subjects, Objects, self.Mask)
        # Edge, index = self.GetRelationCandidate(Subjects, Objects)

        EdgeScore = tf.nn.softmax(edge, dim=-1)
        if teacher is True:
            EdgeScore = EdgeScore * self.TeacherInput
        loss, accuracy, train_step = self.GetOptimizer(edge, maskScore, actionScore, self.RelationClass, Teacher=teacher)

        return loss, accuracy, train_step, EdgeScore, index

    def GetVisualFeature(self, Regions):
        ResNetInput = tf.reshape(Regions, (-1, self.ImgSize, self.ImgSize, 3))
        with slim.arg_scope(nets.vgg.vgg_arg_scope()):
            net, endpoints, feature = vgg_16(ResNetInput, num_classes=None, is_training=self.IsTraining)
        # out, weight = SelfATT(feature, name="att1")
        # out, weight = SelfATT(out, name="att2")
        out = feature
        with tf.variable_scope('vgg_16', reuse=True):
            out = slim.conv2d(out, 4096, [7, 7], padding="VALID", scope='fc6')
            out = slim.dropout(out, 0.5, is_training=self.IsTraining,
                               scope='dropout6')
            out = slim.conv2d(out, 4096, [1, 1], scope='fc7')
        VectorDim = out.get_shape()[-1]
        out = tf.reshape(out, (1, -1, VectorDim))
        return out

    def GetWordVector(self, Object, path=None):
        """
        Get WordVector for object
        :param Object: [Batch, step]: objectId
        :return: 
        """
        # random init
        # r = tf.sqrt(tf.cast(6 / self.embedding_size, dtype=tf.float32))
        # word_embedding = tf.get_variable("embedding", [self.vocab_size, self.embedding_size],
        #                                  initializer=tf.random_uniform_initializer(minval=-r, maxval=r))
        with tf.variable_scope("Word2Vec"):
            LoadPath = path if path else os.path.join("dataset", "InitEmbedding.npy")
            init = tf.constant(np.load(LoadPath), dtype=tf.float32)
            ObjectEmbedding = tf.get_variable("ObjectEmbedding", initializer=init, trainable=True)
            Vectors = tf.nn.embedding_lookup(ObjectEmbedding, Object)
            VectorsDim = Vectors.get_shape()[-1]
            Vectors = tf.reshape(Vectors, (1, -1, VectorsDim))
        print("get word vector")
        return Vectors

    def getRelWordVector(self, relation, path=None):
        with tf.variable_scope("Word2Vec"):
            LoadPath = path if path else os.path.join("dataset", "InitRelEmbedding.npy")
            init = tf.constant(np.load(LoadPath), dtype=tf.float32)
            relEmbedding = tf.get_variable("relEmbedding", initializer=init, trainable=True)
            Vectors = tf.nn.embedding_lookup(relEmbedding, relation)
            VectorsDim = Vectors.get_shape()[-1]
            Vectors = tf.reshape(Vectors, (-1, VectorsDim))
        return Vectors

    def GetPositionMask(self, Positions, name="binary_mask", reuse=False):
        # two binary mask [None, 32,32, 2]
        # 8.24添加，未服务器运行
        spatial = Positions
        with tf.variable_scope(name, reuse=reuse):
            conv1 = slim.conv2d(spatial, num_outputs=96, kernel_size=5, stride=2, padding='SAME', scope="conv1")
            conv2 = slim.conv2d(conv1, num_outputs=128, kernel_size=5, stride=2, padding="SAME", scope="conv2")
            conv3 = slim.conv2d(conv2, num_outputs=64, kernel_size=8, stride=1, padding="VALID", scope="conv3")
            spatial_feature = tf.reshape(conv3, [1, -1, 1 * 1 * 64])
        return spatial_feature

    @staticmethod
    def high_way(x, size, name="char", reuse=False):
        """Highway layers
            args: 
                size: input and output dimension
                dropout_ratio: dropout ratio
            """
        # the formula:
        # m=H(n)=t⊙g(WHn+bH)+(1−t)⊙n
        # t=σ(WTn+bT)
        with tf.variable_scope(name, reuse=reuse):
            # step, num_unit = x.get_shape()[1], x.get_shape()[-1]
            # x = tf.reshape(x, [-1, num_unit])
            h = slim.fully_connected(x, size, activation_fn=tf.nn.relu, scope="fc_h")
            t = slim.fully_connected(x, size, activation_fn=tf.nn.sigmoid, scope="fc_t")
            out = t*h + (1-t)*x
        return out

    def SingleLSTMLayer(self, LSTMInput, NumUnits, SeqLen=None, DropOut=1.0, name="LSTM_Layer", reuse=False, BatchSize=1):
        # Single LSTM layer is used to encoding the SubImg information
        with tf.variable_scope(name, reuse=reuse):
            fw_cell = AlternatingHighWayCell(NumUnits)
            bw_cell = AlternatingHighWayCell(NumUnits)
            # fw_cell = tf.contrib.rnn.GRUCell(NumUnits)
            # bw_cell = tf.contrib.rnn.GRUCell(NumUnits)

            fw_cell = tf.nn.rnn_cell.DropoutWrapper(fw_cell, output_keep_prob=DropOut)
            bw_cell = tf.nn.rnn_cell.DropoutWrapper(bw_cell, output_keep_prob=DropOut)

            fw_init_state = fw_cell.zero_state(BatchSize, dtype=tf.float32)
            bw_init_state = bw_cell.zero_state(BatchSize, dtype=tf.float32)

            outputs, bi_state = tf.nn.bidirectional_dynamic_rnn(fw_cell, bw_cell, LSTMInput,
                                                            sequence_length=self.SeqLength,
                                                            initial_state_fw=fw_init_state,
                                                            initial_state_bw=bw_init_state, dtype=tf.float32)

        outputs = tf.concat(outputs, axis=-1)
        # outputs = self.high_way(outputs, size=NumUnits*2)

        return outputs

    def RelationLSTM(self, ObjectInput, WordVector,BatchSize=1):
        # encoding step
        out = self.SingleLSTMLayer(ObjectInput, NumUnits=self.HiddenSize, BatchSize=BatchSize)
        WordVector = slim.fully_connected(WordVector, num_outputs=100, activation_fn=None, biases_initializer=None)
        length = out.get_shape()[1].value
        out = tf.concat((out, WordVector[:, :length, :]), axis=-1)
        for i in range(3):
            with tf.variable_scope("EdgeContext_{0}".format(i)):
                out = self.SingleLSTMLayer(out, NumUnits=self.HiddenSize, BatchSize=BatchSize)
                out = tf.concat((out, WordVector[:, :length, :]), axis=-1)
        # decoding step use the original attention
        # DecodeLength = out.shape[-2].value
        # print("Decoding length:", DecodeLength)
        # score = slim.fully_connected(out, num_outputs=DecodeLength, activation_fn=tf.nn.relu, biases_initializer=None)
        # weight = tf.nn.softmax(score, -1)
        # if weight.shape[0].value == 1:
        #     weight = tf.squeeze(weight, 0)
        # context = tf.expand_dims(tf.matmul(weight, tf.squeeze(out, 0)), 0)
        # print("context shape:", context.get_shape())
        # DecodeOut = tf.concat((out, context), -1)
        # for i in range(2):
        #     with tf.variable_scope("EdgeDecode_{0}".format(i)):
        #         DecodeOut = self.SingleLSTMLayer(DecodeOut, NumUnits=self.HiddenSize, BatchSize=BatchSize)
        # output step
        result = slim.fully_connected(out, num_outputs=self.size*2, activation_fn=tf.nn.relu)
        Subjects, Objects = tf.split(result, 2, axis=-1)
        return Subjects, Objects

    def iter(self, RelationCandidate, SubjectVector, ObjectVector, name="iter", reuse=False):
        with tf.variable_scope(name, reuse=tf.AUTO_REUSE):
            for i in range(self.iters):
                pa = slim.fully_connected(SubjectVector, self.relationClass, scope="pa", reuse=tf.AUTO_REUSE)
                pa = slim.dropout(pa, keep_prob=self.dropout, is_training=self.IsTraining)
                pb = slim.fully_connected(ObjectVector, self.relationClass, scope="pb", reuse=tf.AUTO_REUSE)
                pb = slim.dropout(pb, keep_prob=self.dropout, is_training=self.IsTraining)
                RelationCandidate = slim.fully_connected(RelationCandidate, self.relationClass, scope="pr", reuse=tf.AUTO_REUSE)
                RelationCandidate = tf.nn.relu(pa+pb+RelationCandidate)
                RelationCandidate = slim.dropout(RelationCandidate, keep_prob=self.dropout, is_training=self.IsTraining)
                # feature_vector = tf.concat((pa, pb, pr), axis=-1)
                reuse = True if not reuse else reuse
        return RelationCandidate

    def getIndexCandidate(self):
        def test():
            x, y = tf.meshgrid(tf.range(self.SeqLength[0]), tf.range(self.SeqLength[0]))
            x, y = tf.reshape(x, (-1,)), tf.reshape(y, (-1,))
            return x,y
        def train():
            if self.RelationClass.get_shape()[0] == 1:
                RelationIndex = tf.squeeze(self.RelationClass, 0)
            else:
                RelationIndex = self.RelationClass
            SubjectIndex = RelationIndex[:, 0]
            ObjectIndex = RelationIndex[:, 1]
            return SubjectIndex, ObjectIndex
        subjectIndex, objectIndex = tf.cond(self.IsTraining, train, test)
        return subjectIndex, objectIndex

    def getEdgeScore(self, subjects, objects, masks):
        dim = subjects.get_shape()[-1]
        subjectIndex, objectIndex = self.getIndexCandidate()

        subjectMask, objectMask = tf.gather(masks, subjectIndex, axis=0), tf.gather(masks, objectIndex, axis=0)

        edgeMask = tf.stack((subjectMask, objectMask), axis=-1)
        edgeMask = self.GetPositionMask(edgeMask)
        maskDim = edgeMask.get_shape()[-1]
        print("edge mask shape", edgeMask.get_shape())

        subjectVector, objectVector = tf.gather(subjects, subjectIndex, axis=1), tf.gather(objects, objectIndex, axis=1)
        edgeScore = subjectVector - objectVector
        edgeScore = tf.concat((edgeScore, edgeMask), axis=-1)
        edgeScore = tf.reshape(edgeScore, (-1, dim+maskDim))
        edgeVec = slim.fully_connected(edgeScore, num_outputs=500)
        # edgeScore = tf.reshape(edgeScore, (-1, dim))
        print("edge score shape", edgeScore.get_shape())
        RelationCandidate = slim.fully_connected(edgeVec, num_outputs=self.relationClass)
        index = tf.stack((subjectIndex, objectIndex), axis=1)

        # 额外的损失，用于补充label之间的信息
        prepScore = slim.fully_connected(edgeMask, num_outputs=self.prepClass, activation_fn=None, biases_initializer=None)
        prepScore = tf.reshape(prepScore, (-1, self.prepClass))
        print("prepScore shape:",prepScore.get_shape())
        actionScore = slim.fully_connected(subjectVector, num_outputs=self.actionClass, activation_fn=None, biases_initializer=None)
        actionScore = tf.reshape(actionScore, (-1, self.actionClass))
        print("actionScore shape:", actionScore.get_shape())
        return RelationCandidate, index, prepScore, actionScore

    # 之前的版本 drop
    def GetRelationCandidate(self, Subjects, Objects):
        dim = Subjects.get_shape()[-1]
        def Test():
            x, y = tf.meshgrid(tf.range(self.SeqLength[0]), tf.range(self.SeqLength[0]))
            x, y = tf.reshape(x, (-1,)), tf.reshape(y, (-1,))
            # EqualIndex = tf.not_equal(x, y)
            # x, y = tf.boolean_mask(x, EqualIndex), tf.boolean_mask(y, EqualIndex)
            SubjectVector, ObjectVector = tf.gather(Subjects, x, axis=1), tf.gather(Objects, y, axis=1)
            RelationCandidate = SubjectVector*ObjectVector
            RelationCandidate = tf.reshape(RelationCandidate, (1, -1, dim))
            x, y = tf.expand_dims(x, axis=-1), tf.expand_dims(y, axis=-1)
            index = tf.reshape(tf.concat((x, y), axis=-1), (-1, 2))
            index = tf.expand_dims(index, axis=0)
            print("test index shape:",index.get_shape())

            return SubjectVector, ObjectVector, RelationCandidate, index

        def Train():
            if self.RelationClass.get_shape()[0] == 1:
                RelationIndex = tf.squeeze(self.RelationClass, 0)
            else:
                RelationIndex = self.RelationClass
            SubjectIndex = RelationIndex[:, 0]
            ObjectIndex = RelationIndex[:, 1]
            index = RelationIndex[:, :2]
            SubjectVector, ObjectVector = tf.gather(Subjects, SubjectIndex, axis=1), tf.gather(Objects, ObjectIndex, axis=1)
            RelationCandidate = SubjectVector*ObjectVector
            RelationCandidate = tf.squeeze(RelationCandidate, 0)
            return SubjectVector, ObjectVector, RelationCandidate, index
        SubjectVector, ObjectVector, RelationCandidate, index = tf.cond(self.IsTraining, Train, Test)
        RelationCandidate = tf.reshape(RelationCandidate, (-1, dim))
        SubjectVector, ObjectVector = tf.reshape(SubjectVector, (-1, dim)), tf.reshape(ObjectVector, (-1, dim))
        print("subject dim:", dim)
        RelationCandidate = slim.fully_connected(RelationCandidate, num_outputs=self.relationClass, activation_fn=None,
                                                 biases_initializer=None)
        print("RelationCandidate", RelationCandidate.get_shape())

        return RelationCandidate, index

    @staticmethod
    def GetPredict(RelationScore, index, IsKL=True):
        """
        :param RelationScore: [self.length*self.length, self.RelationClass]
        :param index: [self.length*self.length, 2 ]
        :return:
        """
        if np.asarray(index).shape[0] == 1:
            index = np.squeeze(np.asarray(index),0)

        relationClass = 71
        try:
            candidate = np.reshape(np.repeat(index, repeats=relationClass, axis=0), (index.shape[0], -1, 2))
        except Exception as e:
            index = np.asarray([index])
            candidate = np.reshape(np.repeat(index, repeats=relationClass, axis=0), (index.shape[0], -1, 2))
        CandidateCls = np.tile(np.asarray(range(relationClass)), index.shape[0])
        CandidateCls = np.reshape(CandidateCls, (index.shape[0], relationClass, 1))
        candidate = np.concatenate((candidate, CandidateCls,np.expand_dims(RelationScore, axis=-1)), axis=-1)
        candidate = np.reshape(candidate, (-1, 4))
        candidate = sorted(candidate, key=lambda x: x[-1], reverse=True)
        candidate = np.delete(candidate, -1, axis=-1)

        RelationCls = np.expand_dims(np.argmax(RelationScore, axis=-1), -1)
        Score = np.expand_dims(np.max(RelationScore, axis=-1), -1)
        PredictTriad = np.concatenate((index, RelationCls, Score), axis=-1)
        # print(PredictTriad.shape)
        PredictTriad = sorted(PredictTriad, key=lambda x:x[-1], reverse=True)
        PredictTriad = np.delete(PredictTriad, -1, axis=-1)

        return PredictTriad, Score, candidate

    def GetOptimizer(self, logits, maskLogits, actionLogits, labels, Teacher=False, alpha=0.5):
        print("logits shape", logits.get_shape())
        print("label shape", labels[:, 2].get_shape())
        edgeLabel, maskLabel, actionLabel = labels[:, 2], labels[:, 3], labels[:, 4]

        # edgeLosses = focal_loss_softmax(labels=edgeLabel, logits=logits)
        edgeLosses = tf.nn.sparse_softmax_cross_entropy_with_logits(
                     labels=edgeLabel, logits=logits)
        # maskLosses = tf.nn.sparse_softmax_cross_entropy_with_logits(
        #     labels=maskLabel, logits=maskLogits)
        # actionLosses = tf.nn.sparse_softmax_cross_entropy_with_logits(
        #     labels=actionLabel, logits=actionLogits)
        losses = edgeLosses # + maskLosses + actionLosses
        optimizer = tf.train.AdamOptimizer(learning_rate=self.learning_rate)
        if Teacher is True:
            # print("teacher input")
            # # teacherProb = 1e-3*tf.multiply(logits, tf.exp(self.TeacherInput), name="teacher")
            # teacherLogits = logits
            #
            # teacherLoss =  tf.nn.softmax_cross_entropy_with_logits(
            #     labels=logits*self.TeacherInput, logits=teacherLogits)
            # losses = alpha*teacherLoss + (1-alpha)*edgeLosses
            print("teacher input")
            teacherLogits = tf.nn.softmax(logits)
            teacherLabel = self.TeacherInput * teacherLogits
            teacherLoss = -tf.reduce_sum(teacherLabel * tf.log(tf.clip_by_value(teacherLogits, 1e-10, 1.0)))
            # teacherLoss =  tf.nn.softmax_cross_entropy_with_logits(
            # labels=tf.one_hot(edgeLabel, depth=self.relationClass), logits=self.TeacherInput*logits)
            a = tf.get_variable("weight_loss_a", initializer=tf.constant(2.0))
            b = tf.get_variable("weight_loss_b", initializer=tf.constant(2.0))
            # teacherLoss = -tf.reduce_mean(teacherProb * tf.log(tf.clip_by_value(tf.nn.softmax(logits), 1e-10, 1.0)))
            # losses = losses*tf.exp(-a) + tf.exp(-b)*teacherLoss + 0.5 * a + 0.5*b
            losses = edgeLosses * tf.exp(-a) + tf.exp(-b) * teacherLoss + 0.5 * a + 0.5 * b

        logits = tf.nn.softmax(logits)
        classes = tf.argmax(logits, axis=1, name='classes')
        accuracy = tf.reduce_mean(tf.cast(
            tf.equal(tf.cast(classes, dtype=tf.int32), edgeLabel), dtype=tf.float32))

        loss = tf.reduce_mean(losses)
        train_step = slim.learning.create_train_op(loss, optimizer)
        return loss, accuracy, train_step

    def GetSaver(self, name='vgg_16'):
        checkpoint_exclude_scopes = name
        exclusions = None
        if checkpoint_exclude_scopes:
            exclusions = [
                scope.strip() for scope in checkpoint_exclude_scopes.split(',')]
        variables_to_restore = []
        for var in slim.get_model_variables():
            excluded = False
            for exclusion in exclusions:
                if var.op.name.startswith(exclusion):
                    excluded = True
            if excluded:
                variables_to_restore.append(var)
        # path = os.path.join("ckpt", "pretrain", "ResnetVariables.ins")
        # pickle.dump(["resnet_v1_101"], open(path, "wb"))

        saver_restore = tf.train.Saver(var_list=variables_to_restore)
        saver = tf.train.Saver(tf.global_variables())

        return saver_restore, saver

    def TrainTest(self, TrainData, resnet_model_path, TestData, Error=True, teacher=False):
        BatchSize = TrainData.Batch
        loss, accuracy, train_step, EdgeScore, EdgeIndex = self.GetArch(BatchSize=BatchSize, teacher=teacher)
        saver_restore, saver = self.GetSaver()
        config = tf.ConfigProto(allow_soft_placement=True)
        config.gpu_options.per_process_gpu_memory_fraction = 0.95
        init = tf.global_variables_initializer()
        epoch = 10
        with tf.Session(config=config) as sess:
            sess.run(init)
            # Load the pretrained checkpoint file xxx.ckpt
            saver_restore.restore(sess, resnet_model_path)
            Acc = []
            for i in range(epoch):
                train = TrainData.NextBatchRelation(IsTeacher=teacher)
                test = TestData.NextBatchRelation(IsTeacher=teacher)
                TrainStep = 0
                for  temp_train in train:
                    if teacher:
                        SubImgs, ImgLabel, Relation, mask, teacherData, length = temp_train
                        TrainDict = {
                            self.Regions: SubImgs[0],
                            self.ObjectClass: ImgLabel[0],
                            self.RelationClass: Relation[0],
                            self.BatchSize: BatchSize,
                            self.IsTraining: True,
                            self.TeacherInput: teacherData,
                            self.Mask: mask[0],
                            self.SeqLength: length
                        }
                    else:
                        SubImgs, ImgLabel, Relation, mask, length = temp_train
                        TrainDict = {
                            self.Regions: SubImgs[0],
                            self.ObjectClass: ImgLabel[0],
                            self.RelationClass: Relation[0],
                            self.BatchSize: BatchSize,
                            self.IsTraining: True,
                            self.Mask: mask[0],
                            self.SeqLength: length
                        }
                    sess.run(train_step, feed_dict=TrainDict)
                    TrainLoss, TrainAcc = sess.run([loss, accuracy], feed_dict=TrainDict)
                    Acc.append(TrainAcc)
                    if TrainStep%100 == 0:
                        TrainResult = "train step:{0}, loss:{1}, acc:{2}".format(TrainStep, TrainLoss, sum(Acc)/Acc.__len__())
                        Acc = []
                        print(TrainResult)
                    TrainStep += 1
                EvalTest = EvalRecall()
                EvalAll = EvalRecall()
                if Error and isinstance(Error, str):
                    error = ErrorAnalysis(i, startPath=Error)
                Acc = []
                testImgName = (i for i in TestData.ImgName)
                for temp_test in test:
                    if teacher:
                        SubImgs, ImgLabel, Relation, mask, teacherData, length = temp_test
                        if not SubImgs:
                            continue
                        feedDict = {
                            self.Regions: SubImgs[0],
                            self.ObjectClass: ImgLabel[0],
                            self.RelationClass: Relation[0],
                            self.BatchSize: BatchSize,
                            self.IsTraining: True,
                            self.TeacherInput: teacherData,
                            self.Mask: mask[0],
                            self.SeqLength: length
                        }
                    else:
                        SubImgs, ImgLabel, Relation, mask, length = temp_test
                        if not SubImgs:
                            continue
                        feedDict =  {
                        self.Regions: SubImgs[0],
                        self.ObjectClass: ImgLabel[0],
                        self.RelationClass: Relation[0],
                        self.BatchSize:BatchSize,
                        self.Mask: mask[0],
                        self.SeqLength:length,
                        self.IsTraining: False
                    }

                    # TrainLoss, TrainAcc = sess.run([loss, accuracy], feed_dict=TrainDict)
                    # Acc.append(TrainAcc)
                    originalName = next(testImgName)
                    Score, index = sess.run([EdgeScore, EdgeIndex], feed_dict=feedDict)
                    Triad, TestRelationScore, candidate = self.GetPredict(Score, index)

                    # print("Truth Relation:",Relation[0])
                    # print("Triad:", Triad)
                    # print("Score:", TestRelationScore)
                    # pdb.set_trace()
                    EvalTest.add(Relation[0], Triad, TestRelationScore)
                    if Error:
                        error.add(originalName, SubImgs[0], ImgLabel[0], Relation[0], Triad)
                    EvalAll.add(Relation[0], candidate, TestRelationScore)
                # print("test set acc:", sum(Acc) / Acc.__len__())
                EvalTest.show()
                print("eval all candidate recall")
                EvalAll.show()
                if Error:
                    error.write()
                
if __name__ == "__main__":
    TrainMat = "annotations_train.json"
    train_data = DataLoad(TrainMat, "sg_train_images", False)
    # RestorePath = os.path.join("ckpt", "Semantic_segmentation_vgg", "Semantic_segmentation_vgg")
    RestorePath = os.path.join("ckpt", "Vgg", "vrd")
    TestMat = "annotations_test.json"
    test_data = DataLoad(TestMat, "sg_test_images", False)
    StorePath = os.path.join("ckpt", "Vrd", "vrd")
    Res = ContextModel()
    Res.TrainTest(train_data, RestorePath, test_data, Error=False, teacher=False)
