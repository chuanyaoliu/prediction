import tensorflow as tf
import numpy as np
from configparser import ConfigParser
import os
import pdb
from layer import *
from EvalRecall import ErrorAnalysis, EvalRecallUnion
from VIsualModel import vgg_16
from layer import AlternatingHighWayCell
from VrdContext import ContextModel
import tensorflow.contrib.slim as slim
from tensorflow.contrib.slim import nets
from LoadMat import DataLoad
from MatDRNet import UnionData
from EvalRecall import EvalRecall
np.set_printoptions(threshold=np.nan)
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
cfg = ConfigParser()
cfg.read("config.ini", encoding="utf-8-sig")

class VisualAttention(ContextModel):
    # Spatial attention
    def __init__(self):
        ContextModel.__init__(self)
        self.subjectImg = tf.placeholder(tf.float32, [None, self.ImgSize, self.ImgSize, 3])
        self.objectImg = tf.placeholder(tf.float32, [None, self.ImgSize, self.ImgSize, 3])
        self.unionImg = tf.placeholder(tf.float32, [None, self.ImgSize, self.ImgSize, 3])
        self.interImg  = tf.placeholder(tf.float32, [None, self.ImgSize, self.ImgSize, 3])

        self.interMask = tf.placeholder(tf.float32, [None, self.MaskSize, self.MaskSize])
        self.subjectMask = tf.placeholder(tf.float32, [None, self.MaskSize, self.MaskSize])
        self.objectMask = tf.placeholder(tf.float32, [None, self.MaskSize, self.MaskSize])
        self.unionMask = tf.placeholder(tf.float32, [None, self.MaskSize, self.MaskSize])
        self.subjectLabel = tf.placeholder(tf.int32, [None])
        self.objectLabel = tf.placeholder(tf.int32, [None])
        self.RelationClass = tf.placeholder(tf.int32, [None])
        self.a = tf.placeholder(tf.float32, )


    def GetArch(self, NumLayers=4, BatchSize=1, teacher=False):
        # Regions = tf.concat((self.Regions, self.UnionImg), axis=0)
        # print("Regions shape:", Regions.get_shape())
        # Visual = self.GetVisualFeature(self.Regions)

        imgRegion = tf.concat((self.subjectImg, self.objectImg, self.unionImg), axis=0)
        subjectVisual, objectVisual, _ = self.GetVisualFeature(imgRegion)
        unionVisual = subjectVisual*objectVisual
        # SubVisual = Visual[:,:self.length,:]
        # UnionVisual = Visual[:,self.length:,:]
        objectClass = tf.concat((self.subjectLabel, self.objectLabel), axis=0)
        # word = self.GetWordVector(self.ObjectClass, path=None)
        Word = self.GetWordVector(objectClass, path=None)
        WordVector = slim.fully_connected(Word, num_outputs=100, activation_fn=None, biases_initializer=None)
        # subjectWordVector, objectWordVector = tf.split(WordVector,2, axis=1)
        # Visual = WordVector
        # Visual = tf.concat((Visual, WordVector), axis=-1)
        # Subjects = tf.concat((subjectVisual, subjectWordVector), axis=-1)
        # Objects = tf.concat((objectVisual, objectWordVector), axis=-1)
        # # Subjects = slim.fully_connected(Visual, num_outputs=self.dim, activation_fn=None, biases_initializer=None)
        # # Objects = slim.fully_connected(Visual, num_outputs=self.dim, activation_fn=None, biases_initializer=None)
        # edgeVec = subjectWordVector*objectWordVector
        # # UnionVisual = slim.fully_connected(UnionVisual, num_outputs=self.dim, activation_fn=None, biases_initializer=None)
        edgeMask = tf.stack((self.subjectMask, self.objectMask, self.unionMask), axis=-1)
        # edgeMask = self.GetPositionMask(edgeMask)
        # edge = tf.concat((edgeVec, edgeMask), axis=-1)
        # edge = slim.fully_connected(edge, self.relationClass)
        # edge = tf.squeeze(edge, 0)
        # unionVisual = tf.concat((unionVisual, WordVector), axis=-1)
        #
        edge = self.ContextAware(unionVisual, WordVector, edgeMask)
        # edge = self.getEdgeScore(Subjects, Objects, edgeMask)
        # edge, index, maskScore, actionScore = self.getEdgeScore(Subjects, Objects, edgeMask)
        # Edge, index = self.GetRelationCandidate(Subjects, Objects)
        EdgeScore = tf.nn.softmax(edge, dim=-1)
        if teacher is True:
            EdgeScore = EdgeScore*self.TeacherInput
        loss, accuracy, train_step = self.GetOptimizer(edge,  self.RelationClass, Teacher=False)

        return loss, accuracy, train_step, EdgeScore, # index

    def GetVisualFeature(self, Regions):
        ResNetInput = tf.reshape(Regions, (-1, self.ImgSize, self.ImgSize, 3))
        with slim.arg_scope(nets.vgg.vgg_arg_scope()):
            net, endpoints, feature = vgg_16(ResNetInput, num_classes=None, is_training=self.IsTraining)
        # x_h, out = CANAttention(feature, is_training=self.IsTraining)
        # out = SpatialATT(feature)
        out = feature
        # out, weight = SelfATT(feature)
        with tf.variable_scope('vgg_16', reuse=True):
            # Use conv2d instead of fully_connected layers.
            out = slim.conv2d(out, 4096, [7, 7], padding="VALID", scope='fc6')
            out = slim.dropout(out, 0.5, is_training=self.IsTraining,
                               scope='dropout6')
            out = slim.conv2d(out, 4096, [1, 1], scope='fc7')
        VectorDim = out.get_shape()[-1]
        out = tf.reshape(out, (1, -1, VectorDim))
        # out = tf.concat((x_h, out), axis=-1)
        subjects, objects, union = tf.split(out, 3, axis=1)
        subjects = slim.fully_connected(subjects, num_outputs=self.dim)
        objects = slim.fully_connected(objects, num_outputs=self.dim)
        union = slim.fully_connected(union, num_outputs=self.dim)
        return subjects, objects, union

    def GetOptimizer(self, logits, labels, Teacher=True, alpha=0.5):
        print("label shape", labels.get_shape())
        # edgeLabel, maskLabel, actionLabel = labels[:, 2], labels[:, 3], labels[:, 4]
        edgeLabel = labels
        print(logits)
        # edgeLosses = focal_loss_softmax(labels=edgeLabel, logits=logits)
        edgeLosses = tf.nn.sparse_softmax_cross_entropy_with_logits(
                     labels=edgeLabel, logits=logits)

        losses = edgeLosses # + maskLosses + actionLosses
        optimizer = tf.train.AdamOptimizer(learning_rate=self.learning_rate)
        if Teacher is True:
            print("teacher input")
            teacherLogits = tf.nn.softmax(logits)
            teacherLabel = self.TeacherInput * teacherLogits
            teacherLoss = -tf.reduce_sum(teacherLabel * tf.log(tf.clip_by_value(teacherLogits, 1e-10, 1.0)))
            # teacherLoss =  tf.nn.softmax_cross_entropy_with_logits(
            # labels=tf.one_hot(edgeLabel, depth=self.relationClass), logits=self.TeacherInput*logits)
            a = tf.get_variable("weight_loss_a", initializer=tf.constant(2.0))
            b = tf.get_variable("weight_loss_b", initializer=tf.constant(2.0))
            # teacherLoss = -tf.reduce_mean(teacherProb * tf.log(tf.clip_by_value(tf.nn.softmax(logits), 1e-10, 1.0)))
            # losses = losses*tf.exp(-a) + tf.exp(-b)*teacherLoss + 0.5 * a + 0.5*b
            losses = edgeLosses * tf.exp(-a) + tf.exp(-b) * teacherLoss + 0.5 * a + 0.5 * b

        logits = tf.nn.softmax(logits)
        classes = tf.argmax(logits, axis=1, name='classes')
        accuracy = tf.reduce_mean(tf.cast(
            tf.equal(tf.cast(classes, dtype=tf.int32), edgeLabel), dtype=tf.float32))

        loss = tf.reduce_mean(losses)
        train_step = slim.learning.create_train_op(loss, optimizer)
        return loss, accuracy, train_step

    def getEdgeScore(self, subjects, objects, masks):
        dim = subjects.get_shape()[-1]
        # subjectIndex, objectIndex = self.getIndexCandidate()
        #
        # subjectMask, objectMask = tf.gather(masks, subjectIndex, axis=0), tf.gather(masks, objectIndex, axis=0)

        # edgeMask = tf.stack((subjectMask, objectMask), axis=-1)
        edgeMask = self.GetPositionMask(masks, name="edgeMask")
        # subjectMask = self.GetPositionMask(edgeMask, name="sub_mask")
        # objectMask = self.GetPositionMask(edgeMask, name="obj_mask")
        # edgeConfidenceScore = slim.fully_connected(edgeMask, num_outputs=1, activation_fn=tf.nn.sigmoid, biases_initializer=None)
        # edgeConfidenceScore = tf.squeeze(edgeConfidenceScore, 0)
        # edgeMask = subjectMask*objectMask
        maskDim = edgeMask.get_shape()[-1]
        print("edge mask  shape", edgeMask.get_shape())

        # subjectVector, objectVector = tf.gather(subjects, subjectIndex, axis=1), tf.gather(objects, objectIndex,axis=1)
        # subjectVector = tf.concat((subjectVector, subjectMask), axis=-1)
        # objectVector = tf.concat((objectVector, objectMask), axis=-1)
        # edgeScore = subjectVector * objectVector

        # subjectVector, objectVector = tf.gather(subjects, subjectIndex, axis=1), tf.gather(objects, objectIndex, axis=1)
        # subjectVector = tf.concat((subjectVector, subjectMask), axis=-1)
        # subjectVector = slim.fully_connected(subjectVector, num_outputs=500, activation_fn=tf.nn.relu, scope="sub")
        # objectVector = tf.concat((objectVector, objectMask), axis=-1)
        # objectVector = slim.fully_connected(objectVector, num_outputs=500, activation_fn=tf.nn.relu, scope="obj")

        # edgeScore = objectVector - subjectVector
        # edgeScore = tf.reshape(edgeScore, (-1, 500))
        edgeScore = subjects*objects
        edgeScore = tf.concat((edgeScore, edgeMask), axis=-1)
        print("edge score shape", edgeScore.get_shape())
        edgeScore = tf.reshape(edgeScore, (-1, maskDim+dim))
        RelationCandidate = slim.fully_connected(edgeScore, num_outputs=self.relationClass, activation_fn=None,
                                                 biases_initializer=None)
        # index = tf.stack((subjectIndex, objectIndex), axis=1)
        # 额外的损失，用于补充label之间的信息
        # prepScore = slim.fully_connected(edgeMask, num_outputs=self.prepClass, activation_fn=None,
        #                                  biases_initializer=None)
        # prepScore = tf.reshape(prepScore, (-1, self.prepClass))
        # print("prepScore shape:", prepScore.get_shape())
        # actionScore = slim.fully_connected(subjectVector, num_outputs=self.actionClass, activation_fn=None,
        #                                    biases_initializer=None)
        # actionScore = tf.reshape(actionScore, (-1, self.actionClass))
        # print("actionScore shape:", actionScore.get_shape())
        # return RelationCandidate, index, prepScore, actionScore
        return RelationCandidate

    def ContextAware(self, unionVisual, wordVector, edgeMask,scope="context_cls"):
        edgeMask = self.GetPositionMask(edgeMask)
        unionVisual = tf.concat((unionVisual, edgeMask), axis=-1)

        wordDim = wordVector.get_shape()[-1]
        feature_dim = unionVisual.get_shape()[-1]
        subjectWordVector, objectWordVector = tf.split(tf.squeeze(wordVector, 0), 2, axis=0)
        WordVector = tf.reshape(tf.concat((subjectWordVector, objectWordVector), axis=-1), (-1, wordDim * 2, 1))
        WordVector = tf.tile(WordVector, [1, 1, feature_dim])
        WordVector = tf.tile(tf.expand_dims(WordVector, -1), [1, 1, 1, self.relationClass])

        batch = tf.shape(unionVisual)[0]
        unionVisual = tf.expand_dims(tf.squeeze(unionVisual, axis=0), axis=-1)
        with tf.variable_scope(scope):
            wp = tf.get_variable("context_wp", shape=(1, feature_dim, self.relationClass))
            wp = tf.tile(wp, [batch, 1, 1])

            vp = tf.get_variable("context_vp", shape=(1, wordDim*2, feature_dim, self.relationClass))
            bias = tf.get_variable("context_bias", shape=(1, self.relationClass))
            vp = tf.tile(vp, [batch, 1, 1, 1])
            context = tf.reduce_sum(vp*WordVector, axis=1)
            cls = wp + context

            unionVisual = tf.tile(unionVisual, [1, 1, self.relationClass])
            score = tf.reduce_sum(unionVisual*cls, axis=1) + bias
            # weigth = wp + tf.matmul(WordVector, vp)
            # score = tf.matmul(weigth, unionVisual)
            # score = tf.squeeze(score, axis=-1)
        return score

    def contextMask(self, unionVisual, wordVector, edgeMask, scope="context_edge"):
        wordDim = wordVector.get_shape()[-1]
        subjectWordVector, objectWordVector = tf.split(tf.nn.relu(tf.squeeze(wordVector, 0)), 2, axis=0)
        WordVector = tf.reshape(tf.concat((subjectWordVector, objectWordVector), axis=-1), (1, -1, wordDim * 2))
        unionVisual = tf.concat((unionVisual, WordVector), axis=-1)
        edgeMask = self.GetPositionMask(edgeMask)
        edgeMask = tf.expand_dims(tf.squeeze(edgeMask, 0), axis=-1)
        edgeDim = edgeMask.get_shape()[1]
        feature_dim = unionVisual.get_shape()[-1]

        edgeMask = tf.tile(edgeMask, [1, 1, feature_dim])
        edgeMask = tf.tile(tf.expand_dims(edgeMask, -1), [1, 1, 1, self.relationClass])
        batch = tf.shape(unionVisual)[0]
        unionVisual = tf.expand_dims(tf.squeeze(unionVisual, axis=0), axis=-1)
        with tf.variable_scope(scope):
            wp = tf.get_variable("context_wp", shape=(1, feature_dim, self.relationClass))
            wp = tf.tile(wp, [batch, 1, 1])

            vp = tf.get_variable("context_vp", shape=(1, edgeDim, feature_dim, self.relationClass))
            bias = tf.get_variable("context_bias", shape=(1, self.relationClass))
            vp = tf.tile(vp, [batch, 1, 1, 1])

            context = tf.reduce_sum(vp*edgeMask, axis=1)
            cls = wp + context

            unionVisual = tf.tile(unionVisual, [1, 1, self.relationClass])
            score = tf.reduce_sum(unionVisual*cls, axis=1) + bias
            # weigth = wp + tf.matmul(WordVector, vp)
            # score = tf.matmul(weigth, unionVisual)
            # score = tf.squeeze(score, axis=-1)
        return score

    @staticmethod
    def split(data):
        result1, result2 = dict(), dict()
        for key, value in data.items():
            length = value.__len__()//2
            try:
                result1[key] = value[:length]
                result2[key] = value[length:]
            except TypeError:
                result1[key] = value
                result2[key] = value
        return result1, result2

    def TrainTest(self, TrainData, resnet_model_path, TestData, Error=True, teacher=False, epoch=10):
        BatchSize = TrainData.Batch
        loss, accuracy, train_step, EdgeScore = self.GetArch(BatchSize=BatchSize, teacher=teacher)
        saver_restore, saver = self.GetSaver()
        config = tf.ConfigProto(allow_soft_placement=True)
        config.gpu_options.per_process_gpu_memory_fraction = 0.95
        init = tf.global_variables_initializer()
        with tf.Session(config=config) as sess:
            sess.run(init)
            # Load the pretrained checkpoint file xxx.ckpt
            saver_restore.restore(sess, resnet_model_path)
            Acc = []
            for i in range(epoch):
                train = TrainData.getNext(teacher=teacher)
                test = TestData.getNext(teacher=teacher)
                TestData.Length = []
                TrainStep = 0
                for temp_train in train:
                    if teacher:
                        inter, union, subject, objects, subLabel, objLabel, rel, teacherInput = temp_train
                        TrainDict = {
                            self.subjectImg:subject[0],
                            self.subjectMask:subject[1],
                            self.subjectLabel:subLabel,

                            self.objectImg:objects[0],
                            self.objectMask:objects[1],
                            self.objectLabel:objLabel,

                            self.unionImg:union[0],
                            self.unionMask:union[1],
                            self.RelationClass:rel,
                            self.IsTraining: True,
                            self.TeacherInput: teacherInput,

                        }
                    else:
                        inter, union, subject, objects, subLabel, objLabel, rel = temp_train
                        TrainDict = {
                            self.subjectImg: subject[0],
                            self.subjectMask: subject[1],
                            self.subjectLabel: subLabel,

                            self.objectImg: objects[0],
                            self.objectMask: objects[1],
                            self.objectLabel: objLabel,

                            self.RelationClass: rel,
                            self.unionImg: union[0],
                            self.unionMask: union[1],

                            self.IsTraining: True}
                    if TrainStep > 500 and i == 0:
                        TrainDict[self.a] = 0.5
                    else:
                        TrainDict[self.a] = 1.0
                    try:
                        sess.run(train_step, feed_dict=TrainDict)
                        TrainLoss, TrainAcc = sess.run([loss, accuracy], feed_dict=TrainDict)
                    except Exception as e:
                        print("running error")
                        feedDict1, feedDict2 = self.split(TrainDict)
                        sess.run(train_step, feed_dict=feedDict1)
                        sess.run(train_step, feed_dict=feedDict2)
                        TrainLoss, TrainAcc = sess.run([loss, accuracy], feed_dict=feedDict2)

                    Acc.append(TrainAcc)
                    if TrainStep % 100 == 0:
                        TrainResult = "train step:{0}, loss:{1}, acc:{2}".format(TrainStep, TrainLoss,
                                                                                 sum(Acc) / Acc.__len__())
                        Acc = []
                        print(TrainResult)
                    TrainStep += 1
                EvalTest = EvalRecall()
                EvalAll = EvalRecall()
                evalTest = EvalRecallUnion()
                if Error and isinstance(Error, str):
                    error = ErrorAnalysis(i, startPath=Error)
                Acc = []
                testImgName = (i for i in TestData.ImgName)
                for temp_test in test:
                    if teacher is True:
                        inter, union, subject, objects, subLabel, objLabel, rel, teacherInput = temp_test
                        feedDict = {
                            self.subjectImg: subject[0],
                            self.subjectMask: subject[1],
                            self.subjectLabel: subLabel,

                            self.objectImg: objects[0],
                            self.objectMask: objects[1],
                            self.objectLabel: objLabel,
                            self.TeacherInput: teacherInput,
                            self.unionImg: union[0],
                            self.unionMask: union[1],
                            self.RelationClass: rel,
                            self.IsTraining: True}
                    else:
                        inter, union, subject, objects, subLabel, objLabel, rel = temp_test
                        feedDict = {
                            self.subjectImg: subject[0],
                            self.subjectMask: subject[1],
                            self.subjectLabel: subLabel,

                            self.objectImg: objects[0],
                            self.objectMask: objects[1],
                            self.objectLabel: objLabel,

                            self.unionImg: union[0],
                            self.unionMask: union[1],
                            self.RelationClass: rel,
                            self.IsTraining: True}
                    # TrainLoss, TrainAcc = sess.run([loss, accuracy], feed_dict=TrainDict)
                    # Acc.append(TrainAcc)
                    # originalName = next(testImgName)
                    # Score, index = sess.run([EdgeScore, EdgeIndex], feed_dict=feedDict)
                    Score = sess.run(EdgeScore, feed_dict=feedDict)
                    evalTest.add(rel, Score, subLabel, objLabel, subject[-1], objects[-1])
                    # Triad, TestRelationScore, candidate = self.GetPredict(Score, index)
                    # print("Truth Relation:",Relation[0])
                    # print("Triad:", Triad)
                    # print("Score:", TestRelationScore)
                    # pdb.set_trace()

                    # EvalTest.add(relation, Triad, TestRelationScore)
                    # if Error:
                    #     error.add(originalName, SubImgs[0], ImgLabel[0], relation, Triad)
                    # EvalAll.add(Relation[0], candidate, TestRelationScore)
                # print("test set acc:", sum(Acc) / Acc.__len__())
                evalTest.eval(TestData.Length)
                evalTest.show()
                if Error:
                    error.write()


if __name__ == "__main__":
    batch = 4
    TrainMat = "annotations_train.json"
    train_data = UnionData(TrainMat, "sg_train_images", batch=batch)
    RestorePath = os.path.join("ckpt", "Vgg", "vrd")
    TestMat = "annotations_test.json"
    test_data = UnionData(TestMat, "sg_test_images", batch=batch)
    StorePath = os.path.join("ckpt", "Vrd", "vrd")
    Res = VisualAttention()
    Res.TrainTest(train_data, RestorePath, test_data, Error=False, teacher=False)